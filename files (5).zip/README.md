# NETRAVAAH — React Frontend
## AI-Powered Governance Intelligence Platform

---

## 🚀 Quick Start

```bash
npm install
npm run dev          # http://localhost:3000
npm run build        # production build
```

---

## 📁 File Structure

```
src/
├── main.jsx                          # React entry point
├── App.jsx                           # Router (page switching via Zustand)
│
├── data/
│   └── masterData.js                 # ALL departments, models, mock reports
│
├── store/
│   └── useStore.js                   # Zustand global state (auth, nav, toast)
│
├── lib/
│   └── theme.js                      # Design tokens + levelColor helper
│
├── hooks/
│   └── useApi.js                     # React Query hooks for every API endpoint
│
├── components/
│   ├── ui/index.jsx                  # Shared: Btn, Card, Badge, SHAPBar, Toast…
│   ├── layout/
│   │   ├── Navbar.jsx                # Top navigation bar
│   │   └── DashboardSidebar.jsx      # Govt dashboard sidebar
│   └── auth/
│       └── AuthModal.jsx             # Login / Signup modal (Citizen + Govt)
│
└── pages/
    ├── LandingPage.jsx               # Hero + Features + Dept showcase + CTA
    ├── CommunityPage.jsx             # Feed + Trending + Govt Intelligence tabs
    ├── DepartmentsPage.jsx           # All 10 dept cards with live report counts
    ├── DepartmentDetailPage.jsx      # Single dept: reports, models, analytics, tasks
    ├── AllModelsPage.jsx             # All AI models registry with dept filter
    ├── ModelDetailPage.jsx           # Single model: pipeline, SHAP, live inference
    ├── DashboardPage.jsx             # Govt command center (sidebar + sub-pages)
    ├── IssueReportPage.jsx           # Citizen issue form (GPS, voice, S3 upload)
    └── ProfilePage.jsx               # User profile: issues, posts, activity
```

---

## 🏛️ Departments & Their AI Models

| # | Department | Models |
|---|-----------|--------|
| 1 | 🌾 Agriculture (MoAFW) | Crop Yield, Stress Detection, Disease Detection (ResNet-9), Irrigation (FAO-56), Crop Suitability (XGBoost), Agriculture Risk Score |
| 2 | 🚨 NDMA | Flood Risk v5, Landslide, Heatwave, Drought, Cyclone |
| 3 | 💧 Jal Shakti | Flood Risk, Drought, Water Quality, Reservoir Levels, Groundwater |
| 4 | 🏥 Health | Disease Outbreak, Epidemic Risk, Malnutrition, Air Quality Health, Vector-Borne |
| 5 | 🛣️ MoRTH | Road Damage, Pothole Detection, Traffic Prediction, Bridge Stress, Infrastructure Risk |
| 6 | ⚡ Power | Grid Failure, Power Demand, Outage Prediction, Renewable Forecast, Load Balancing |
| 7 | 🌿 MoEFCC | Air Quality, Deforestation Risk, Pollution Index, Wildfire Risk, Biodiversity |
| 8 | 🏙️ Urban Dev | Urban Flooding, Slum Risk, Water Supply, Sanitation, Smart City |
| 9 | 🚂 Railways | Track Defect, Signal Failure, Flood Track Risk, Maintenance Priority, Delay Prediction |
| 10 | 💰 Finance | Economic Stress, Crop Insurance (PMFBY), Disaster Fund, Poverty Index, Subsidy |

---

## 🔑 Auth Roles

| Role | Access |
|------|--------|
| **Citizen** | Landing, Community Feed, Issue Report, Profile, Public dashboards |
| **Govt Official** | Everything + Govt Intelligence tab, All Dept Reports, Dashboard with AI predictions, Priority Queue, Audit Trail |

When logging in as Govt Official, user selects their Ministry → sees personalized dept-specific reports.

---

## 💬 Community Tabs

| Tab | Access |
|-----|--------|
| 🌐 Citizen Feed | All users |
| 📈 Trending | All users |
| 🏛️ Govt Intelligence | **Govt only** — all AI model reports grouped by department |
| 📊 All Dept Reports | **Govt only** — flat list, filterable by dept + level |

---

## 🧠 AI Model Detail Page

Each model page shows:
- Live inference panel (select district → run model)
- Confidence interval output
- SHAP explainability bars
- Full input feature list
- Output variables
- Pipeline steps (animated)
- Live data sources
- Model specifications
- Alert thresholds
- Stress/risk class breakdowns (where applicable)

---

## 🔌 Backend API Endpoints (from zip files)

### Hazard Prediction (Flask, port 5000)
```
GET  /api/overview                    # All 30 districts
GET  /api/district/<name>             # Full prediction cycle
GET  /api/anomalies/<name>            # z-score vs 3yr baseline
GET  /api/forecast-alerts/<name>      # 72h forecast-based alerts
GET  /api/pipeline-status             # All 9 pipeline components
GET  /api/evac-routes/<name>          # Evacuation routing
GET  /api/dam-advisories              # Dam stress
GET  /api/bridge-advisories           # Bridge advisories
GET  /api/shelters                    # NDRF shelter locations
GET  /api/export/alerts               # CSV export
```

### Agriculture Models (FastAPI)
```
GET  /api/agri/yield/<district>       # Model 1: Crop yield
GET  /api/agri/stress/<district>      # Model 2: Stress detection (6 classes)
POST /api/agri/disease                # Model 3: Disease from leaf image
GET  /api/agri/irrigation/<district>  # Model 4: FAO-56 ET₀
GET  /api/agri/suitability/<district> # Model 5: Best crop XGBoost
GET  /api/agri/risk/<district>        # Model 6: Risk score ensemble
```

### NETRAVAAH Core API
```
POST /api/auth/login
POST /api/auth/signup
POST /api/auth/refresh
GET  /api/issues
POST /api/issues
GET  /api/issues/:id
PATCH /api/issues/:id/status
POST /api/media/presigned-url         # S3 presigned upload
GET  /api/posts
POST /api/posts
POST /api/posts/:id/vote
GET  /api/dashboard/overview
GET  /api/dashboard/priority-queue
GET  /api/dashboard/audit-trail
GET  /api/notifications
```

---

## 🎨 Design System

```css
--navy:    #0B1E3D  /* Authority */
--gold:    #C6A75E  /* Prestige */
--saffron: #F59E0B  /* Indian identity */
--success: #10B981
--warning: #F59E0B
--error:   #EF4444
```

**Fonts:** Playfair Display (headings) · Inter (body) · IBM Plex Mono (data)

---

## 📦 Key Dependencies

```json
{
  "react": "18",
  "zustand": "4",              // Global state
  "@tanstack/react-query": "5", // API caching
  "axios": "1",                // HTTP
  "framer-motion": "11",       // Animations
  "recharts": "2",             // Charts
  "react-leaflet": "4",        // Maps
  "leaflet": "1"
}
```

---

*NETRAVAAH — India's Future Governance OS*  
*Built for Digital India · Powered by AI · Trusted by Citizens*  
*v2.4.1 · March 2026*
