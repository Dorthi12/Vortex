import React, { useState } from 'react';
import { useStore } from '../../store/useStore';
import { DEPARTMENTS, MOCK_REPORTS, AI_MODELS } from '../../data/masterData';
import { Card, CardHeader, LevelBadge, Btn, SHAPBar, ConfBar, ScoreRing, StatCard, MiniBarChart } from '../ui';
import { levelColor } from '../../lib/theme';

export default function DepartmentDetailPage({ deptId }) {
  const { setPage, setActiveModel, isGovt, showToast } = useStore();
  const [activeTab, setActiveTab] = useState('reports');
  const [filterLevel, setFilterLevel] = useState('all');

  const dept = DEPARTMENTS.find(d => d.id === deptId);
  if (!dept) return <div style={{ padding:'2rem' }}>Department not found</div>;

  const reports = MOCK_REPORTS[deptId] || [];
  const deptModels = dept.models.map(m => AI_MODELS[m]).filter(Boolean);
  const filtered = filterLevel === 'all' ? reports : reports.filter(r => r.level === filterLevel);

  const criticals = reports.filter(r => r.level === 'CRITICAL').length;
  const highs = reports.filter(r => r.level === 'HIGH').length;

  const TABS = [
    { id:'reports', label:'AI Reports', count: reports.length },
    { id:'models', label:'AI Models', count: deptModels.length },
    { id:'analytics', label:'Analytics' },
    { id:'tasks', label:'Tasks', count: dept.pendingIssues },
  ];

  return (
    <div style={{ padding:'2rem' }}>
      {/* Header */}
      <div style={{ marginBottom:'2rem' }}>
        <button onClick={() => setPage('departments')} style={{ background:'none', border:'none', cursor:'pointer', fontSize:'0.8125rem', color:'#64748B', display:'flex', alignItems:'center', gap:6, marginBottom:'1rem' }}>
          ← Back to Departments
        </button>
        <div style={{ display:'flex', alignItems:'flex-start', gap:'1.25rem' }}>
          <div style={{ width:60, height:60, borderRadius:16, background: dept.bg, border:`1px solid ${dept.border}`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:'2rem', flexShrink:0 }}>{dept.icon}</div>
          <div style={{ flex:1 }}>
            <div style={{ display:'flex', alignItems:'center', gap:10, flexWrap:'wrap' }}>
              <h1 style={{ fontFamily:'Playfair Display', fontSize:'1.5rem', fontWeight:700, color:'#0B1E3D' }}>{dept.shortName}</h1>
              <span style={{ fontSize:'0.6875rem', padding:'3px 10px', borderRadius:100, background: dept.bg, color: dept.color, border:`1px solid ${dept.border}`, fontWeight:700 }}>{dept.activeAlerts} Active Alerts</span>
            </div>
            <div style={{ fontSize:'0.875rem', color:'#64748B', marginTop:3 }}>{dept.name}</div>
            <div style={{ fontSize:'0.8125rem', color:'#64748B', marginTop:6 }}>{dept.description}</div>
          </div>
          <div style={{ display:'flex', gap:8 }}>
            <Btn variant="outline" size="sm" onClick={() => showToast('📥 Report exported')}>📥 Export</Btn>
            <Btn variant="gold" size="sm" onClick={() => showToast('🚨 Alert dispatched to dept')}>🚨 Alert Dept</Btn>
          </div>
        </div>
      </div>

      {/* KPIs */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:'1rem', marginBottom:'2rem' }}>
        <StatCard icon="🚨" value={criticals} label="Critical Alerts" iconBg="rgba(239,68,68,0.08)" trend="Active now" />
        <StatCard icon="⚠️" value={highs} label="High Priority" iconBg="rgba(245,158,11,0.08)" />
        <StatCard icon="✅" value={dept.resolvedIssues} label="Resolved (30d)" iconBg="rgba(16,185,129,0.08)" trend="↑ 8%" trendUp />
        <StatCard icon="🤖" value={deptModels.length} label="AI Models Active" iconBg={dept.bg} />
      </div>

      {/* Tabs */}
      <div style={{ display:'flex', gap:4, background:'white', borderRadius:10, padding:4, border:'1px solid #E2E8F0', marginBottom:'1.5rem', width:'fit-content' }}>
        {TABS.map(t => (
          <button key={t.id} onClick={() => setActiveTab(t.id)} style={{
            padding:'6px 16px', borderRadius:7, fontSize:'0.8125rem', fontWeight:600,
            border:'none', cursor:'pointer', transition:'all 0.2s',
            background: activeTab === t.id ? 'linear-gradient(135deg,#0B1E3D,#1A3A6E)' : 'transparent',
            color: activeTab === t.id ? 'white' : '#64748B',
          }}>
            {t.label} {t.count !== undefined && <span style={{ marginLeft:4, fontSize:'0.6rem', background: activeTab===t.id ? 'rgba(255,255,255,0.2)' : 'rgba(11,30,61,0.06)', padding:'1px 5px', borderRadius:100 }}>{t.count}</span>}
          </button>
        ))}
      </div>

      {/* AI REPORTS TAB */}
      {activeTab === 'reports' && (
        <div>
          <div style={{ display:'flex', gap:6, marginBottom:'1.25rem' }}>
            {['all','CRITICAL','HIGH','MEDIUM'].map(l => (
              <button key={l} onClick={() => setFilterLevel(l)} style={{
                padding:'4px 12px', borderRadius:6, fontSize:'0.75rem', fontWeight:700,
                border: filterLevel===l ? 'none' : '1.5px solid #E2E8F0',
                background: filterLevel===l ? (l==='CRITICAL'?'#EF4444':l==='HIGH'?'#F59E0B':l==='MEDIUM'?'#10B981':'linear-gradient(135deg,#0B1E3D,#1A3A6E)') : 'transparent',
                color: filterLevel===l ? 'white' : '#64748B', cursor:'pointer',
              }}>{l === 'all' ? 'All Reports' : l}</button>
            ))}
          </div>

          <div style={{ display:'flex', flexDirection:'column', gap:'0.875rem' }}>
            {filtered.map(report => (
              <ReportCard key={report.id} report={report} dept={dept} onViewModel={(modelId) => { setActiveModel(modelId); setPage('model_' + modelId); }} />
            ))}
            {filtered.length === 0 && (
              <div style={{ padding:'3rem', textAlign:'center', color:'#94A3B8', background:'white', borderRadius:14, border:'1px solid #E2E8F0' }}>
                No reports at this filter level
              </div>
            )}
          </div>
        </div>
      )}

      {/* AI MODELS TAB */}
      {activeTab === 'models' && (
        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(300px,1fr))', gap:'1.25rem' }}>
          {deptModels.map(model => (
            <ModelCard key={model.id} model={model} dept={dept} onClick={() => { setActiveModel(model.id); setPage('model_' + model.id); }} />
          ))}
        </div>
      )}

      {/* ANALYTICS TAB */}
      {activeTab === 'analytics' && (
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'1.25rem' }}>
          <Card>
            <CardHeader title="Issue Volume (7 days)" />
            <div style={{ padding:'1.25rem' }}>
              <MiniBarChart height={100} data={[
                {value:12,label:'Mon',color:'linear-gradient(180deg,#C6A75E,rgba(198,167,94,0.3))'},
                {value:18,label:'Tue',color:'linear-gradient(180deg,#C6A75E,rgba(198,167,94,0.3))'},
                {value:9,label:'Wed',color:'linear-gradient(180deg,#C6A75E,rgba(198,167,94,0.3))'},
                {value:24,label:'Thu',color:'linear-gradient(180deg,#F59E0B,rgba(245,158,11,0.4))'},
                {value:21,label:'Fri',color:'linear-gradient(180deg,#EF4444,rgba(239,68,68,0.4))'},
                {value:14,label:'Sat',color:'linear-gradient(180deg,#C6A75E,rgba(198,167,94,0.3))'},
                {value:8,label:'Sun',color:'linear-gradient(180deg,#10B981,rgba(16,185,129,0.3))'},
              ]} />
            </div>
          </Card>

          <Card>
            <CardHeader title="Resolution Rate" />
            <div style={{ padding:'1.25rem' }}>
              <ConfBar label="Issues Resolved" value={Math.round(dept.resolvedIssues/(dept.resolvedIssues+dept.pendingIssues)*100)} color={dept.color} />
              <ConfBar label="SLA Compliance" value={78} color={dept.color} />
              <ConfBar label="AI Model Accuracy" value={deptModels.length > 0 ? Math.round(deptModels.reduce((a,m)=>a+m.accuracy,0)/deptModels.length) : 0} color={dept.color} />
            </div>
          </Card>

          <Card>
            <CardHeader title="Model Performance" />
            <div style={{ padding:'1.25rem', display:'flex', flexDirection:'column', gap:'0.75rem' }}>
              {deptModels.map(m => (
                <div key={m.id} style={{ display:'flex', alignItems:'center', gap:10 }}>
                  <span style={{ fontSize:'0.875rem', width:20 }}>{m.icon}</span>
                  <span style={{ fontSize:'0.75rem', flex:1, color:'#0F172A', fontWeight:500 }}>{m.name}</span>
                  <div style={{ width:80, height:5, background:'#F0F4F8', borderRadius:100, overflow:'hidden' }}>
                    <div style={{ width:`${m.accuracy}%`, height:'100%', background: dept.color, borderRadius:100 }} />
                  </div>
                  <span style={{ fontFamily:'IBM Plex Mono', fontSize:'0.6875rem', fontWeight:700, color: dept.color, width:36, textAlign:'right' }}>{m.accuracy}%</span>
                </div>
              ))}
            </div>
          </Card>

          <Card>
            <CardHeader title="Alert Distribution" />
            <div style={{ padding:'1.25rem' }}>
              {[['CRITICAL', criticals, '#EF4444'], ['HIGH', highs, '#F59E0B'], ['MEDIUM', reports.length - criticals - highs, '#10B981']].map(([l,v,c]) => (
                <div key={l} style={{ display:'flex', alignItems:'center', gap:10, marginBottom:'0.75rem' }}>
                  <span style={{ fontSize:'0.6875rem', fontWeight:700, color: c, width:64 }}>{l}</span>
                  <div style={{ flex:1, height:6, background:'#F0F4F8', borderRadius:100, overflow:'hidden' }}>
                    <div style={{ width: reports.length > 0 ? `${(v/reports.length)*100}%` : '0%', height:'100%', background: c, borderRadius:100 }} />
                  </div>
                  <span style={{ fontFamily:'IBM Plex Mono', fontSize:'0.6875rem', color:'#64748B', width:20, textAlign:'right' }}>{v}</span>
                </div>
              ))}
            </div>
          </Card>
        </div>
      )}

      {/* TASKS TAB */}
      {activeTab === 'tasks' && (
        <div style={{ display:'flex', flexDirection:'column', gap:'0.875rem' }}>
          {reports.filter(r=>!r.assigned).map(r => (
            <Card key={r.id} className="p-4">
              <div style={{ display:'flex', alignItems:'center', gap:12 }}>
                <ScoreRing score={r.score} size={40} />
                <div style={{ flex:1 }}>
                  <div style={{ fontSize:'0.875rem', fontWeight:600, color:'#0F172A' }}>{r.title}</div>
                  <div style={{ fontSize:'0.75rem', color:'#64748B', marginTop:2 }}>{r.district}, {r.state} · {r.time}</div>
                </div>
                <LevelBadge level={r.level} />
                <Btn variant="primary" size="sm" onClick={() => showToast(`✅ Assigned to ${dept.shortName} team`)}>Assign</Btn>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

// ── Report Card ───────────────────────────────────────────────────
function ReportCard({ report, dept, onViewModel }) {
  const [expanded, setExpanded] = useState(false);
  const model = AI_MODELS[report.model];
  const lc = levelColor(report.level);

  return (
    <div style={{ background:'white', border:`1px solid ${lc.badge}`, borderRadius:14, overflow:'hidden', transition:'all 0.2s' }}>
      <div style={{ height:3, background:`linear-gradient(90deg,${dept.color},${dept.color}60)` }} />
      <div style={{ padding:'1.125rem 1.25rem' }}>
        <div style={{ display:'flex', alignItems:'flex-start', gap:12 }}>
          <ScoreRing score={report.score} size={44} />
          <div style={{ flex:1, minWidth:0 }}>
            <div style={{ display:'flex', alignItems:'flex-start', gap:8, flexWrap:'wrap', marginBottom:4 }}>
              <div style={{ fontSize:'0.9375rem', fontWeight:700, color:'#0F172A', flex:1 }}>{report.title}</div>
              <LevelBadge level={report.level} />
              {!report.assigned && <span style={{ fontSize:'0.6rem', background:'rgba(239,68,68,0.08)', color:'#DC2626', padding:'2px 7px', borderRadius:100, fontWeight:700, border:'1px solid rgba(239,68,68,0.2)' }}>UNASSIGNED</span>}
            </div>
            <p style={{ fontSize:'0.8125rem', color:'#64748B', lineHeight:1.55, marginBottom:'0.75rem' }}>{report.summary}</p>
            <div style={{ display:'flex', gap:8, flexWrap:'wrap', alignItems:'center' }}>
              {model && <span style={{ fontSize:'0.6rem', padding:'2px 8px', borderRadius:100, background: dept.bg, color: dept.color, border:`1px solid ${dept.border}`, fontWeight:700 }}>{model.icon} {model.name}</span>}
              <span style={{ fontSize:'0.6875rem', color:'#94A3B8' }}>📍 {report.district}, {report.state}</span>
              <span style={{ fontSize:'0.6875rem', color:'#94A3B8' }}>⏰ {report.time}</span>
              <button onClick={() => setExpanded(!expanded)} style={{ marginLeft:'auto', fontSize:'0.6875rem', color:'#C6A75E', fontWeight:600, background:'none', border:'none', cursor:'pointer' }}>
                {expanded ? '▲ Less' : '▼ SHAP Details'}
              </button>
            </div>
          </div>
        </div>

        {expanded && model && (
          <div style={{ marginTop:'1rem', padding:'0.875rem', background:'rgba(11,30,61,0.02)', border:'1px solid rgba(198,167,94,0.2)', borderRadius:10 }}>
            <div style={{ fontSize:'0.6875rem', fontWeight:700, letterSpacing:'0.08em', textTransform:'uppercase', color:'#C6A75E', marginBottom:'0.75rem' }}>🧠 SHAP Explanation — Why this score?</div>
            {model.shapFactors.map((f, i) => (
              <SHAPBar key={i} label={f} value={model.shapValues[i]} maxValue={0.5} color={dept.color} />
            ))}
            <div style={{ display:'flex', gap:8, marginTop:'0.875rem' }}>
              <Btn variant="primary" size="sm" onClick={() => onViewModel(model.id)}>View {model.name}</Btn>
              <Btn variant="outline" size="sm" onClick={() => {}}>Assign to Dept</Btn>
              <Btn variant="gold" size="sm" onClick={() => {}}>🚨 Escalate</Btn>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ── Model Card ────────────────────────────────────────────────────
function ModelCard({ model, dept, onClick }) {
  return (
    <Card className="overflow-hidden cursor-pointer group" onClick={onClick}>
      <div style={{ height:3, background: model.color || dept.color }} />
      <div style={{ padding:'1.25rem' }}>
        <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:'0.875rem' }}>
          <div style={{ width:40, height:40, borderRadius:10, background:`${model.color || dept.color}18`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:'1.25rem' }}>{model.icon}</div>
          <div>
            <div style={{ fontSize:'0.9375rem', fontWeight:700, color:'#0F172A', fontFamily:'Playfair Display' }}>{model.name}</div>
            <div style={{ fontSize:'0.6875rem', color:'#64748B' }}>{model.algorithm}</div>
          </div>
        </div>
        <p style={{ fontSize:'0.8125rem', color:'#64748B', lineHeight:1.55, marginBottom:'0.875rem' }}>{model.description}</p>
        <div style={{ display:'flex', gap:8, marginBottom:'0.875rem' }}>
          <span style={{ fontSize:'0.6rem', padding:'2px 8px', borderRadius:100, background:'rgba(16,185,129,0.08)', color:'#10B981', fontWeight:700 }}>✓ {model.accuracy}% Acc</span>
          <span style={{ fontSize:'0.6rem', padding:'2px 8px', borderRadius:100, background:'rgba(11,30,61,0.06)', color:'#64748B', fontWeight:600 }}>{model.trainingRecords} records</span>
          <span style={{ fontSize:'0.6rem', padding:'2px 8px', borderRadius:100, background:'rgba(198,167,94,0.08)', color:'#C6A75E', fontWeight:600 }}>{model.version}</span>
        </div>
        <ConfBar label="Model Confidence" value={model.accuracy} color={model.color || dept.color} />
        <div style={{ textAlign:'right' }}>
          <button style={{ fontSize:'0.75rem', color:'#C6A75E', fontWeight:600, background:'none', border:'none', cursor:'pointer' }}>View Full Model →</button>
        </div>
      </div>
    </Card>
  );
}
