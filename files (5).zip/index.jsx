import React from 'react';
import { levelColor } from '../../lib/theme';

// ── Button ────────────────────────────────────────────────────────
export const Btn = ({ children, variant = 'primary', size = 'md', onClick, className = '', style = {} }) => {
  const base = 'inline-flex items-center gap-1.5 font-semibold rounded-lg cursor-pointer transition-all duration-200 border-0 font-[Inter]';
  const sizes = { sm:'px-3 py-1.5 text-xs', md:'px-4 py-2 text-sm', lg:'px-6 py-3 text-base' };
  const variants = {
    primary:  'bg-gradient-to-br from-[#0B1E3D] to-[#1A3A6E] text-white hover:-translate-y-0.5 hover:shadow-lg',
    gold:     'bg-gradient-to-br from-[#C6A75E] to-[#F59E0B] text-[#0B1E3D] hover:-translate-y-0.5 hover:shadow-md',
    outline:  'bg-transparent border border-[#E2E8F0] text-[#64748B] hover:border-[#0B1E3D] hover:text-[#0B1E3D]',
    ghost:    'bg-transparent text-[#64748B] hover:bg-[#F0F4F8] hover:text-[#0B1E3D]',
    danger:   'bg-red-50 text-red-600 border border-red-200 hover:bg-red-100',
  };
  return (
    <button className={`${base} ${sizes[size]} ${variants[variant]} ${className}`} style={style} onClick={onClick}>
      {children}
    </button>
  );
};

// ── Badge ─────────────────────────────────────────────────────────
export const LevelBadge = ({ level }) => {
  const c = levelColor(level);
  return (
    <span style={{ background: c.bg, color: c.text, border: `1px solid ${c.badge}` }}
      className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wide">
      <span style={{ width:5, height:5, borderRadius:'50%', background: c.dot, display:'inline-block' }} />
      {level}
    </span>
  );
};

export const Tag = ({ children, color = '#0B1E3D' }) => (
  <span style={{ background: `${color}12`, color, border: `1px solid ${color}30` }}
    className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wide">
    {children}
  </span>
);

// ── Card ──────────────────────────────────────────────────────────
export const Card = ({ children, className = '', hover = true, style = {} }) => (
  <div
    style={style}
    className={`bg-white border border-[#E2E8F0] rounded-2xl ${hover ? 'transition-all duration-200 hover:shadow-lg hover:border-[rgba(198,167,94,0.3)]' : ''} ${className}`}>
    {children}
  </div>
);

export const CardHeader = ({ title, sub, action, icon }) => (
  <div className="flex items-start justify-between px-5 pt-5 pb-0">
    <div className="flex items-center gap-2">
      {icon && <span className="text-lg">{icon}</span>}
      <div>
        <div className="text-sm font-bold text-[#0F172A] font-[Playfair_Display]">{title}</div>
        {sub && <div className="text-xs text-[#64748B] mt-0.5">{sub}</div>}
      </div>
    </div>
    {action && <div>{action}</div>}
  </div>
);

// ── Score Ring ────────────────────────────────────────────────────
export const ScoreRing = ({ score, size = 44 }) => {
  const c = score >= 8 ? '#EF4444' : score >= 6 ? '#F59E0B' : '#10B981';
  return (
    <div style={{ width: size, height: size, borderRadius: '50%', background: `${c}18`, border: `2px solid ${c}40`, display:'flex', alignItems:'center', justifyContent:'center', flexShrink: 0 }}>
      <span style={{ fontFamily:'IBM Plex Mono', fontSize: size * 0.28, fontWeight: 700, color: c }}>{score}</span>
    </div>
  );
};

// ── SHAP Bar ──────────────────────────────────────────────────────
export const SHAPBar = ({ label, value, maxValue = 0.5, color = '#C6A75E' }) => (
  <div className="flex items-center gap-2 mb-2">
    <span className="text-[11px] text-[#64748B] w-36 flex-shrink-0">{label}</span>
    <div className="flex-1 h-1.5 bg-[#F0F4F8] rounded-full overflow-hidden">
      <div style={{ width: `${(value / maxValue) * 100}%`, background: color }} className="h-full rounded-full transition-all duration-700" />
    </div>
    <span style={{ fontFamily:'IBM Plex Mono', color }} className="text-[10px] font-semibold w-10 text-right">+{value}</span>
  </div>
);

// ── Confidence Bar ────────────────────────────────────────────────
export const ConfBar = ({ label, value, color = '#C6A75E' }) => (
  <div className="mb-3">
    <div className="flex justify-between mb-1">
      <span className="text-xs text-[#64748B]">{label}</span>
      <span style={{ fontFamily:'IBM Plex Mono', color }} className="text-xs font-semibold">{value}%</span>
    </div>
    <div className="h-1.5 bg-[#F0F4F8] rounded-full overflow-hidden">
      <div style={{ width:`${value}%`, background:`linear-gradient(90deg, ${color}, #F59E0B)` }} className="h-full rounded-full transition-all duration-700" />
    </div>
  </div>
);

// ── Toast ─────────────────────────────────────────────────────────
export const Toast = ({ toast }) => {
  if (!toast) return null;
  const colors = { success:'#10B981', error:'#EF4444', info:'#C6A75E', warning:'#F59E0B' };
  return (
    <div style={{ borderLeftColor: colors[toast.type] || '#C6A75E' }}
      className="fixed bottom-6 right-6 z-[200] bg-[#0B1E3D] text-white px-5 py-4 rounded-xl shadow-2xl flex items-center gap-3 text-sm border-l-4 animate-[slideUp_0.4s_ease] max-w-xs">
      <span>{toast.msg}</span>
    </div>
  );
};

// ── Stat Card ─────────────────────────────────────────────────────
export const StatCard = ({ icon, value, label, sub, trend, trendUp, iconBg = 'rgba(11,30,61,0.06)' }) => (
  <Card className="p-5">
    <div className="flex items-start justify-between mb-3">
      <div style={{ background: iconBg }} className="w-10 h-10 rounded-xl flex items-center justify-center text-lg flex-shrink-0">{icon}</div>
      {trend && (
        <span style={{ background: trendUp ? 'rgba(16,185,129,0.1)' : 'rgba(239,68,68,0.1)', color: trendUp ? '#10B981' : '#EF4444' }}
          className="text-[10px] font-bold px-2 py-0.5 rounded-full">{trend}</span>
      )}
    </div>
    <div style={{ fontFamily:'IBM Plex Mono' }} className="text-2xl font-semibold text-[#0F172A] mb-0.5">{value}</div>
    <div className="text-xs font-medium text-[#0F172A]">{label}</div>
    {sub && <div className="text-[11px] text-[#64748B] mt-0.5">{sub}</div>}
  </Card>
);

// ── Modal Overlay ─────────────────────────────────────────────────
export const Modal = ({ open, onClose, children, maxW = 'max-w-lg' }) => {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[100] bg-[rgba(7,15,31,0.8)] backdrop-blur-sm flex items-center justify-center p-4"
      onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className={`bg-white rounded-2xl shadow-2xl w-full ${maxW} relative animate-[scaleIn_0.3s_ease]`}>
        <button onClick={onClose} className="absolute top-4 right-4 w-8 h-8 rounded-lg bg-[#F0F4F8] border border-[#E2E8F0] flex items-center justify-center text-sm text-[#64748B] hover:text-red-500 cursor-pointer">✕</button>
        {children}
      </div>
    </div>
  );
};

// ── Fake Bar Chart ─────────────────────────────────────────────────
export const MiniBarChart = ({ data, height = 80 }) => {
  const max = Math.max(...data.map(d => d.value));
  return (
    <div className="flex items-end gap-1.5" style={{ height }}>
      {data.map((d, i) => (
        <div key={i} className="flex-1 flex flex-col items-center gap-1">
          <div style={{ height: `${(d.value / max) * (height - 20)}px`, background: d.color || 'linear-gradient(180deg,#C6A75E,rgba(198,167,94,0.4))' }}
            className="w-full rounded-t-md transition-all duration-700" />
          <span className="text-[9px] text-[#94A3B8]">{d.label}</span>
        </div>
      ))}
    </div>
  );
};

// ── Pipeline Step ─────────────────────────────────────────────────
export const PipelineStep = ({ step, label, active, done }) => (
  <div className="flex items-center gap-2">
    <div style={{
      width: 28, height: 28, borderRadius: '50%', flexShrink: 0,
      background: done ? 'linear-gradient(135deg,#10B981,#059669)' : active ? 'linear-gradient(135deg,#C6A75E,#F59E0B)' : 'rgba(11,30,61,0.06)',
      border: active ? '2px solid #C6A75E' : '2px solid transparent',
      display:'flex', alignItems:'center', justifyContent:'center',
      fontSize: 11, fontWeight: 700, color: done || active ? 'white' : '#94A3B8',
    }}>
      {done ? '✓' : step}
    </div>
    <span style={{ fontSize:11, color: active ? '#0F172A' : done ? '#10B981' : '#94A3B8', fontWeight: active ? 600 : 400 }}>{label}</span>
  </div>
);
