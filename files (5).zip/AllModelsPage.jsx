import React, { useState } from 'react';
import { useStore } from '../store/useStore';
import { AI_MODELS, DEPARTMENTS } from '../data/masterData';
import { Card, ConfBar, Btn } from '../components/ui';

export default function AllModelsPage() {
  const { setPage, setActiveModel, showToast } = useStore();
  const [filterDept, setFilterDept] = useState('all');
  const [search, setSearch] = useState('');

  const models = Object.values(AI_MODELS).filter(m => {
    const deptMatch = filterDept === 'all' || m.dept === filterDept || (m.also && m.also.includes(filterDept));
    const searchMatch = !search || m.name.toLowerCase().includes(search.toLowerCase()) || m.algorithm.toLowerCase().includes(search.toLowerCase());
    return deptMatch && searchMatch;
  });

  return (
    <div style={{ padding:'2rem', maxWidth:1200, margin:'0 auto' }}>
      {/* Header */}
      <div style={{ marginBottom:'2rem' }}>
        <div style={{ fontSize:'0.6875rem', fontWeight:700, letterSpacing:'0.1em', textTransform:'uppercase', color:'#C6A75E', marginBottom:'0.375rem' }}>AI Intelligence</div>
        <div style={{ display:'flex', alignItems:'flex-end', justifyContent:'space-between', flexWrap:'wrap', gap:'1rem' }}>
          <div>
            <h1 style={{ fontFamily:'Playfair Display', fontSize:'1.75rem', fontWeight:700, color:'#0B1E3D', marginBottom:'0.375rem' }}>
              All AI <span style={{ color:'#C6A75E' }}>Models</span>
            </h1>
            <p style={{ fontSize:'0.875rem', color:'#64748B' }}>
              {Object.keys(AI_MODELS).length} models across {DEPARTMENTS.length} government departments
            </p>
          </div>
          <div style={{ display:'flex', gap:8, alignItems:'center' }}>
            <div style={{ display:'flex', alignItems:'center', gap:8, background:'white', border:'1px solid #E2E8F0', borderRadius:8, padding:'0.5rem 0.875rem' }}>
              <span>🔍</span>
              <input value={search} onChange={e => setSearch(e.target.value)}
                placeholder="Search models..."
                style={{ border:'none', outline:'none', fontSize:'0.8125rem', color:'#0F172A', background:'transparent', width:160, fontFamily:'Inter' }} />
            </div>
            <Btn variant="gold" size="sm" onClick={() => showToast('📥 Exporting model registry...')}>📥 Export</Btn>
          </div>
        </div>
      </div>

      {/* Summary stats */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:'1rem', marginBottom:'2rem' }}>
        {[
          ['🤖', Object.keys(AI_MODELS).length, 'Total Models', 'rgba(11,30,61,0.06)'],
          ['✅', Math.round(Object.values(AI_MODELS).reduce((a,m)=>a+m.accuracy,0)/Object.keys(AI_MODELS).length), 'Avg Accuracy %', 'rgba(16,185,129,0.08)'],
          ['📊', Object.values(AI_MODELS).reduce((a,m)=>a + parseInt(m.trainingRecords.replace(/\D+/g,'') || 0), 0).toLocaleString() + '+', 'Training Records', 'rgba(198,167,94,0.1)'],
          ['🏛️', DEPARTMENTS.length, 'Departments', 'rgba(79,70,229,0.08)'],
        ].map(([icon, val, label, bg]) => (
          <div key={label} style={{ background:'white', border:'1px solid #E2E8F0', borderRadius:14, padding:'1.125rem', display:'flex', gap:10, alignItems:'center' }}>
            <div style={{ width:40, height:40, borderRadius:10, background:bg, display:'flex', alignItems:'center', justifyContent:'center', fontSize:'1.125rem', flexShrink:0 }}>{icon}</div>
            <div>
              <div style={{ fontFamily:'IBM Plex Mono', fontSize:'1.25rem', fontWeight:700, color:'#0B1E3D' }}>{val}</div>
              <div style={{ fontSize:'0.6875rem', color:'#94A3B8' }}>{label}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Dept filter */}
      <div style={{ display:'flex', gap:6, flexWrap:'wrap', marginBottom:'1.5rem' }}>
        <button onClick={() => setFilterDept('all')} style={{
          padding:'5px 14px', borderRadius:7, fontSize:'0.75rem', fontWeight:600,
          border: filterDept==='all' ? 'none' : '1.5px solid #E2E8F0',
          background: filterDept==='all' ? 'linear-gradient(135deg,#0B1E3D,#1A3A6E)' : 'transparent',
          color: filterDept==='all' ? 'white' : '#64748B', cursor:'pointer',
        }}>All Models ({Object.keys(AI_MODELS).length})</button>
        {DEPARTMENTS.map(d => {
          const count = Object.values(AI_MODELS).filter(m => m.dept === d.id || (m.also && m.also.includes(d.id))).length;
          return (
            <button key={d.id} onClick={() => setFilterDept(d.id)} style={{
              padding:'5px 12px', borderRadius:7, fontSize:'0.75rem', fontWeight:600,
              border: filterDept===d.id ? 'none' : `1.5px solid ${d.border}`,
              background: filterDept===d.id ? d.color : 'transparent',
              color: filterDept===d.id ? 'white' : d.color, cursor:'pointer',
            }}>
              {d.icon} {d.shortName} ({count})
            </button>
          );
        })}
      </div>

      {/* Models grid */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(300px,1fr))', gap:'1.25rem' }}>
        {models.map(model => {
          const dept = DEPARTMENTS.find(d => d.id === model.dept);
          const modelColor = model.color || (dept?.color || '#C6A75E');
          return (
            <div key={model.id}
              style={{ background:'white', border:'1px solid #E2E8F0', borderRadius:14, overflow:'hidden', cursor:'pointer', transition:'all 0.2s' }}
              onClick={() => { setActiveModel(model.id); setPage('model_' + model.id); }}
              onMouseEnter={e => { e.currentTarget.style.boxShadow='0 8px 24px rgba(11,30,61,0.1)'; e.currentTarget.style.borderColor='rgba(198,167,94,0.3)'; e.currentTarget.style.transform='translateY(-2px)'; }}
              onMouseLeave={e => { e.currentTarget.style.boxShadow=''; e.currentTarget.style.borderColor='#E2E8F0'; e.currentTarget.style.transform=''; }}>

              <div style={{ height:3, background: modelColor }} />
              <div style={{ padding:'1.25rem' }}>
                <div style={{ display:'flex', gap:10, marginBottom:'0.875rem' }}>
                  <div style={{ width:44, height:44, borderRadius:12, background:`${modelColor}18`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:'1.375rem', flexShrink:0 }}>{model.icon}</div>
                  <div>
                    <div style={{ fontSize:'0.9375rem', fontWeight:700, color:'#0F172A', fontFamily:'Playfair Display', lineHeight:1.2 }}>{model.name}</div>
                    <div style={{ fontSize:'0.6875rem', color:'#64748B', marginTop:2 }}>{model.algorithm}</div>
                  </div>
                </div>

                <p style={{ fontSize:'0.8125rem', color:'#64748B', lineHeight:1.6, marginBottom:'0.875rem' }}>{model.description}</p>

                {/* Badges */}
                <div style={{ display:'flex', gap:5, flexWrap:'wrap', marginBottom:'0.875rem' }}>
                  <span style={{ fontSize:'0.6rem', padding:'2px 8px', borderRadius:100, background:'rgba(16,185,129,0.08)', color:'#10B981', fontWeight:700, border:'1px solid rgba(16,185,129,0.2)' }}>✓ {model.accuracy}%</span>
                  <span style={{ fontSize:'0.6rem', padding:'2px 8px', borderRadius:100, background:'rgba(11,30,61,0.05)', color:'#64748B', fontWeight:600 }}>{model.trainingRecords}</span>
                  <span style={{ fontSize:'0.6rem', padding:'2px 8px', borderRadius:100, background:`${modelColor}12`, color: modelColor, fontWeight:700 }}>{model.version}</span>
                  {dept && <span style={{ fontSize:'0.6rem', padding:'2px 8px', borderRadius:100, background: dept.bg, color: dept.color, fontWeight:700, border:`1px solid ${dept.border}` }}>{dept.icon} {dept.shortName}</span>}
                  {model.also && model.also.slice(0,1).map(a => {
                    const ad = DEPARTMENTS.find(d => d.id === a);
                    return ad ? <span key={a} style={{ fontSize:'0.6rem', padding:'2px 8px', borderRadius:100, background: ad.bg, color: ad.color, fontWeight:700, border:`1px solid ${ad.border}` }}>{ad.icon} {ad.shortName}</span> : null;
                  })}
                </div>

                <ConfBar label="Model Confidence" value={model.accuracy} color={modelColor} />

                {/* Features preview */}
                <div style={{ display:'flex', gap:4, flexWrap:'wrap', marginTop:'-0.25rem' }}>
                  {model.features.slice(0,4).map(f => (
                    <span key={f} style={{ fontSize:'0.5625rem', padding:'1px 6px', borderRadius:100, background:'rgba(11,30,61,0.04)', color:'#64748B', fontWeight:500 }}>{f}</span>
                  ))}
                  {model.features.length > 4 && <span style={{ fontSize:'0.5625rem', padding:'1px 6px', borderRadius:100, background:'rgba(11,30,61,0.04)', color:'#94A3B8' }}>+{model.features.length-4}</span>}
                </div>

                <div style={{ textAlign:'right', marginTop:'0.75rem', paddingTop:'0.75rem', borderTop:'1px solid #F0F4F8' }}>
                  <button style={{ fontSize:'0.75rem', color:'#C6A75E', fontWeight:700, background:'none', border:'none', cursor:'pointer' }}>
                    View Full Model →
                  </button>
                </div>
              </div>
            </div>
          );
        })}

        {models.length === 0 && (
          <div style={{ gridColumn:'1/-1', padding:'4rem', textAlign:'center', background:'white', borderRadius:14, border:'1px solid #E2E8F0' }}>
            <div style={{ fontSize:'2rem', marginBottom:'0.75rem' }}>🔍</div>
            <p style={{ color:'#64748B' }}>No models found for this filter</p>
          </div>
        )}
      </div>
    </div>
  );
}
