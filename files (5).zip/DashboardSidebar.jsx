import React from 'react';
import { useStore } from '../../store/useStore';
import { DEPARTMENTS } from '../../data/masterData';

const NAV = [
  { id:'overview', icon:'📊', label:'Overview' },
  { id:'ai', icon:'🧠', label:'AI Predictions', badge:3 },
  { id:'queue', icon:'⚡', label:'Priority Queue', badge:14 },
  { id:'map', icon:'📍', label:'Geo Map' },
  { id:'analytics', icon:'📈', label:'Analytics' },
  { id:'audit', icon:'📋', label:'Audit Trail' },
  { id:'community', icon:'💬', label:'Community', badge:3 },
  { id:'alerts', icon:'🔔', label:'Alerts', badge:5 },
];

export default function DashboardSidebar({ activePage, onNavigate }) {
  const { isGovt, userDept, setPage } = useStore();
  const dept = DEPARTMENTS.find(d => d.id === userDept);

  return (
    <aside style={{
      width: 240, minHeight: '100vh', background: '#0B1E3D',
      display: 'flex', flexDirection: 'column', flexShrink: 0,
      borderRight: '1px solid rgba(255,255,255,0.05)',
      position: 'sticky', top: 0,
    }}>
      {/* Brand */}
      <div style={{ padding:'1.25rem 1rem', borderBottom:'1px solid rgba(255,255,255,0.06)' }}>
        <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:'0.875rem' }}>
          <div style={{ width:32, height:32, borderRadius:8, background:'linear-gradient(135deg,#C6A75E,#F59E0B)', display:'flex', alignItems:'center', justifyContent:'center', fontFamily:'Playfair Display', fontWeight:700, color:'#0B1E3D', fontSize:'0.875rem' }}>N</div>
          <div>
            <div style={{ fontFamily:'Playfair Display', fontSize:'0.875rem', fontWeight:700, color:'white' }}>NETRAVAAH</div>
            <div style={{ fontSize:'0.5625rem', color:'rgba(255,255,255,0.3)', textTransform:'uppercase', letterSpacing:'0.1em' }}>Governance OS</div>
          </div>
        </div>
        {/* User card */}
        <div style={{ background:'rgba(255,255,255,0.04)', border:'1px solid rgba(255,255,255,0.07)', borderRadius:10, padding:'0.75rem', display:'flex', alignItems:'center', gap:8 }}>
          <div style={{ width:30, height:30, borderRadius:'50%', background:'linear-gradient(135deg,#C6A75E,#F59E0B)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'0.6875rem', fontWeight:700, color:'#0B1E3D', flexShrink:0 }}>
            {dept ? dept.icon : '🏛️'}
          </div>
          <div style={{ flex:1, minWidth:0 }}>
            <div style={{ fontSize:'0.75rem', fontWeight:600, color:'white', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>
              {dept ? dept.shortName : 'All Departments'}
            </div>
            <div style={{ fontSize:'0.5625rem', color:'rgba(255,255,255,0.35)', marginTop:1 }}>
              {isGovt ? 'Govt Official' : 'Citizen'} · Verified
            </div>
          </div>
          <div style={{ width:7, height:7, borderRadius:'50%', background:'#10B981', boxShadow:'0 0 6px #10B981' }} />
        </div>
      </div>

      {/* Nav */}
      <nav style={{ flex:1, padding:'0.75rem', overflowY:'auto' }}>
        <div style={{ fontSize:'0.5625rem', fontWeight:700, letterSpacing:'0.1em', textTransform:'uppercase', color:'rgba(255,255,255,0.25)', padding:'0 0.5rem', marginBottom:'0.375rem', marginTop:'0.5rem' }}>Main</div>
        {NAV.slice(0,3).map(item => (
          <NavItem key={item.id} item={item} active={activePage === item.id} onClick={() => onNavigate(item.id)} />
        ))}

        <div style={{ fontSize:'0.5625rem', fontWeight:700, letterSpacing:'0.1em', textTransform:'uppercase', color:'rgba(255,255,255,0.25)', padding:'0 0.5rem', marginBottom:'0.375rem', marginTop:'1rem' }}>Operations</div>
        {NAV.slice(3,6).map(item => (
          <NavItem key={item.id} item={item} active={activePage === item.id} onClick={() => onNavigate(item.id)} />
        ))}

        <div style={{ fontSize:'0.5625rem', fontWeight:700, letterSpacing:'0.1em', textTransform:'uppercase', color:'rgba(255,255,255,0.25)', padding:'0 0.5rem', marginBottom:'0.375rem', marginTop:'1rem' }}>Intelligence</div>
        {NAV.slice(6).map(item => (
          <NavItem key={item.id} item={item} active={activePage === item.id} onClick={() => onNavigate(item.id)} />
        ))}

        {/* Departments section */}
        <div style={{ fontSize:'0.5625rem', fontWeight:700, letterSpacing:'0.1em', textTransform:'uppercase', color:'rgba(255,255,255,0.25)', padding:'0 0.5rem', marginBottom:'0.375rem', marginTop:'1rem' }}>Departments</div>
        <NavItem item={{ id:'dept_all', icon:'🏛️', label:'All Departments' }} active={activePage === 'dept_all'} onClick={() => setPage('departments')} />
        {dept && (
          <NavItem item={{ id:'dept_mine', icon: dept.icon, label: dept.shortName }} active={false} onClick={() => setPage('dept_' + dept.id)} />
        )}
        <NavItem item={{ id:'models_all', icon:'🤖', label:'AI Models' }} active={activePage === 'models_all'} onClick={() => setPage('models')} />

        <div style={{ marginTop:'0.5rem', borderTop:'1px solid rgba(255,255,255,0.06)', paddingTop:'0.5rem' }}>
          <NavItem item={{ id:'back', icon:'↩', label:'Back to Home' }} active={false} onClick={() => setPage('landing')} />
        </div>
      </nav>

      <div style={{ padding:'0.75rem 1rem', borderTop:'1px solid rgba(255,255,255,0.06)', display:'flex', alignItems:'center', gap:8 }}>
        <span style={{ fontSize:'0.625rem', color:'rgba(255,255,255,0.25)' }}>🔒 Secure Gov Network</span>
        <span style={{ marginLeft:'auto', fontFamily:'IBM Plex Mono', fontSize:'0.5625rem', color:'rgba(255,255,255,0.25)', background:'rgba(255,255,255,0.05)', padding:'2px 6px', borderRadius:4 }}>v2.4.1</span>
      </div>
    </aside>
  );
}

function NavItem({ item, active, onClick }) {
  return (
    <button onClick={onClick} style={{
      display:'flex', alignItems:'center', gap:10,
      padding:'0.5625rem 0.75rem', borderRadius:8, width:'100%',
      fontSize:'0.8125rem', fontWeight:500, cursor:'pointer', border:'none',
      background: active ? 'rgba(198,167,94,0.12)' : 'transparent',
      color: active ? '#C6A75E' : 'rgba(255,255,255,0.5)',
      marginBottom:1, transition:'all 0.15s', textAlign:'left',
    }}>
      <span style={{ fontSize:'0.875rem', width:18, flexShrink:0 }}>{item.icon}</span>
      <span style={{ flex:1 }}>{item.label}</span>
      {item.badge && (
        <span style={{ background:'#EF4444', color:'white', fontSize:'0.5rem', fontWeight:700, padding:'1px 5px', borderRadius:100, minWidth:16, textAlign:'center' }}>{item.badge}</span>
      )}
    </button>
  );
}
