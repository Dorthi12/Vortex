import React, { useState, useEffect } from 'react';
import { useStore } from '../../store/useStore';
import { Btn } from '../ui';

export default function Navbar({ onLogin }) {
  const { user, isGovt, logout, setPage, activePage, showToast } = useStore();
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const h = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', h);
    return () => window.removeEventListener('scroll', h);
  }, []);

  return (
    <nav style={{
      background: scrolled ? 'rgba(11,30,61,0.97)' : 'rgba(11,30,61,0.92)',
      borderBottom: '1px solid rgba(198,167,94,0.2)',
      backdropFilter: 'blur(20px)',
      position: 'fixed', top: 0, left: 0, right: 0, zIndex: 90,
      height: 60, display: 'flex', alignItems: 'center',
      padding: '0 1.5rem', gap: '1rem', transition: 'all 0.3s',
    }}>
      {/* Logo */}
      <button onClick={() => setPage('landing')} style={{ display:'flex', alignItems:'center', gap:10, background:'none', border:'none', cursor:'pointer' }}>
        <div style={{ width:34, height:34, borderRadius:8, background:'linear-gradient(135deg,#C6A75E,#F59E0B)', display:'flex', alignItems:'center', justifyContent:'center', fontFamily:'Playfair Display', fontWeight:700, color:'#0B1E3D', fontSize:15, boxShadow:'0 4px 12px rgba(198,167,94,0.3)' }}>N</div>
        <span style={{ fontFamily:'Playfair Display', fontSize:'1rem', fontWeight:700, color:'white' }}>NETRA<span style={{ color:'#C6A75E' }}>VAAH</span></span>
      </button>

      {/* Nav links */}
      <div style={{ display:'flex', gap:'1.5rem', marginLeft:'1rem', flex:1 }}>
        {[
          ['landing','Home'],
          ['community','Community'],
          ['departments','Departments'],
          ['models','AI Models'],
          ['report','Report Issue'],
          ['dashboard','Dashboard'],
        ].map(([page, label]) => (
          <button key={page} onClick={() => setPage(page)} style={{
            background:'none', border:'none', cursor:'pointer',
            fontSize:'0.8125rem', fontWeight:500,
            color: activePage === page ? '#C6A75E' : 'rgba(255,255,255,0.6)',
            transition:'color 0.2s',
          }}>{label}</button>
        ))}
      </div>

      {/* Right */}
      <div style={{ display:'flex', alignItems:'center', gap:8 }}>
        {user ? (
          <>
            <div style={{ display:'flex', alignItems:'center', gap:8, padding:'4px 12px', background:'rgba(255,255,255,0.06)', borderRadius:8, border:'1px solid rgba(255,255,255,0.1)' }}>
              <div style={{ width:28, height:28, borderRadius:'50%', background:'linear-gradient(135deg,#C6A75E,#F59E0B)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'0.75rem', fontWeight:700, color:'#0B1E3D' }}>
                {user.name.split(' ').map(n=>n[0]).join('')}
              </div>
              <div>
                <div style={{ fontSize:'0.75rem', fontWeight:600, color:'white' }}>{user.name}</div>
                <div style={{ fontSize:'0.5625rem', color:'rgba(255,255,255,0.4)', textTransform:'uppercase', letterSpacing:'0.05em' }}>
                  {isGovt ? '🏛️ Govt Official' : '👤 Citizen'}
                </div>
              </div>
            </div>
            <Btn variant="outline" size="sm" onClick={() => { logout(); setPage('landing'); }} style={{ color:'rgba(255,255,255,0.5)', borderColor:'rgba(255,255,255,0.15)' }}>Sign Out</Btn>
          </>
        ) : (
          <>
            <Btn variant="outline" size="sm" onClick={() => onLogin('login')} style={{ color:'rgba(255,255,255,0.7)', borderColor:'rgba(198,167,94,0.4)' }}>Sign In</Btn>
            <Btn variant="gold" size="sm" onClick={() => onLogin('signup')}>Get Started</Btn>
          </>
        )}
      </div>
    </nav>
  );
}
