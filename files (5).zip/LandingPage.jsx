import React, { useEffect, useRef } from 'react';
import { useStore } from '../../store/useStore';
import { Btn, Card } from '../ui';

const FEATURES = [
  { icon:'📡', title:'Citizen Signal Intelligence', desc:'Real-time issue intake from citizens, auto-classified, geo-tagged, and routed to departments via AI triage.', tag:'🤖 AI-Powered' },
  { icon:'⚡', title:'AI-Driven Prioritization', desc:'ML models rank issues by urgency, impact, recurrence, and cross-correlation with satellite and sensor data.', tag:'📈 Priority Score' },
  { icon:'📍', title:'Geo-Verified Execution', desc:'Field officers upload before/after photos with GPS timestamps. Every action is permanently audited.', tag:'🔒 Verified' },
  { icon:'🧠', title:'Sentiment Monitoring', desc:'NLP models scan community posts and signals to detect civic unrest before it escalates.', tag:'💬 NLP' },
  { icon:'🔗', title:'Cross-Department Correlation', desc:'Smart routing connects flood reports to drainage, crop failures to agriculture — automatically.', tag:'🏛️ Multi-Dept' },
  { icon:'👑', title:'Leadership Intelligence', desc:'Collectors and CMOs get real-time dashboards with predictive AI and SHAP-explained models.', tag:'📊 Executive' },
];

const STEPS = [
  { n:'01', icon:'📡', title:'Citizen Reports Issue', desc:'Via app, web or voice. GPS + media evidence captured automatically.' },
  { n:'02', icon:'🧠', title:'AI Classification', desc:'NLP classifies, prioritizes, generates SHAP-explained reasoning for each issue.' },
  { n:'03', icon:'🏛️', title:'Department Assignment', desc:'Smart routing assigns to the right dept with SLA timers and escalation rules.' },
  { n:'04', icon:'🔧', title:'Field Execution', desc:'Officers upload geo-verified before/after evidence. Timestamped and auditable.' },
  { n:'05', icon:'✅', title:'Citizen Verification', desc:'Citizens confirm resolution. Satisfaction feeds back into dept performance.' },
  { n:'06', icon:'📊', title:'Intelligence Loop', desc:'Patterns, predictions and reports delivered to leadership every 24 hours.' },
];

export default function LandingPage({ onLogin }) {
  const { setPage, isGovt, showToast } = useStore();
  const statsRef = useRef();

  return (
    <div style={{ background:'#F0F4F8' }}>
      {/* HERO */}
      <section style={{ minHeight:'100vh', background:'#0B1E3D', position:'relative', overflow:'hidden', display:'flex', alignItems:'center', paddingTop:60 }}>
        {/* Grid bg */}
        <div style={{ position:'absolute', inset:0, backgroundImage:'linear-gradient(rgba(198,167,94,0.04) 1px,transparent 1px),linear-gradient(90deg,rgba(198,167,94,0.04) 1px,transparent 1px)', backgroundSize:'60px 60px' }} />
        <div style={{ position:'absolute', inset:0, background:'radial-gradient(ellipse at 20% 50%,rgba(26,58,110,0.8),transparent 60%),radial-gradient(ellipse at 80% 20%,rgba(198,167,94,0.06),transparent 50%)' }} />

        {/* Map SVG */}
        <svg style={{ position:'absolute', right:'-5%', top:'50%', transform:'translateY(-50%)', width:'52%', opacity:0.3, pointerEvents:'none' }} viewBox="0 0 500 600">
          {[['230','180','310','250'],['310','250','280','350'],['280','350','200','400'],['200','400','180','480'],['230','180','160','280'],['310','250','370','320'],['370','320','350','420'],['280','120','310','250'],['400','200','370','320']].map(([x1,y1,x2,y2],i) => (
            <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke="rgba(198,167,94,0.3)" strokeWidth="1" />
          ))}
          {[['230','180','Delhi'],['310','250','Lucknow'],['280','350','Mumbai'],['200','400','Bengaluru'],['180','480','Chennai'],['280','120','Chandigarh'],['400','200','Kolkata']].map(([cx,cy,name],i) => (
            <g key={i}>
              <circle cx={cx} cy={cy} r="5" fill="#C6A75E" style={{ animation:`pulse 3s ease-in-out ${i*0.5}s infinite` }} />
              <text x={parseInt(cx)+10} y={parseInt(cy)+4} fill="rgba(198,167,94,0.6)" fontSize="8" fontFamily="IBM Plex Mono">{name}</text>
            </g>
          ))}
        </svg>

        <div style={{ maxWidth:1200, margin:'0 auto', padding:'5rem 2rem', width:'100%', position:'relative', zIndex:2 }}>
          <div style={{ display:'inline-flex', alignItems:'center', gap:8, background:'rgba(198,167,94,0.12)', border:'1px solid rgba(198,167,94,0.3)', borderRadius:100, padding:'6px 16px', marginBottom:'2rem' }}>
            <span style={{ width:6, height:6, borderRadius:'50%', background:'#F59E0B', display:'inline-block', animation:'blink 2s infinite' }} />
            <span style={{ fontSize:'0.6875rem', fontWeight:700, letterSpacing:'0.1em', textTransform:'uppercase', color:'#C6A75E' }}>AI-Powered Governance Intelligence Platform</span>
          </div>

          <h1 style={{ fontFamily:'Playfair Display', fontSize:'clamp(2.5rem,6vw,4.5rem)', fontWeight:800, lineHeight:1.08, color:'white', marginBottom:'1.5rem' }}>
            India's Future<br />
            <span style={{ background:'linear-gradient(135deg,#C6A75E,#F59E0B)', WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent' }}>Governance OS</span><br />
            is Here
          </h1>

          <p style={{ fontSize:'1.0625rem', color:'rgba(255,255,255,0.6)', maxWidth:540, lineHeight:1.75, marginBottom:'2.5rem' }}>
            NETRAVAAH empowers citizens to signal civic issues and enables leaders to act proactively — powered by AI models for every department of the Government of India.
          </p>

          <div style={{ display:'flex', gap:'0.875rem', flexWrap:'wrap', marginBottom:'4rem' }}>
            <Btn variant="gold" size="lg" onClick={() => onLogin('signup')}>🚨 Report an Issue</Btn>
            <Btn size="lg" onClick={() => setPage('community')} style={{ background:'transparent', border:'1.5px solid rgba(198,167,94,0.5)', color:'#C6A75E' }}>🌐 Explore Community</Btn>
            <Btn size="lg" onClick={() => setPage('dashboard')} style={{ background:'rgba(255,255,255,0.05)', border:'1.5px solid rgba(255,255,255,0.12)', color:'rgba(255,255,255,0.8)' }}>📊 View Dashboard</Btn>
          </div>

          {/* Stats */}
          <div style={{ display:'flex', gap:'3rem', flexWrap:'wrap', paddingTop:'2rem', borderTop:'1px solid rgba(255,255,255,0.08)' }}>
            {[['2,847','Issues Resolved'],['142','Districts Active'],['94%','AI Accuracy'],['10','Dept Models']].map(([val,label]) => (
              <div key={label}>
                <div style={{ fontFamily:'IBM Plex Mono', fontSize:'2rem', fontWeight:600, color:'#C6A75E' }}>{val}</div>
                <div style={{ fontSize:'0.6875rem', color:'rgba(255,255,255,0.4)', textTransform:'uppercase', letterSpacing:'0.06em', marginTop:2 }}>{label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FEATURES */}
      <section style={{ padding:'6rem 2rem', background:'#F0F4F8' }}>
        <div style={{ maxWidth:1200, margin:'0 auto' }}>
          <div style={{ textAlign:'center', marginBottom:'4rem' }}>
            <div style={{ fontSize:'0.6875rem', fontWeight:700, letterSpacing:'0.12em', textTransform:'uppercase', color:'#C6A75E', marginBottom:'0.75rem', display:'flex', alignItems:'center', justifyContent:'center', gap:8 }}>Platform Capabilities</div>
            <h2 style={{ fontFamily:'Playfair Display', fontSize:'clamp(1.75rem,4vw,2.5rem)', fontWeight:700, color:'#0B1E3D', marginBottom:'0.75rem' }}>Intelligence at Every Layer</h2>
            <p style={{ color:'#64748B', maxWidth:500, margin:'0 auto', lineHeight:1.7 }}>From citizen signal collection to predictive AI across all 10 government departments.</p>
          </div>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(320px,1fr))', gap:'1.25rem' }}>
            {FEATURES.map((f, i) => (
              <Card key={i} className="p-6 group relative overflow-hidden">
                <div style={{ position:'absolute', top:0, left:0, right:0, height:3, background:'linear-gradient(90deg,#C6A75E,#F59E0B)', transform:'scaleX(0)', transformOrigin:'left', transition:'transform 0.3s' }} className="group-hover:scale-x-100" />
                <div style={{ width:44, height:44, borderRadius:12, background:'linear-gradient(135deg,rgba(11,30,61,0.06),rgba(198,167,94,0.1))', border:'1px solid rgba(198,167,94,0.2)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'1.25rem', marginBottom:'1rem' }}>{f.icon}</div>
                <div style={{ fontFamily:'Playfair Display', fontSize:'1rem', fontWeight:600, color:'#0B1E3D', marginBottom:'0.5rem' }}>{f.title}</div>
                <p style={{ fontSize:'0.875rem', color:'#64748B', lineHeight:1.65, marginBottom:'1rem' }}>{f.desc}</p>
                <span style={{ fontSize:'0.6rem', fontWeight:700, padding:'3px 8px', borderRadius:100, background:'rgba(198,167,94,0.08)', color:'#C6A75E', border:'1px solid rgba(198,167,94,0.2)' }}>{f.tag}</span>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* DEPARTMENTS SHOWCASE */}
      <section style={{ padding:'5rem 2rem', background:'white' }}>
        <div style={{ maxWidth:1200, margin:'0 auto' }}>
          <div style={{ textAlign:'center', marginBottom:'3rem' }}>
            <div style={{ fontSize:'0.6875rem', fontWeight:700, letterSpacing:'0.12em', textTransform:'uppercase', color:'#C6A75E', marginBottom:'0.75rem' }}>AI Models for Every Department</div>
            <h2 style={{ fontFamily:'Playfair Display', fontSize:'clamp(1.75rem,4vw,2.5rem)', fontWeight:700, color:'#0B1E3D' }}>10 Government Ministries.<br/>Personalized AI Intelligence.</h2>
          </div>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(200px,1fr))', gap:'1rem' }}>
            {[
              ['🌾','Agriculture','6 AI Models','#16a34a'],
              ['🚨','NDMA','5 AI Models','#dc2626'],
              ['💧','Jal Shakti','5 AI Models','#0284c7'],
              ['🏥','Health','5 AI Models','#7c3aed'],
              ['🛣️','MoRTH','5 AI Models','#b45309'],
              ['⚡','Power','5 AI Models','#d97706'],
              ['🌿','MoEFCC','5 AI Models','#059669'],
              ['🏙️','Urban Dev','5 AI Models','#4f46e5'],
              ['🚂','Railways','5 AI Models','#0369a1'],
              ['💰','Finance','5 AI Models','#c6a75e'],
            ].map(([icon, name, models, color]) => (
              <button key={name} onClick={() => setPage('departments')} style={{
                background:'white', border:`1px solid ${color}22`, borderRadius:14,
                padding:'1.25rem', textAlign:'center', cursor:'pointer',
                transition:'all 0.2s', display:'flex', flexDirection:'column', alignItems:'center', gap:8,
              }}
              onMouseEnter={e => { e.currentTarget.style.borderColor=`${color}60`; e.currentTarget.style.transform='translateY(-3px)'; e.currentTarget.style.boxShadow=`0 8px 24px ${color}18`; }}
              onMouseLeave={e => { e.currentTarget.style.borderColor=`${color}22`; e.currentTarget.style.transform=''; e.currentTarget.style.boxShadow=''; }}>
                <div style={{ width:44, height:44, borderRadius:12, background:`${color}12`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:'1.375rem' }}>{icon}</div>
                <div style={{ fontSize:'0.8125rem', fontWeight:700, color:'#0F172A' }}>{name}</div>
                <div style={{ fontSize:'0.6875rem', color, fontWeight:600 }}>{models}</div>
              </button>
            ))}
          </div>
          <div style={{ textAlign:'center', marginTop:'2rem' }}>
            <Btn variant="primary" size="lg" onClick={() => setPage('departments')}>Explore All Departments →</Btn>
          </div>
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section style={{ padding:'6rem 2rem', background:'#0B1E3D' }}>
        <div style={{ maxWidth:1200, margin:'0 auto' }}>
          <div style={{ textAlign:'center', marginBottom:'3rem' }}>
            <h2 style={{ fontFamily:'Playfair Display', fontSize:'2.25rem', fontWeight:700, color:'white', marginBottom:'0.75rem' }}>From Signal to Resolution</h2>
            <p style={{ color:'rgba(255,255,255,0.5)', maxWidth:500, margin:'0 auto' }}>NETRAVAAH's AI pipeline transforms raw citizen inputs into government action.</p>
          </div>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(260px,1fr))', gap:'1.5rem' }}>
            {STEPS.map((s, i) => (
              <div key={i} style={{ padding:'1.75rem', border:'1px solid rgba(198,167,94,0.15)', borderRadius:16, background:'rgba(255,255,255,0.03)', position:'relative', transition:'all 0.3s' }}
                onMouseEnter={e => { e.currentTarget.style.borderColor='rgba(198,167,94,0.4)'; e.currentTarget.style.background='rgba(255,255,255,0.06)'; e.currentTarget.style.transform='translateY(-4px)'; }}
                onMouseLeave={e => { e.currentTarget.style.borderColor='rgba(198,167,94,0.15)'; e.currentTarget.style.background='rgba(255,255,255,0.03)'; e.currentTarget.style.transform=''; }}>
                <div style={{ fontFamily:'IBM Plex Mono', fontSize:'3rem', fontWeight:600, color:'rgba(198,167,94,0.12)', position:'absolute', top:'1.5rem', right:'1.5rem', lineHeight:1 }}>{s.n}</div>
                <div style={{ fontSize:'1.5rem', marginBottom:'0.875rem' }}>{s.icon}</div>
                <div style={{ fontFamily:'Playfair Display', fontSize:'0.9375rem', fontWeight:600, color:'white', marginBottom:'0.5rem' }}>{s.title}</div>
                <p style={{ fontSize:'0.8125rem', color:'rgba(255,255,255,0.5)', lineHeight:1.65 }}>{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section style={{ padding:'7rem 2rem', background:'#0B1E3D', textAlign:'center', position:'relative', overflow:'hidden' }}>
        <div style={{ position:'absolute', inset:0, background:'radial-gradient(ellipse at 50% 0%,rgba(198,167,94,0.1),transparent 60%)' }} />
        <div style={{ position:'relative', zIndex:1, maxWidth:600, margin:'0 auto' }}>
          <div style={{ fontSize:'0.6875rem', fontWeight:700, letterSpacing:'0.12em', textTransform:'uppercase', color:'#C6A75E', marginBottom:'1rem' }}>Join the Movement</div>
          <h2 style={{ fontFamily:'Playfair Display', fontSize:'2.5rem', fontWeight:700, color:'white', marginBottom:'1rem' }}>Be Part of India's<br/>Governance Revolution</h2>
          <p style={{ color:'rgba(255,255,255,0.5)', lineHeight:1.7, marginBottom:'2.5rem' }}>Whether citizen or leader — NETRAVAAH is your platform for transparent, accountable, AI-powered governance.</p>
          <div style={{ display:'flex', gap:'1rem', justifyContent:'center', flexWrap:'wrap' }}>
            <Btn variant="gold" size="lg" onClick={() => onLogin('signup')}>🏛️ Register as Citizen</Btn>
            <Btn size="lg" onClick={() => onLogin('official')} style={{ background:'transparent', border:'1.5px solid rgba(198,167,94,0.4)', color:'#C6A75E' }}>👑 Government Login</Btn>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer style={{ background:'#070F1F', padding:'3rem 2rem 1.5rem', borderTop:'1px solid rgba(255,255,255,0.05)' }}>
        <div style={{ maxWidth:1200, margin:'0 auto', display:'flex', justifyContent:'space-between', alignItems:'center', flexWrap:'wrap', gap:'1rem' }}>
          <div style={{ display:'flex', alignItems:'center', gap:10 }}>
            <div style={{ width:28, height:28, borderRadius:6, background:'linear-gradient(135deg,#C6A75E,#F59E0B)', display:'flex', alignItems:'center', justifyContent:'center', fontFamily:'Playfair Display', fontWeight:700, color:'#0B1E3D', fontSize:'0.75rem' }}>N</div>
            <span style={{ fontFamily:'Playfair Display', fontSize:'0.9375rem', fontWeight:700, color:'white' }}>NETRAVAAH</span>
          </div>
          <div style={{ fontSize:'0.6875rem', color:'rgba(255,255,255,0.25)' }}>
            © 2026 NETRAVAAH · A Digital Public Infrastructure Initiative · 🇮🇳 Made in India
          </div>
          <div style={{ fontFamily:'IBM Plex Mono', fontSize:'0.625rem', color:'rgba(198,167,94,0.5)' }}>v2.4.1-stable</div>
        </div>
      </footer>

      <style>{`
        @keyframes pulse { 0%,100%{opacity:0.4;r:5px} 50%{opacity:1;r:8px} }
        @keyframes blink { 0%,100%{opacity:1} 50%{opacity:0.3} }
      `}</style>
    </div>
  );
}
