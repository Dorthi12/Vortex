export const theme = {
  navy:       '#0B1E3D',
  navyLight:  '#132952',
  navyMid:    '#1A3A6E',
  gold:       '#C6A75E',
  saffron:    '#F59E0B',
  white:      '#FFFFFF',
  bg:         '#F0F4F8',
  border:     '#E2E8F0',
  text:       '#0F172A',
  muted:      '#64748B',
  success:    '#10B981',
  warning:    '#F59E0B',
  error:      '#EF4444',
};

export const levelColor = (level) => ({
  CRITICAL: { bg:'rgba(239,68,68,0.1)',  text:'#DC2626', dot:'#EF4444', badge:'rgba(239,68,68,0.15)' },
  HIGH:     { bg:'rgba(245,158,11,0.1)', text:'#D97706', dot:'#F59E0B', badge:'rgba(245,158,11,0.15)' },
  MEDIUM:   { bg:'rgba(16,185,129,0.08)',text:'#059669', dot:'#10B981', badge:'rgba(16,185,129,0.12)' },
  WATCH:    { bg:'rgba(100,116,139,0.08)',text:'#64748B',dot:'#94A3B8', badge:'rgba(100,116,139,0.1)' },
  NORMAL:   { bg:'rgba(100,116,139,0.06)',text:'#94A3B8',dot:'#CBD5E1', badge:'rgba(100,116,139,0.08)' },
}[level] || { bg:'rgba(100,116,139,0.06)', text:'#94A3B8', dot:'#CBD5E1', badge:'rgba(100,116,139,0.08)' });
