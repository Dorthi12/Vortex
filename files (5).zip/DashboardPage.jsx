import React, { useState } from 'react';
import { useStore } from '../../store/useStore';
import { ALL_REPORTS, DEPARTMENTS, AI_MODELS } from '../../data/masterData';
import { Card, CardHeader, LevelBadge, Btn, SHAPBar, ConfBar, ScoreRing, StatCard, MiniBarChart } from '../ui';
import DashboardSidebar from '../layout/DashboardSidebar';

export default function DashboardPage() {
  const { userDept, setPage, showToast, isGovt } = useStore();
  const [subPage, setSubPage] = useState('overview');
  const dept = DEPARTMENTS.find(d => d.id === userDept);
  const relevantReports = userDept ? ALL_REPORTS.filter(r => r.dept === userDept) : ALL_REPORTS;

  return (
    <div style={{ display:'flex', minHeight:'100vh', background:'#F0F4F8' }}>
      <DashboardSidebar activePage={subPage} onNavigate={setSubPage} />

      <div style={{ flex:1, display:'flex', flexDirection:'column', overflow:'hidden' }}>
        {/* Topbar */}
        <div style={{ background:'white', borderBottom:'1px solid #E2E8F0', padding:'0 1.75rem', height:60, display:'flex', alignItems:'center', gap:'1rem', position:'sticky', top:0, zIndex:30 }}>
          <div style={{ flex:1 }}>
            <span style={{ fontSize:'0.9375rem', fontWeight:700, color:'#0B1E3D', fontFamily:'Playfair Display' }}>
              {subPage === 'overview' ? 'Overview' : subPage === 'ai' ? 'AI Predictions' : subPage === 'queue' ? 'Priority Queue' : subPage.charAt(0).toUpperCase() + subPage.slice(1)}
            </span>
            <span style={{ fontSize:'0.75rem', color:'#94A3B8', marginLeft:8 }}>
              {dept ? dept.name : 'All Departments'}
            </span>
          </div>
          <div style={{ display:'flex', alignItems:'center', gap:8, background:'#F0F4F8', border:'1px solid #E2E8F0', borderRadius:8, padding:'0.5rem 0.875rem', width:220 }}>
            <span>🔍</span>
            <input placeholder="Search..." style={{ border:'none', background:'transparent', outline:'none', fontSize:'0.8125rem', fontFamily:'Inter', width:'100%' }} />
          </div>
          <div style={{ display:'flex', gap:8 }}>
            {[['🌐','Language'],['📥','Export'],['🔔','Alerts']].map(([icon, tip]) => (
              <button key={tip} onClick={() => showToast(`${icon} ${tip}`)} title={tip} style={{ width:36, height:36, borderRadius:8, background:'#F0F4F8', border:'1px solid #E2E8F0', display:'flex', alignItems:'center', justifyContent:'center', cursor:'pointer', fontSize:'0.9375rem', transition:'all 0.2s' }}>{icon}</button>
            ))}
          </div>
          <span style={{ fontFamily:'IBM Plex Mono', fontSize:'0.6875rem', color:'#94A3B8', whiteSpace:'nowrap' }}>SAT 14 MAR 2026</span>
        </div>

        {/* Page content */}
        <div style={{ flex:1, overflow:'auto', padding:'1.75rem' }}>
          {subPage === 'overview' && <OverviewPage dept={dept} reports={relevantReports} />}
          {subPage === 'ai' && <AIPredictionsPage dept={dept} reports={relevantReports} />}
          {subPage === 'queue' && <PriorityQueuePage reports={relevantReports} />}
          {subPage === 'map' && <MapPage />}
          {subPage === 'analytics' && <AnalyticsPage dept={dept} reports={relevantReports} />}
          {subPage === 'audit' && <AuditPage />}
          {subPage === 'alerts' && <AlertsPage reports={relevantReports} />}
          {subPage === 'community' && <CommunityRedirect />}
        </div>
      </div>
    </div>
  );
}

// ── Overview ──────────────────────────────────────────────────────
function OverviewPage({ dept, reports }) {
  const { showToast, setPage } = useStore();
  const criticals = reports.filter(r=>r.level==='CRITICAL').length;
  const resolved = dept ? dept.resolvedIssues : 1284;

  return (
    <div>
      <div style={{ display:'flex', alignItems:'flex-end', justifyContent:'space-between', marginBottom:'1.5rem', flexWrap:'wrap', gap:'1rem' }}>
        <div>
          <h1 style={{ fontFamily:'Playfair Display', fontSize:'1.375rem', fontWeight:700, color:'#0B1E3D' }}>
            Good Morning, <span style={{ color:'#C6A75E' }}>{dept ? dept.shortName + ' Officer' : 'Administrator'}</span> 🙏
          </h1>
          <div style={{ display:'flex', gap:8, marginTop:4, alignItems:'center', flexWrap:'wrap' }}>
            <span style={{ fontSize:'0.8125rem', color:'#94A3B8' }}>{dept ? dept.name : 'All Departments'} · {new Date().toDateString()}</span>
            <span style={{ display:'inline-flex', gap:4, alignItems:'center', fontSize:'0.6875rem', fontWeight:600, color:'#10B981', background:'rgba(16,185,129,0.1)', border:'1px solid rgba(16,185,129,0.2)', padding:'2px 8px', borderRadius:100 }}>
              <span style={{ width:5, height:5, borderRadius:'50%', background:'#10B981', animation:'blink 1.5s infinite' }} />
              Live Data
            </span>
          </div>
        </div>
        <div style={{ display:'flex', gap:8 }}>
          <Btn variant="outline" size="sm" onClick={() => showToast('📋 Generating daily briefing...')}>📋 Daily Brief</Btn>
          <Btn variant="gold" size="sm" onClick={() => showToast('🚀 Escalation mode activated')}>⚡ Escalate</Btn>
        </div>
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:'1rem', marginBottom:'1.75rem' }}>
        <StatCard icon="🚨" value={reports.length} label="Active Issues" sub={`${criticals} critical`} iconBg="rgba(239,68,68,0.08)" trend="▲ 7 today" />
        <StatCard icon="✅" value={resolved} label="Resolved (30d)" iconBg="rgba(16,185,129,0.08)" trend="↑ 8.2%" trendUp />
        <StatCard icon="🧠" value="7.4" label="Risk Score" sub="AI confidence 89%" iconBg="rgba(198,167,94,0.1)" trend="⚠ High" />
        <StatCard icon="😊" value="64%" label="Sentiment" sub="2,840 signals" iconBg="rgba(11,30,61,0.06)" trend="↑ 3.1%" trendUp />
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'1fr 360px', gap:'1.5rem' }}>
        <div>
          <Card style={{ marginBottom:'1.25rem' }}>
            <CardHeader title="Issue Volume Trend" sub="Last 7 days" action={<Btn variant="outline" size="sm" onClick={() => showToast('📥 Exporting...')}>Export</Btn>} />
            <div style={{ padding:'1.25rem' }}>
              <MiniBarChart height={120} data={[
                {value:42,label:'Mon',color:'linear-gradient(180deg,#C6A75E,rgba(198,167,94,0.35))'},
                {value:58,label:'Tue',color:'linear-gradient(180deg,#C6A75E,rgba(198,167,94,0.35))'},
                {value:35,label:'Wed',color:'linear-gradient(180deg,#C6A75E,rgba(198,167,94,0.35))'},
                {value:81,label:'Thu',color:'linear-gradient(180deg,#F59E0B,rgba(245,158,11,0.4))'},
                {value:73,label:'Fri',color:'linear-gradient(180deg,#EF4444,rgba(239,68,68,0.4))'},
                {value:62,label:'Sat',color:'linear-gradient(180deg,#C6A75E,rgba(198,167,94,0.35))'},
                {value:48,label:'Sun',color:'linear-gradient(180deg,#10B981,rgba(16,185,129,0.3))'},
              ]} />
            </div>
          </Card>

          <Card>
            <CardHeader title="⚡ Priority Queue" sub="AI ranked" action={<Btn variant="primary" size="sm" onClick={() => {}}>View All</Btn>} />
            <div style={{ padding:'0 1.25rem 1.25rem' }}>
              {reports.slice(0,5).map(r => (
                <div key={r.id} style={{ display:'flex', alignItems:'center', gap:10, padding:'0.75rem 0', borderBottom:'1px solid #F0F4F8', cursor:'pointer' }}
                  onClick={() => showToast(`📋 ${r.title}`)}>
                  <ScoreRing score={r.score} size={36} />
                  <div style={{ flex:1, minWidth:0 }}>
                    <div style={{ fontSize:'0.8125rem', fontWeight:600, color:'#0F172A', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{r.title}</div>
                    <div style={{ fontSize:'0.6875rem', color:'#94A3B8', marginTop:1 }}>{r.district} · {r.time}</div>
                  </div>
                  <LevelBadge level={r.level} />
                </div>
              ))}
            </div>
          </Card>
        </div>

        <div>
          {/* Top AI alert */}
          {reports[0] && (() => {
            const model = AI_MODELS[reports[0].model];
            return (
              <div style={{ background:'linear-gradient(135deg,#0B1E3D,#1A3A6E)', borderRadius:14, padding:'1.25rem', marginBottom:'1rem', position:'relative', overflow:'hidden' }}>
                <div style={{ position:'absolute', top:'-20px', right:'-20px', width:120, height:120, borderRadius:'50%', background:'rgba(198,167,94,0.08)' }} />
                <div style={{ position:'relative', zIndex:1 }}>
                  <div style={{ fontSize:'0.5625rem', fontWeight:700, letterSpacing:'0.1em', textTransform:'uppercase', color:'#C6A75E', marginBottom:'0.5rem' }}>
                    🧠 {model ? model.name : 'AI Alert'}
                  </div>
                  <div style={{ fontSize:'0.9375rem', fontWeight:700, color:'white', marginBottom:'0.25rem' }}>{reports[0].title}</div>
                  <div style={{ fontSize:'0.75rem', color:'rgba(255,255,255,0.5)', marginBottom:'1rem' }}>{reports[0].district}, {reports[0].state}</div>
                  {model && (
                    <>
                      <ConfBar label="Model Confidence" value={model.accuracy} color="#C6A75E" />
                      <div style={{ fontSize:'0.5625rem', fontWeight:700, letterSpacing:'0.08em', textTransform:'uppercase', color:'#C6A75E', marginBottom:'0.5rem', marginTop:'0.25rem' }}>SHAP Factors</div>
                      {model.shapFactors.slice(0,3).map((f,i) => (
                        <SHAPBar key={i} label={f} value={model.shapValues[i]} maxValue={0.5} color="#C6A75E" />
                      ))}
                    </>
                  )}
                  <Btn variant="gold" size="sm" style={{ width:'100%', justifyContent:'center', marginTop:'0.75rem' }} onClick={() => showToast('🚨 Alert dispatched to department')}>🚨 Issue Alert</Btn>
                </div>
              </div>
            );
          })()}

          {/* Mini heatmap */}
          <Card>
            <CardHeader title="District Heatmap" sub="Issue density" />
            <div style={{ padding:'1.25rem' }}>
              <div style={{ display:'grid', gridTemplateColumns:'repeat(10,1fr)', gap:3 }}>
                {Array.from({length:50}, (_,i) => {
                  const v = Math.random();
                  const r = Math.round(11 + v*228); const g = Math.round(30 + v*38); const b = Math.round(61 + v*7);
                  return <div key={i} style={{ aspectRatio:'1', borderRadius:3, background:`rgba(${r},${g},${b},${0.15+v*0.85})`, cursor:'pointer', transition:'transform 0.15s' }}
                    onMouseEnter={e=>e.currentTarget.style.transform='scale(1.3)'}
                    onMouseLeave={e=>e.currentTarget.style.transform=''} />;
                })}
              </div>
              <div style={{ display:'flex', gap:4, alignItems:'center', marginTop:8 }}>
                <span style={{ fontSize:'0.625rem', color:'#94A3B8' }}>Low</span>
                <div style={{ flex:1, height:5, borderRadius:3, background:'linear-gradient(90deg,rgba(198,167,94,0.2),#C6A75E,#F59E0B,#EF4444)' }} />
                <span style={{ fontSize:'0.625rem', color:'#94A3B8' }}>High</span>
              </div>
            </div>
          </Card>

          {/* Sentiment */}
          <Card style={{ marginTop:'1rem' }}>
            <CardHeader title="Sentiment Pulse" />
            <div style={{ padding:'1.25rem' }}>
              <div style={{ display:'flex', borderRadius:5, overflow:'hidden', height:10, marginBottom:8 }}>
                <div style={{ width:'42%', background:'#10B981' }} />
                <div style={{ width:'22%', background:'#94A3B8' }} />
                <div style={{ width:'36%', background:'#EF4444' }} />
              </div>
              <div style={{ display:'flex', gap:'1rem' }}>
                {[['#10B981','Positive','42%'],['#94A3B8','Neutral','22%'],['#EF4444','Negative','36%']].map(([c,l,v]) => (
                  <div key={l} style={{ display:'flex', alignItems:'center', gap:5 }}>
                    <div style={{ width:8, height:8, borderRadius:'50%', background:c }} />
                    <span style={{ fontSize:'0.6875rem', color:'#64748B' }}>{l} {v}</span>
                  </div>
                ))}
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

// ── AI Predictions ────────────────────────────────────────────────
function AIPredictionsPage({ dept, reports }) {
  const { showToast } = useStore();
  const HAZARD_MODELS = ['flood_risk','landslide','heatwave','drought','cyclone'];
  const AGRI_MODELS = ['crop_yield','crop_stress','disease_detection','irrigation','crop_suitability','agri_risk'];

  const modelGroups = dept
    ? [dept.models]
    : [HAZARD_MODELS, AGRI_MODELS];

  return (
    <div>
      <div style={{ marginBottom:'1.5rem' }}>
        <h2 style={{ fontFamily:'Playfair Display', fontSize:'1.375rem', fontWeight:700, color:'#0B1E3D', marginBottom:'0.375rem' }}>🧠 AI <span style={{ color:'#C6A75E' }}>Predictions</span></h2>
        <p style={{ fontSize:'0.875rem', color:'#64748B' }}>ML model outputs with SHAP explainability · 72h forecast integration</p>
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'1.25rem' }}>
        {(dept ? dept.models : [...HAZARD_MODELS, ...AGRI_MODELS]).map(modelId => {
          const model = AI_MODELS[modelId];
          if (!model) return null;
          const report = reports.find(r => r.model === modelId);
          const modelDept = DEPARTMENTS.find(d => d.id === model.dept);

          return (
            <div key={modelId} style={{ background:'linear-gradient(135deg,#0B1E3D,#1A3A6E)', borderRadius:14, padding:'1.25rem', position:'relative', overflow:'hidden' }}>
              <div style={{ position:'absolute', top:'-20px', right:'-20px', width:100, height:100, borderRadius:'50%', background:`${model.color || '#C6A75E'}12` }} />
              <div style={{ position:'relative', zIndex:1 }}>
                <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:'0.75rem' }}>
                  <span style={{ fontSize:'1.25rem' }}>{model.icon}</span>
                  <div>
                    <div style={{ fontSize:'0.625rem', fontWeight:700, letterSpacing:'0.1em', textTransform:'uppercase', color: model.color || '#C6A75E' }}>{modelDept?.shortName} · {model.version}</div>
                    <div style={{ fontSize:'0.875rem', fontWeight:700, color:'white' }}>{model.name}</div>
                  </div>
                  {report && <div style={{ marginLeft:'auto' }}><LevelBadge level={report.level} /></div>}
                </div>
                {report && <div style={{ fontSize:'0.8125rem', color:'rgba(255,255,255,0.65)', marginBottom:'0.875rem', lineHeight:1.5 }}>{report.summary}</div>}
                <ConfBar label="Confidence" value={model.accuracy} color={model.color || '#C6A75E'} />
                <div style={{ fontSize:'0.5625rem', fontWeight:700, letterSpacing:'0.08em', textTransform:'uppercase', color:'rgba(255,255,255,0.4)', marginBottom:'0.5rem' }}>SHAP</div>
                {model.shapFactors.slice(0,3).map((f,i) => (
                  <SHAPBar key={i} label={f} value={model.shapValues[i]} maxValue={0.5} color={model.color || '#C6A75E'} />
                ))}
                <div style={{ display:'flex', gap:6, marginTop:'0.75rem' }}>
                  <Btn variant="gold" size="sm" onClick={() => showToast('🚨 Alert dispatched!')}>🚨 Alert</Btn>
                  <button onClick={() => showToast('📋 Full model view')} style={{ flex:1, padding:'5px 10px', background:'rgba(255,255,255,0.08)', border:'1px solid rgba(255,255,255,0.15)', borderRadius:7, fontSize:'0.6875rem', color:'rgba(255,255,255,0.7)', cursor:'pointer' }}>Full Details →</button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ── Priority Queue ────────────────────────────────────────────────
function PriorityQueuePage({ reports }) {
  const { showToast } = useStore();
  const sorted = [...reports].sort((a,b) => b.score - a.score);

  return (
    <div>
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:'1.5rem' }}>
        <div>
          <h2 style={{ fontFamily:'Playfair Display', fontSize:'1.375rem', fontWeight:700, color:'#0B1E3D' }}>⚡ Priority <span style={{ color:'#C6A75E' }}>Queue</span></h2>
          <p style={{ fontSize:'0.875rem', color:'#64748B' }}>{sorted.filter(r=>!r.assigned).length} unassigned · AI-ranked by urgency × impact × recurrence</p>
        </div>
        <Btn variant="primary" onClick={() => showToast('🤖 Auto-assigning all critical issues...')}>🤖 Auto-Assign All</Btn>
      </div>
      <div style={{ display:'flex', flexDirection:'column', gap:'0.75rem' }}>
        {sorted.map(r => {
          const model = AI_MODELS[r.model];
          const dept = DEPARTMENTS.find(d=>d.id===r.dept);
          return (
            <div key={r.id} style={{ background:'white', border:`1px solid ${r.level==='CRITICAL'?'rgba(239,68,68,0.2)':r.level==='HIGH'?'rgba(245,158,11,0.2)':'#E2E8F0'}`, borderRadius:12, padding:'1rem 1.25rem', display:'flex', alignItems:'center', gap:12, transition:'all 0.2s', cursor:'pointer' }}
              onMouseEnter={e=>e.currentTarget.style.boxShadow='0 4px 16px rgba(11,30,61,0.08)'}
              onMouseLeave={e=>e.currentTarget.style.boxShadow=''}>
              <ScoreRing score={r.score} size={44} />
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ display:'flex', gap:8, alignItems:'center', marginBottom:3 }}>
                  <span style={{ fontSize:'0.875rem', fontWeight:700, color:'#0F172A' }}>{r.title}</span>
                  <LevelBadge level={r.level} />
                  {!r.assigned && <span style={{ fontSize:'0.5625rem', background:'rgba(239,68,68,0.08)', color:'#DC2626', padding:'2px 6px', borderRadius:100, fontWeight:800, border:'1px solid rgba(239,68,68,0.2)' }}>UNASSIGNED</span>}
                </div>
                <div style={{ display:'flex', gap:8, flexWrap:'wrap' }}>
                  {dept && <span style={{ fontSize:'0.6rem', background: dept.bg, color: dept.color, padding:'2px 7px', borderRadius:100, fontWeight:700, border:`1px solid ${dept.border}` }}>{dept.icon} {dept.shortName}</span>}
                  {model && <span style={{ fontSize:'0.6rem', background:'rgba(11,30,61,0.05)', color:'#64748B', padding:'2px 7px', borderRadius:100, fontWeight:600 }}>{model.icon} {model.name}</span>}
                  <span style={{ fontSize:'0.6875rem', color:'#94A3B8' }}>📍 {r.district} · {r.time}</span>
                </div>
              </div>
              <div style={{ display:'flex', gap:6, flexShrink:0 }}>
                <Btn variant="outline" size="sm" onClick={() => showToast(`✅ Assigned to ${dept?.shortName}`)}>Assign</Btn>
                <Btn variant="gold" size="sm" onClick={() => showToast('🚨 Escalated!')}>Escalate</Btn>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ── Map Page ──────────────────────────────────────────────────────
function MapPage() {
  return (
    <div>
      <h2 style={{ fontFamily:'Playfair Display', fontSize:'1.375rem', fontWeight:700, color:'#0B1E3D', marginBottom:'1.5rem' }}>📍 Geo <span style={{ color:'#C6A75E' }}>Intelligence Map</span></h2>
      <div style={{ background:'#0B1E3D', borderRadius:16, overflow:'hidden', height:500, position:'relative', display:'flex', alignItems:'center', justifyContent:'center' }}>
        {[{s:80,t:'20%',l:'30%',d:0},{s:60,t:'40%',l:'55%',d:0.8},{s:100,t:'60%',l:'25%',bg:'rgba(245,158,11,0.7)',d:1.5},{s:50,t:'35%',l:'70%',d:0.4},{s:70,t:'55%',l:'65%',d:1}].map((dot,i) => (
          <div key={i} style={{ position:'absolute', width:dot.s, height:dot.s, borderRadius:'50%', background: dot.bg || 'radial-gradient(circle,rgba(239,68,68,0.65),transparent 70%)', top:dot.t, left:dot.l, animation:`pulse 3s ease-in-out ${dot.d}s infinite` }} />
        ))}
        <div style={{ position:'relative', zIndex:1, textAlign:'center' }}>
          <div style={{ fontSize:'2.5rem', marginBottom:'0.5rem' }}>🗺️</div>
          <div style={{ fontSize:'0.9375rem', color:'rgba(255,255,255,0.7)', fontWeight:600 }}>Lucknow District · Interactive Map</div>
          <div style={{ fontSize:'0.75rem', color:'rgba(255,255,255,0.4)', fontFamily:'IBM Plex Mono', marginBottom:'1rem' }}>Mapbox / Leaflet Integration</div>
          <div style={{ display:'flex', gap:8, justifyContent:'center' }}>
            {[['#EF4444','14 Critical'],['#F59E0B','89 High'],['#10B981','244 Normal']].map(([c,l]) => (
              <div key={l} style={{ background:`${c}CC`, borderRadius:6, padding:'4px 10px', fontSize:'0.75rem', color:'white' }}>● {l}</div>
            ))}
          </div>
        </div>
      </div>
      <style>{`@keyframes pulse { 0%,100%{transform:scale(1);opacity:0.6} 50%{transform:scale(1.3);opacity:1} }`}</style>
    </div>
  );
}

// ── Analytics ─────────────────────────────────────────────────────
function AnalyticsPage({ dept, reports }) {
  return (
    <div>
      <h2 style={{ fontFamily:'Playfair Display', fontSize:'1.375rem', fontWeight:700, color:'#0B1E3D', marginBottom:'1.5rem' }}>📈 <span style={{ color:'#C6A75E' }}>Analytics</span></h2>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:'1rem', marginBottom:'1.5rem' }}>
        <StatCard icon="📊" value="89%" label="Resolution Rate" trend="↑ 8.2%" trendUp iconBg="rgba(16,185,129,0.08)" />
        <StatCard icon="⏱️" value="4.2d" label="Avg Resolution" trend="↑ 1.2d" trendUp iconBg="rgba(198,167,94,0.1)" />
        <StatCard icon="⭐" value="3.8/5" label="Satisfaction" iconBg="rgba(11,30,61,0.06)" />
        <StatCard icon="🔁" value="12%" label="Recurrence" trend="▲ 2%" iconBg="rgba(239,68,68,0.08)" />
      </div>
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'1.25rem' }}>
        <Card>
          <CardHeader title="Issues by Category" />
          <div style={{ padding:'1.25rem' }}>
            <MiniBarChart height={120} data={[
              {value:72,label:'Roads',color:'linear-gradient(180deg,#C6A75E,rgba(198,167,94,0.3))'},
              {value:54,label:'Water',color:'linear-gradient(180deg,#0284c7,rgba(2,132,199,0.3))'},
              {value:41,label:'Elec',color:'linear-gradient(180deg,#d97706,rgba(217,119,6,0.3))'},
              {value:38,label:'Sanit',color:'linear-gradient(180deg,#059669,rgba(5,150,105,0.3))'},
              {value:22,label:'Flood',color:'linear-gradient(180deg,#EF4444,rgba(239,68,68,0.3))'},
              {value:18,label:'Agri',color:'linear-gradient(180deg,#16a34a,rgba(22,163,74,0.3))'},
            ]} />
          </div>
        </Card>
        <Card>
          <CardHeader title="Dept Response Times" />
          <div style={{ padding:'1.25rem' }}>
            {[['PWD','3.8d','68%','#b45309'],['Jal Nigam','6.1d','45%','#0284c7'],['UPCL','1.9d','80%','#d97706'],['LMC','4.4d','58%','#059669']].map(([d,t,p,c]) => (
              <div key={d} style={{ display:'flex', alignItems:'center', gap:10, marginBottom:'0.75rem' }}>
                <span style={{ fontSize:'0.8125rem', fontWeight:600, color:'#0F172A', width:80 }}>{d}</span>
                <div style={{ flex:1, height:6, background:'#F0F4F8', borderRadius:100, overflow:'hidden' }}>
                  <div style={{ width:p, height:'100%', background:c, borderRadius:100 }} />
                </div>
                <span style={{ fontFamily:'IBM Plex Mono', fontSize:'0.6875rem', color:'#64748B', width:32, textAlign:'right' }}>{t}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

// ── Audit ─────────────────────────────────────────────────────────
function AuditPage() {
  const { showToast } = useStore();
  const TRAIL = [
    ['✅','Issue #2847 resolved','PWD uploaded before/after photos · Geo-verified','2h ago'],
    ['📋','Issue #2848 assigned','Auto-assigned to Jal Nigam by AI routing · Priority 8.9','3h ago'],
    ['🔔','Alert dispatched','Flood warning to 340 residents · Gomti Nagar','5h ago'],
    ['📝','Issue #2843 reported','Citizen Priya K. via mobile · GPS tagged','6h ago'],
    ['✅','Issue #2831 resolved','Sanitation team completed · 4.2d SLA met','8h ago'],
    ['📊','Daily brief generated','AI summary sent to Collector · 3 critical','12h ago'],
    ['🤖','Model run: flood_risk','87% probability for Gomti Nagar · Alert issued','14h ago'],
  ];
  return (
    <div>
      <h2 style={{ fontFamily:'Playfair Display', fontSize:'1.375rem', fontWeight:700, color:'#0B1E3D', marginBottom:'1.5rem' }}>📋 Audit <span style={{ color:'#C6A75E' }}>Trail</span></h2>
      <Card>
        <div style={{ padding:'1.25rem' }}>
          {TRAIL.map(([icon, title, desc, time], i) => (
            <div key={i} style={{ display:'flex', gap:12, padding:'0.875rem 0', borderBottom: i<TRAIL.length-1 ? '1px solid #F0F4F8' : 'none' }}>
              <div style={{ width:36, height:36, borderRadius:8, background:'#F0F4F8', border:'1px solid #E2E8F0', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'0.9375rem', flexShrink:0 }}>{icon}</div>
              <div style={{ flex:1 }}>
                <div style={{ fontSize:'0.875rem', fontWeight:600, color:'#0F172A' }}>{title}</div>
                <div style={{ fontSize:'0.75rem', color:'#94A3B8', marginTop:2 }}>{desc}</div>
              </div>
              <div style={{ fontFamily:'IBM Plex Mono', fontSize:'0.6875rem', color:'#94A3B8', whiteSpace:'nowrap' }}>{time}</div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

// ── Alerts ────────────────────────────────────────────────────────
function AlertsPage({ reports }) {
  const { showToast } = useStore();
  return (
    <div>
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:'1.5rem' }}>
        <h2 style={{ fontFamily:'Playfair Display', fontSize:'1.375rem', fontWeight:700, color:'#0B1E3D' }}>🔔 <span style={{ color:'#C6A75E' }}>Alerts</span></h2>
        <Btn variant="outline" size="sm" onClick={() => showToast('✓ All alerts marked read')}>Mark all read</Btn>
      </div>
      <Card>
        <div style={{ padding:'1.25rem' }}>
          {reports.slice(0,8).map((r, i) => (
            <div key={r.id} style={{ display:'flex', gap:12, padding:'1rem 0', borderBottom: i<7 ? '1px solid #F0F4F8' : 'none', background: !r.assigned ? 'rgba(198,167,94,0.01)' : 'transparent' }}>
              <div style={{ width:7, height:7, borderRadius:'50%', background: r.level==='CRITICAL'?'#EF4444':'#F59E0B', marginTop:4, flexShrink:0 }} />
              <span style={{ fontSize:'1.125rem' }}>{AI_MODELS[r.model]?.icon || '🔔'}</span>
              <div style={{ flex:1 }}>
                <div style={{ fontSize:'0.875rem', fontWeight: !r.assigned ? 700 : 500, color:'#0F172A' }}>{r.title}</div>
                <div style={{ fontSize:'0.75rem', color:'#94A3B8', marginTop:2 }}>{r.summary}</div>
              </div>
              <div style={{ fontFamily:'IBM Plex Mono', fontSize:'0.6875rem', color:'#94A3B8', whiteSpace:'nowrap' }}>{r.time}</div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

function CommunityRedirect() {
  const { setPage } = useStore();
  return (
    <div style={{ textAlign:'center', padding:'4rem 2rem' }}>
      <div style={{ fontSize:'3rem', marginBottom:'1rem' }}>💬</div>
      <h2 style={{ fontFamily:'Playfair Display', color:'#0B1E3D', marginBottom:'0.75rem' }}>Community Feed</h2>
      <p style={{ color:'#64748B', marginBottom:'1.5rem' }}>Access the full citizen feed and government intelligence community</p>
      <Btn variant="primary" onClick={() => setPage('community')}>Open Community →</Btn>
    </div>
  );
}
