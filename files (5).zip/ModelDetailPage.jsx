import React, { useState } from 'react';
import { useStore } from '../../store/useStore';
import { AI_MODELS, DEPARTMENTS } from '../../data/masterData';
import { Card, CardHeader, LevelBadge, Btn, SHAPBar, ConfBar, PipelineStep, MiniBarChart, ScoreRing } from '../ui';

export default function ModelDetailPage({ modelId }) {
  const { setPage, showToast } = useStore();
  const model = AI_MODELS[modelId];
  if (!model) return <div style={{ padding:'2rem' }}>Model not found</div>;

  const dept = DEPARTMENTS.find(d => d.id === model.dept);
  const [activeDistrict, setActiveDistrict] = useState('Lucknow');
  const [running, setRunning] = useState(false);

  const SAMPLE_RESULT = {
    flood_risk:    { probability:0.73, level:'HIGH',     ci:0.08, alert:'⚠️ Flood alert: 73% probability', advisory:'Deploy drainage teams. Pre-position NDRF.' },
    landslide:     { probability:0.62, level:'HIGH',     ci:0.09, alert:'⚠️ Landslide: slope saturation critical', advisory:'Evacuate 3 villages. Restrict access.' },
    heatwave:      { probability:0.88, level:'CRITICAL', ci:0.06, alert:'🌡️ Heatwave: 44°C forecast 72h', advisory:'Close schools. Open cooling centers.' },
    drought:       { probability:0.54, level:'MEDIUM',   ci:0.11, alert:'📉 Drought onset: SPI-3 at -1.4', advisory:'Activate water conservation protocols.' },
    cyclone:       { probability:0.41, level:'MEDIUM',   ci:0.07, alert:'🌀 Cyclone watch: Bay of Bengal', advisory:'Coastal district advisory. Fishermen recall.' },
    crop_yield:    { probability:0.78, level:'HIGH',     ci:0.05, alert:'📉 Yield forecast: 3.2 t/ha (baseline 4.1)', advisory:'Subsidize inputs. Deploy extension officers.' },
    crop_stress:   { probability:0.81, level:'HIGH',     ci:0.07, alert:'🌿 Heat stress detected — VPD 4.2 kPa', advisory:'Irrigate within 24h. Apply foliar spray.' },
    disease_detection: { probability:0.94, level:'CRITICAL', ci:0.03, alert:'🦠 Wheat Rust: 94% confidence', advisory:'Fungicide spray immediately. Block all movement.' },
    irrigation:    { probability:0.68, level:'MEDIUM',   ci:0.06, alert:'💧 Deficit: 3.1 mm/day', advisory:'Increase irrigation. Check canal flows.' },
    crop_suitability: { probability:0.82, level:'HIGH', ci:0.05, alert:'🌱 Best crop: Rice (82% suitable)', advisory:'Switch to drought-tolerant Wheat if rain < 600mm.' },
    agri_risk:     { probability:0.77, level:'HIGH',     ci:0.08, alert:'📊 High Agriculture Risk Score: 7.7', advisory:'Pre-position PMFBY claim teams. Issue advisory.' },
  }[modelId] || { probability:0.65, level:'HIGH', ci:0.07, alert:'Model output', advisory:'Take action.' };

  const runModel = () => {
    setRunning(true);
    setTimeout(() => { setRunning(false); showToast(`✅ ${model.name} executed for ${activeDistrict}`); }, 1800);
  };

  const modelColor = model.color || (dept?.color || '#C6A75E');

  return (
    <div style={{ padding:'2rem', maxWidth:1200 }}>
      {/* Breadcrumb */}
      <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:'1.5rem', fontSize:'0.8125rem', color:'#64748B' }}>
        <button onClick={() => setPage('departments')} style={{ background:'none', border:'none', cursor:'pointer', color:'#64748B' }}>Departments</button>
        <span>›</span>
        <button onClick={() => setPage('dept_' + model.dept)} style={{ background:'none', border:'none', cursor:'pointer', color:'#64748B' }}>{dept?.shortName}</button>
        <span>›</span>
        <span style={{ color:'#0F172A', fontWeight:600 }}>{model.name}</span>
      </div>

      {/* Hero card */}
      <div style={{ background:'linear-gradient(135deg,#0B1E3D 0%,#1A3A6E 100%)', borderRadius:20, padding:'2rem', marginBottom:'2rem', position:'relative', overflow:'hidden' }}>
        <div style={{ position:'absolute', top:'-30px', right:'-30px', width:180, height:180, borderRadius:'50%', background:`${modelColor}12` }} />
        <div style={{ position:'relative', zIndex:1, display:'flex', alignItems:'flex-start', gap:'1.5rem', flexWrap:'wrap' }}>
          <div style={{ width:64, height:64, borderRadius:16, background:`${modelColor}25`, border:`2px solid ${modelColor}40`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:'2rem', flexShrink:0 }}>{model.icon}</div>
          <div style={{ flex:1 }}>
            <div style={{ display:'flex', gap:8, flexWrap:'wrap', marginBottom:'0.5rem' }}>
              <span style={{ fontSize:'0.625rem', fontWeight:700, letterSpacing:'0.1em', textTransform:'uppercase', color: modelColor }}>AI Model · {model.version}</span>
              <span style={{ fontSize:'0.6rem', padding:'2px 8px', borderRadius:100, background:'rgba(16,185,129,0.2)', color:'#10B981', fontWeight:700 }}>✓ {model.accuracy}% Accuracy</span>
            </div>
            <h1 style={{ fontFamily:'Playfair Display', fontSize:'1.625rem', fontWeight:700, color:'white', marginBottom:'0.5rem' }}>{model.name}</h1>
            <p style={{ fontSize:'0.875rem', color:'rgba(255,255,255,0.6)', lineHeight:1.65, maxWidth:600 }}>{model.description}</p>
            <div style={{ display:'flex', gap:8, marginTop:'1rem', flexWrap:'wrap' }}>
              <span style={{ fontSize:'0.6875rem', padding:'4px 12px', borderRadius:100, background:'rgba(255,255,255,0.08)', color:'rgba(255,255,255,0.7)' }}>🔬 {model.algorithm}</span>
              <span style={{ fontSize:'0.6875rem', padding:'4px 12px', borderRadius:100, background:'rgba(255,255,255,0.08)', color:'rgba(255,255,255,0.7)' }}>📊 {model.trainingRecords} training records</span>
              {dept && <span style={{ fontSize:'0.6875rem', padding:'4px 12px', borderRadius:100, background: `${dept.color}25`, color: dept.color }}>{dept.icon} {dept.shortName}</span>}
            </div>
          </div>
          <div style={{ display:'flex', gap:8 }}>
            <Btn variant="gold" size="sm" onClick={runModel}>{running ? '⏳ Running...' : '▶ Run Model'}</Btn>
            <Btn size="sm" style={{ background:'rgba(255,255,255,0.08)', border:'1px solid rgba(255,255,255,0.15)', color:'rgba(255,255,255,0.7)' }} onClick={() => showToast('📥 Model report exported')}>📥 Export</Btn>
          </div>
        </div>
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'1fr 380px', gap:'1.5rem' }}>
        {/* LEFT */}
        <div style={{ display:'flex', flexDirection:'column', gap:'1.25rem' }}>

          {/* Live Inference */}
          <Card>
            <CardHeader title="🧠 Live Model Inference" sub={`Run ${model.name} for any district`} />
            <div style={{ padding:'1.25rem' }}>
              <div style={{ display:'flex', gap:8, marginBottom:'1rem', flexWrap:'wrap' }}>
                {['Lucknow','Patna','Nagpur','Wayanad','Delhi','Jaipur'].map(d => (
                  <button key={d} onClick={() => setActiveDistrict(d)} style={{
                    padding:'5px 14px', borderRadius:7, fontSize:'0.75rem', fontWeight:600,
                    border: activeDistrict===d ? 'none' : '1.5px solid #E2E8F0',
                    background: activeDistrict===d ? `linear-gradient(135deg,${modelColor},${modelColor}aa)` : 'transparent',
                    color: activeDistrict===d ? 'white' : '#64748B', cursor:'pointer',
                  }}>{d}</button>
                ))}
              </div>

              {running ? (
                <div style={{ padding:'2rem', textAlign:'center' }}>
                  <div style={{ fontSize:'2rem', marginBottom:'0.5rem', animation:'spin 1s linear infinite', display:'inline-block' }}>⚙️</div>
                  <div style={{ fontSize:'0.875rem', color:'#64748B' }}>Running {model.pipeline?.length || 8}-step pipeline...</div>
                </div>
              ) : (
                <div style={{ background:'rgba(11,30,61,0.02)', border:'1px solid rgba(198,167,94,0.2)', borderRadius:12, padding:'1.25rem' }}>
                  <div style={{ display:'flex', alignItems:'center', gap:12, marginBottom:'1rem' }}>
                    <ScoreRing score={(SAMPLE_RESULT.probability * 10).toFixed(1)} size={52} />
                    <div>
                      <div style={{ fontSize:'0.6875rem', fontWeight:700, letterSpacing:'0.08em', textTransform:'uppercase', color: modelColor, marginBottom:3 }}>Output — {activeDistrict}</div>
                      <div style={{ fontSize:'1rem', fontWeight:700, color:'#0F172A' }}>{SAMPLE_RESULT.alert}</div>
                      <LevelBadge level={SAMPLE_RESULT.level} />
                    </div>
                  </div>
                  <div style={{ background:'rgba(255,255,255,0.8)', borderRadius:8, padding:'0.75rem', border:'1px solid #E2E8F0', marginBottom:'0.875rem' }}>
                    <div style={{ fontSize:'0.6875rem', fontWeight:700, color:'#0B1E3D', marginBottom:4 }}>📋 Advisory</div>
                    <div style={{ fontSize:'0.8125rem', color:'#64748B' }}>{SAMPLE_RESULT.advisory}</div>
                  </div>
                  <div style={{ display:'flex', gap:'1.5rem' }}>
                    <div>
                      <div style={{ fontFamily:'IBM Plex Mono', fontSize:'1.25rem', fontWeight:700, color: modelColor }}>{(SAMPLE_RESULT.probability * 100).toFixed(0)}%</div>
                      <div style={{ fontSize:'0.625rem', color:'#94A3B8', textTransform:'uppercase' }}>Probability</div>
                    </div>
                    <div>
                      <div style={{ fontFamily:'IBM Plex Mono', fontSize:'1.25rem', fontWeight:700, color:'#10B981' }}>±{(SAMPLE_RESULT.ci * 100).toFixed(0)}%</div>
                      <div style={{ fontSize:'0.625rem', color:'#94A3B8', textTransform:'uppercase' }}>Confidence Interval</div>
                    </div>
                    <div>
                      <div style={{ fontFamily:'IBM Plex Mono', fontSize:'1.25rem', fontWeight:700, color:'#0B1E3D' }}>{model.accuracy}%</div>
                      <div style={{ fontSize:'0.625rem', color:'#94A3B8', textTransform:'uppercase' }}>Model Accuracy</div>
                    </div>
                  </div>
                </div>
              )}
              <ConfBar label={`${model.name} Confidence`} value={model.accuracy} color={modelColor} />
            </div>
          </Card>

          {/* SHAP Explainability */}
          <Card>
            <CardHeader title="🔬 SHAP Feature Explainability" sub="Why did the model give this score?" />
            <div style={{ padding:'1.25rem' }}>
              {model.shapFactors.map((f, i) => (
                <SHAPBar key={i} label={f} value={model.shapValues[i]} maxValue={0.5} color={modelColor} />
              ))}
              <div style={{ marginTop:'0.875rem', padding:'0.75rem', background:'rgba(198,167,94,0.04)', border:'1px solid rgba(198,167,94,0.2)', borderRadius:8 }}>
                <div style={{ fontSize:'0.6875rem', color:'#64748B', lineHeight:1.5 }}>
                  📊 SHAP (SHapley Additive exPlanations) values show each feature's contribution to this prediction. Higher values = greater influence on the output score.
                </div>
              </div>
            </div>
          </Card>

          {/* Input Features */}
          <Card>
            <CardHeader title="📥 Model Input Features" sub={`${model.features.length} features used`} />
            <div style={{ padding:'1.25rem' }}>
              <div style={{ display:'flex', gap:6, flexWrap:'wrap' }}>
                {model.features.map((f, i) => (
                  <span key={i} style={{ fontSize:'0.6875rem', padding:'4px 10px', borderRadius:100, background:'rgba(11,30,61,0.05)', color:'#0B1E3D', border:'1px solid rgba(11,30,61,0.08)', fontWeight:500 }}>{f}</span>
                ))}
              </div>
            </div>
          </Card>

          {/* Output spec */}
          <Card>
            <CardHeader title="📤 Model Outputs" sub="Variables produced by this model" />
            <div style={{ padding:'1.25rem' }}>
              <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
                {model.outputs.map((o, i) => (
                  <div key={i} style={{ display:'flex', alignItems:'center', gap:10, padding:'8px 12px', background:'rgba(16,185,129,0.04)', border:'1px solid rgba(16,185,129,0.15)', borderRadius:8 }}>
                    <span style={{ width:8, height:8, borderRadius:'50%', background:'#10B981', display:'inline-block', flexShrink:0 }} />
                    <span style={{ fontFamily:'IBM Plex Mono', fontSize:'0.75rem', color:'#065F46', fontWeight:500 }}>{o}</span>
                  </div>
                ))}
              </div>
            </div>
          </Card>

          {/* Trend chart */}
          <Card>
            <CardHeader title="📈 Prediction Trend (7 days)" />
            <div style={{ padding:'1.25rem' }}>
              <MiniBarChart height={100} data={[
                {value:42,label:'Mon',color:`linear-gradient(180deg,${modelColor},${modelColor}44)`},
                {value:58,label:'Tue',color:`linear-gradient(180deg,${modelColor},${modelColor}44)`},
                {value:35,label:'Wed',color:`linear-gradient(180deg,${modelColor},${modelColor}44)`},
                {value:81,label:'Thu',color:'linear-gradient(180deg,#EF4444,rgba(239,68,68,0.4))'},
                {value:73,label:'Fri',color:'linear-gradient(180deg,#F59E0B,rgba(245,158,11,0.4))'},
                {value:62,label:'Sat',color:`linear-gradient(180deg,${modelColor},${modelColor}44)`},
                {value:48,label:'Sun',color:`linear-gradient(180deg,${modelColor},${modelColor}44)`},
              ]} />
            </div>
          </Card>
        </div>

        {/* RIGHT */}
        <div style={{ display:'flex', flexDirection:'column', gap:'1.25rem' }}>

          {/* Model Pipeline */}
          <Card>
            <CardHeader title="⚙️ Model Pipeline" sub={`${model.pipeline?.length || 8} steps`} />
            <div style={{ padding:'1.25rem', display:'flex', flexDirection:'column', gap:10 }}>
              {(model.pipeline || ['Load Data','Preprocess','Feature Engineering','Model Inference','Confidence Interval','Alert Generation','Advisory','Response']).map((step, i, arr) => (
                <PipelineStep key={i} step={i+1} label={step} done={i < arr.length - 2} active={i === arr.length - 2} />
              ))}
            </div>
          </Card>

          {/* Data Sources */}
          <Card>
            <CardHeader title="🌐 Live Data Sources" />
            <div style={{ padding:'1.25rem', display:'flex', flexDirection:'column', gap:6 }}>
              {model.apis.map((api, i) => (
                <div key={i} style={{ display:'flex', alignItems:'center', gap:8, padding:'6px 10px', background:'rgba(11,30,61,0.03)', borderRadius:8, border:'1px solid rgba(11,30,61,0.06)' }}>
                  <span style={{ width:7, height:7, borderRadius:'50%', background:'#10B981', flexShrink:0 }} />
                  <span style={{ fontSize:'0.8125rem', color:'#0F172A', fontWeight:500 }}>{api}</span>
                  <span style={{ marginLeft:'auto', fontSize:'0.5625rem', color:'#10B981', fontWeight:700 }}>LIVE</span>
                </div>
              ))}
            </div>
          </Card>

          {/* Model metadata */}
          <Card>
            <CardHeader title="📋 Model Specifications" />
            <div style={{ padding:'1.25rem', display:'flex', flexDirection:'column', gap:8 }}>
              {[
                ['Algorithm', model.algorithm],
                ['Version', model.version],
                ['Training Records', model.trainingRecords],
                ['Accuracy', `${model.accuracy}%`],
                ['Endpoint', model.liveEndpoint],
                ['Department', dept?.shortName || model.dept],
              ].map(([k, v]) => (
                <div key={k} style={{ display:'flex', justifyContent:'space-between', paddingBottom:6, borderBottom:'1px solid #F0F4F8' }}>
                  <span style={{ fontSize:'0.75rem', color:'#64748B' }}>{k}</span>
                  <span style={{ fontSize:'0.75rem', fontWeight:600, color:'#0F172A', fontFamily: k==='Endpoint'?'IBM Plex Mono':undefined, textAlign:'right', maxWidth:170, overflow:'hidden', textOverflow:'ellipsis' }}>{v}</span>
                </div>
              ))}
            </div>
          </Card>

          {/* Thresholds */}
          {model.thresholds && (
            <Card>
              <CardHeader title="🎯 Alert Thresholds" />
              <div style={{ padding:'1.25rem', display:'flex', flexDirection:'column', gap:6 }}>
                {Object.entries(model.thresholds).map(([level, val]) => {
                  const lc = { CRITICAL:'#EF4444', HIGH:'#F59E0B', MEDIUM:'#10B981', WATCH:'#94A3B8' };
                  return (
                    <div key={level} style={{ display:'flex', alignItems:'center', gap:10 }}>
                      <span style={{ fontSize:'0.6875rem', fontWeight:700, color: lc[level], width:64 }}>{level}</span>
                      <div style={{ flex:1, height:5, background:'#F0F4F8', borderRadius:100, overflow:'hidden' }}>
                        <div style={{ width:`${val*100}%`, height:'100%', background: lc[level], borderRadius:100 }} />
                      </div>
                      <span style={{ fontFamily:'IBM Plex Mono', fontSize:'0.6875rem', color:'#64748B', width:34, textAlign:'right' }}>{(val*100).toFixed(0)}%</span>
                    </div>
                  );
                })}
              </div>
            </Card>
          )}

          {/* Crop/stress specific */}
          {model.stressClasses && (
            <Card>
              <CardHeader title="🌿 Stress Classifications" />
              <div style={{ padding:'1.25rem', display:'flex', flexDirection:'column', gap:6 }}>
                {model.stressClasses.map((cls, i) => (
                  <div key={i} style={{ display:'flex', alignItems:'center', gap:8, padding:'6px 10px', background:'rgba(11,30,61,0.03)', borderRadius:7 }}>
                    <span style={{ fontFamily:'IBM Plex Mono', fontSize:'0.625rem', color:'#94A3B8', width:16 }}>{i}</span>
                    <span style={{ fontSize:'0.8125rem', color:'#0F172A', fontWeight:500 }}>{cls}</span>
                  </div>
                ))}
              </div>
            </Card>
          )}

          {model.riskClasses && (
            <Card>
              <CardHeader title="📊 Risk Classifications" />
              <div style={{ padding:'1.25rem', display:'flex', flexDirection:'column', gap:6 }}>
                {model.riskClasses.map((cls, i) => {
                  const c = ['#10B981','#F59E0B','#EF4444','#DC2626'][i];
                  return (
                    <div key={i} style={{ display:'flex', alignItems:'center', gap:8, padding:'6px 10px', background:`${c}08`, border:`1px solid ${c}20`, borderRadius:7 }}>
                      <span style={{ width:8, height:8, borderRadius:'50%', background:c, flexShrink:0 }} />
                      <span style={{ fontSize:'0.8125rem', fontWeight:600, color: c }}>{cls}</span>
                    </div>
                  );
                })}
              </div>
            </Card>
          )}
        </div>
      </div>

      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}
