import React, { useState, useRef } from 'react'
import { useStore } from '../store/useStore'
import { Card, Btn } from '../components/ui'

const CATEGORIES = [
  { id:'roads',       icon:'🛣️',  label:'Roads & Infrastructure' },
  { id:'water',       icon:'🚰',  label:'Water Supply' },
  { id:'electricity', icon:'⚡',  label:'Electricity' },
  { id:'sanitation',  icon:'🗑️',  label:'Sanitation' },
  { id:'flood',       icon:'🌊',  label:'Flood Risk' },
  { id:'agriculture', icon:'🌾',  label:'Agriculture' },
  { id:'health',      icon:'🏥',  label:'Health' },
  { id:'environment', icon:'🌿',  label:'Environment' },
  { id:'railway',     icon:'🚂',  label:'Railway' },
  { id:'other',       icon:'📡',  label:'Other' },
]

export default function IssueReportPage() {
  const { showToast, user } = useStore()
  const [form, setForm] = useState({ title:'', category:'', description:'', district:'', ward:'' })
  const [files, setFiles]   = useState([])
  const [gpsActive, setGps] = useState(false)
  const [gpsCoords, setGpsCoords] = useState(null)
  const [listening, setListening] = useState(false)
  const [submitted, setSubmitted] = useState(false)
  const fileRef = useRef()

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }))

  const captureGPS = () => {
    setGps(true)
    navigator.geolocation?.getCurrentPosition(
      p => { setGpsCoords({ lat: p.coords.latitude.toFixed(5), lon: p.coords.longitude.toFixed(5) }); showToast('📍 GPS location captured') },
      () => { setGps(false); showToast('GPS unavailable — using IP location', 'warning') },
      { enableHighAccuracy: true, timeout: 8000 }
    )
  }

  const startVoice = () => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition
    if (!SR) { showToast('Voice input not supported in this browser', 'warning'); return }
    const rec = new SR()
    rec.lang = 'hi-IN'
    rec.continuous = false
    rec.interimResults = false
    setListening(true)
    rec.onresult = e => {
      const transcript = e.results[0][0].transcript
      set('description', (form.description + ' ' + transcript).trim())
      setListening(false)
      showToast('🎤 Voice transcribed successfully')
    }
    rec.onerror = () => { setListening(false); showToast('Voice input failed', 'error') }
    rec.onend   = () => setListening(false)
    rec.start()
  }

  const handleFiles = e => {
    const selected = Array.from(e.target.files)
    setFiles(prev => [...prev, ...selected])
    showToast(`📎 ${selected.length} file(s) attached`)
  }

  const submit = () => {
    if (!form.title || !form.category || !form.description) {
      showToast('Please fill Title, Category and Description', 'warning')
      return
    }
    setSubmitted(true)
    showToast('✅ Issue submitted! AI is analyzing priority…')
  }

  if (submitted) return <SuccessScreen form={form} />

  return (
    <div style={{ minHeight:'100vh', background:'#F0F4F8', padding:'2rem' }}>
      <div style={{ maxWidth:900, margin:'0 auto' }}>
        {/* Header */}
        <div style={{ marginBottom:'2rem' }}>
          <div style={{ fontSize:'0.6875rem', fontWeight:700, letterSpacing:'0.1em', textTransform:'uppercase', color:'#C6A75E', marginBottom:'0.375rem' }}>Civic Grievance Portal</div>
          <h1 style={{ fontFamily:'Playfair Display', fontSize:'1.75rem', fontWeight:700, color:'#0B1E3D', marginBottom:'0.375rem' }}>
            File Official <span style={{ color:'#C6A75E' }}>Civic Report</span>
          </h1>
          <p style={{ fontSize:'0.875rem', color:'#64748B' }}>Your report becomes an official civic record — AI-classified, tracked, and resolved.</p>
        </div>

        <div style={{ display:'grid', gridTemplateColumns:'1fr 1.5fr', gap:'2rem', alignItems:'start' }}>
          {/* Left: category picker */}
          <div>
            <div style={{ fontSize:'0.75rem', fontWeight:700, color:'#0F172A', marginBottom:'0.875rem' }}>Select Category</div>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'0.625rem', marginBottom:'1.5rem' }}>
              {CATEGORIES.map(c => (
                <button key={c.id} onClick={() => set('category', c.id)} style={{
                  display:'flex', alignItems:'center', gap:8, padding:'0.75rem',
                  borderRadius:10, fontSize:'0.8125rem', fontWeight:500, cursor:'pointer',
                  border: form.category===c.id ? '2px solid #0B1E3D' : '1.5px solid #E2E8F0',
                  background: form.category===c.id ? 'rgba(11,30,61,0.05)' : 'white',
                  color: form.category===c.id ? '#0B1E3D' : '#64748B',
                  transition:'all 0.15s', textAlign:'left',
                }}>
                  <span style={{ fontSize:'1rem' }}>{c.icon}</span>
                  <span style={{ fontSize:'0.75rem' }}>{c.label}</span>
                </button>
              ))}
            </div>

            {/* AI Preview */}
            <div style={{ background:'linear-gradient(135deg,#0B1E3D,#1A3A6E)', borderRadius:14, padding:'1.25rem', color:'white' }}>
              <div style={{ fontSize:'0.625rem', fontWeight:700, letterSpacing:'0.1em', textTransform:'uppercase', color:'#C6A75E', marginBottom:'0.5rem' }}>🧠 AI Processing Pipeline</div>
              {['Issue intake + GPS tag','NLP classification','Priority score (0–10)','Department routing','SLA timer starts','Citizen notification'].map((s, i) => (
                <div key={i} style={{ display:'flex', gap:8, alignItems:'center', padding:'4px 0' }}>
                  <div style={{ width:18, height:18, borderRadius:'50%', background:'rgba(198,167,94,0.2)', border:'1px solid rgba(198,167,94,0.4)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'0.5625rem', fontWeight:700, color:'#C6A75E', flexShrink:0 }}>{i+1}</div>
                  <span style={{ fontSize:'0.75rem', color:'rgba(255,255,255,0.6)' }}>{s}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Right: form */}
          <Card className="p-6">
            <div style={{ fontSize:'1rem', fontWeight:700, color:'#0B1E3D', fontFamily:'Playfair Display', marginBottom:'1.5rem', display:'flex', alignItems:'center', gap:8 }}>
              📋 Issue Details
            </div>

            {/* Title + Category row */}
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'1rem', marginBottom:'1rem' }}>
              <FormField label="Issue Title" required>
                <input value={form.title} onChange={e => set('title', e.target.value)}
                  placeholder="Brief title of the issue"
                  style={inputStyle} onFocus={focusStyle} onBlur={blurStyle} />
              </FormField>
              <FormField label="Category">
                <div style={{ ...inputStyle, background: form.category ? 'rgba(11,30,61,0.04)' : '#F0F4F8', color: form.category ? '#0F172A' : '#94A3B8', display:'flex', alignItems:'center', gap:6 }}>
                  {form.category ? `${CATEGORIES.find(c=>c.id===form.category)?.icon} ${CATEGORIES.find(c=>c.id===form.category)?.label}` : 'Select from left →'}
                </div>
              </FormField>
            </div>

            {/* Description + Voice */}
            <FormField label="Description" required style={{ marginBottom:'1rem' }}>
              <div style={{ position:'relative' }}>
                <textarea value={form.description} onChange={e => set('description', e.target.value)}
                  placeholder="Describe the issue — what, where, how long, severity..."
                  rows={4}
                  style={{ ...inputStyle, resize:'vertical', minHeight:100 }}
                  onFocus={focusStyle} onBlur={blurStyle} />
                <button onClick={startVoice}
                  style={{ position:'absolute', bottom:10, right:10, width:32, height:32, borderRadius:'50%', background: listening ? '#EF4444' : '#0B1E3D', border:'none', color:'white', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'0.875rem', transition:'all 0.2s' }}
                  title={listening ? 'Listening…' : 'Voice input (Hindi / English)'}>
                  {listening ? '⏹' : '🎤'}
                </button>
              </div>
              {listening && <div style={{ fontSize:'0.75rem', color:'#EF4444', marginTop:4, display:'flex', alignItems:'center', gap:4 }}><span style={{ width:6, height:6, borderRadius:'50%', background:'#EF4444', animation:'blink 1s infinite', display:'inline-block' }} /> Listening — speak in Hindi or English…</div>}
            </FormField>

            {/* District + Ward */}
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'1rem', marginBottom:'1rem' }}>
              <FormField label="District">
                <input value={form.district} onChange={e => set('district', e.target.value)}
                  placeholder="Your district" style={inputStyle} onFocus={focusStyle} onBlur={blurStyle} />
              </FormField>
              <FormField label="Ward / Area">
                <input value={form.ward} onChange={e => set('ward', e.target.value)}
                  placeholder="Specific area / ward" style={inputStyle} onFocus={focusStyle} onBlur={blurStyle} />
              </FormField>
            </div>

            {/* GPS */}
            <div style={{ marginBottom:'1rem' }}>
              {gpsCoords ? (
                <div style={{ display:'flex', alignItems:'center', gap:8, padding:'0.75rem', background:'rgba(16,185,129,0.06)', border:'1px solid rgba(16,185,129,0.25)', borderRadius:8 }}>
                  <span>📍</span>
                  <span style={{ fontSize:'0.8125rem', color:'#065F46' }}><strong>GPS Captured</strong> — {gpsCoords.lat}°N, {gpsCoords.lon}°E</span>
                  <button onClick={() => setGpsCoords(null)} style={{ marginLeft:'auto', fontSize:'0.75rem', color:'#94A3B8', background:'none', border:'none', cursor:'pointer' }}>✕</button>
                </div>
              ) : (
                <button onClick={captureGPS} style={{ width:'100%', padding:'0.75rem', background:'rgba(11,30,61,0.03)', border:'1.5px dashed rgba(11,30,61,0.15)', borderRadius:8, cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', gap:8, fontSize:'0.8125rem', color:'#0B1E3D', fontWeight:500, transition:'all 0.2s' }}
                  onMouseEnter={e=>{e.currentTarget.style.borderColor='#0B1E3D';e.currentTarget.style.background='rgba(11,30,61,0.05)'}}
                  onMouseLeave={e=>{e.currentTarget.style.borderColor='rgba(11,30,61,0.15)';e.currentTarget.style.background='rgba(11,30,61,0.03)'}}>
                  📍 {gpsActive ? 'Detecting location…' : 'Auto-capture GPS Location'}
                </button>
              )}
            </div>

            {/* File upload */}
            <FormField label="Upload Evidence" style={{ marginBottom:'1.25rem' }}>
              <div onClick={() => fileRef.current?.click()}
                style={{ border:'2px dashed #E2E8F0', borderRadius:10, padding:'1.5rem', textAlign:'center', cursor:'pointer', transition:'all 0.2s' }}
                onMouseEnter={e=>{e.currentTarget.style.borderColor='#C6A75E';e.currentTarget.style.background='rgba(198,167,94,0.03)'}}
                onMouseLeave={e=>{e.currentTarget.style.borderColor='#E2E8F0';e.currentTarget.style.background=''}}>
                <div style={{ fontSize:'1.75rem', marginBottom:'0.5rem' }}>📎</div>
                <div style={{ fontSize:'0.8125rem', color:'#64748B' }}>
                  <strong style={{ color:'#0B1E3D' }}>Click to upload</strong> or drag & drop<br />
                  <span style={{ fontSize:'0.6875rem', color:'#94A3B8' }}>Photos, videos · Max 50 MB per file · Stored on AWS S3</span>
                </div>
                <input ref={fileRef} type="file" multiple accept="image/*,video/*" onChange={handleFiles} style={{ display:'none' }} />
              </div>
              {files.length > 0 && (
                <div style={{ display:'flex', gap:6, flexWrap:'wrap', marginTop:8 }}>
                  {files.map((f, i) => (
                    <div key={i} style={{ display:'flex', alignItems:'center', gap:5, padding:'3px 10px', background:'rgba(16,185,129,0.06)', border:'1px solid rgba(16,185,129,0.2)', borderRadius:100, fontSize:'0.6875rem', color:'#065F46' }}>
                      {f.type.startsWith('video') ? '🎥' : '📷'} {f.name.slice(0, 18)}{f.name.length > 18 ? '…' : ''}
                      <button onClick={() => setFiles(fs => fs.filter((_,j)=>j!==i))} style={{ background:'none', border:'none', cursor:'pointer', color:'#94A3B8', fontSize:'0.625rem' }}>✕</button>
                    </div>
                  ))}
                </div>
              )}
            </FormField>

            <button onClick={submit} style={{ width:'100%', padding:'0.875rem', background:'linear-gradient(135deg,#0B1E3D,#1A3A6E)', color:'white', border:'none', borderRadius:8, fontSize:'0.9375rem', fontWeight:700, cursor:'pointer', fontFamily:'Inter', letterSpacing:'0.02em', transition:'all 0.2s' }}
              onMouseEnter={e=>{e.currentTarget.style.transform='translateY(-1px)';e.currentTarget.style.boxShadow='0 4px 16px rgba(11,30,61,0.25)'}}
              onMouseLeave={e=>{e.currentTarget.style.transform='';e.currentTarget.style.boxShadow=''}}>
              🚀 Submit Official Report
            </button>
          </Card>
        </div>
      </div>
      <style>{`@keyframes blink{0%,100%{opacity:1}50%{opacity:0.3}}`}</style>
    </div>
  )
}

function SuccessScreen({ form }) {
  const { setPage } = useStore()
  const issueId = 'NTV-' + Math.floor(Math.random() * 9000 + 1000)
  return (
    <div style={{ minHeight:'100vh', background:'#F0F4F8', display:'flex', alignItems:'center', justifyContent:'center', padding:'2rem' }}>
      <Card className="p-10 text-center" style={{ maxWidth:520 }}>
        <div style={{ width:72, height:72, borderRadius:'50%', background:'rgba(16,185,129,0.12)', border:'2px solid rgba(16,185,129,0.3)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'2rem', margin:'0 auto 1.5rem' }}>✅</div>
        <h2 style={{ fontFamily:'Playfair Display', fontSize:'1.5rem', fontWeight:700, color:'#0B1E3D', marginBottom:'0.5rem' }}>Issue Submitted!</h2>
        <p style={{ fontSize:'0.875rem', color:'#64748B', marginBottom:'1.5rem', lineHeight:1.7 }}>Your report has been officially recorded. AI is now analyzing priority and routing to the appropriate department.</p>
        <div style={{ background:'rgba(11,30,61,0.03)', border:'1px solid rgba(198,167,94,0.2)', borderRadius:10, padding:'1rem', marginBottom:'1.5rem' }}>
          <div style={{ fontFamily:'IBM Plex Mono', fontSize:'1.25rem', fontWeight:700, color:'#0B1E3D', marginBottom:4 }}>{issueId}</div>
          <div style={{ fontSize:'0.75rem', color:'#94A3B8' }}>Track this issue ID for status updates</div>
        </div>
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:8, marginBottom:'1.5rem' }}>
          {[['📥','Received','Just now'],['🧠','AI Analysis','~30 sec'],['📡','Routing','~2 min']].map(([i,l,t]) => (
            <div key={l} style={{ background:'#F0F4F8', borderRadius:8, padding:'0.625rem', textAlign:'center' }}>
              <div style={{ fontSize:'1.125rem', marginBottom:4 }}>{i}</div>
              <div style={{ fontSize:'0.6875rem', fontWeight:600, color:'#0F172A' }}>{l}</div>
              <div style={{ fontSize:'0.625rem', color:'#94A3B8' }}>{t}</div>
            </div>
          ))}
        </div>
        <div style={{ display:'flex', gap:8 }}>
          <Btn variant="outline" style={{ flex:1, justifyContent:'center' }} onClick={() => setPage('community')}>View Community</Btn>
          <Btn variant="primary" style={{ flex:1, justifyContent:'center' }} onClick={() => setPage('landing')}>Back to Home</Btn>
        </div>
      </Card>
    </div>
  )
}

function FormField({ label, required, children, style }) {
  return (
    <div style={{ marginBottom:'1rem', ...style }}>
      <label style={{ display:'block', fontSize:'0.8125rem', fontWeight:600, color:'#0F172A', marginBottom:'0.375rem' }}>
        {label}{required && <span style={{ color:'#EF4444', marginLeft:3 }}>*</span>}
      </label>
      {children}
    </div>
  )
}

const inputStyle = {
  width:'100%', padding:'0.75rem 1rem', borderRadius:8,
  border:'1.5px solid #E2E8F0', background:'#F0F4F8',
  fontSize:'0.9375rem', color:'#0F172A', fontFamily:'Inter',
  outline:'none', transition:'all 0.2s', boxSizing:'border-box',
}
const focusStyle = e => {
  e.target.style.borderColor = '#0B1E3D'
  e.target.style.background  = 'white'
  e.target.style.boxShadow   = '0 0 0 3px rgba(11,30,61,0.06)'
}
const blurStyle = e => {
  e.target.style.borderColor = '#E2E8F0'
  e.target.style.background  = '#F0F4F8'
  e.target.style.boxShadow   = ''
}
