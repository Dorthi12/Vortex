// ─────────────────────────────────────────────────────────────────
// NETRAVAAH — React Query Hooks (API integration layer)
// ─────────────────────────────────────────────────────────────────
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import axios from 'axios'

const API = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:5000',
  timeout: 15000,
})

// Attach JWT on every request
API.interceptors.request.use(cfg => {
  const token = localStorage.getItem('netravaah_token')
  if (token) cfg.headers.Authorization = `Bearer ${token}`
  return cfg
})

// ── Auth ──────────────────────────────────────────────────────────
export const useLogin = () =>
  useMutation({
    mutationFn: ({ email, password, role }) =>
      API.post('/api/auth/login', { email, password, role }).then(r => r.data),
    onSuccess: data => {
      if (data.token) localStorage.setItem('netravaah_token', data.token)
    },
  })

export const useSignup = () =>
  useMutation({
    mutationFn: payload =>
      API.post('/api/auth/signup', payload).then(r => r.data),
  })

// ── Issues ────────────────────────────────────────────────────────
export const useIssues = (filters = {}) =>
  useQuery({
    queryKey: ['issues', filters],
    queryFn: () =>
      API.get('/api/issues', { params: filters }).then(r => r.data),
    staleTime: 60_000,
    placeholderData: [],
  })

export const useIssue = id =>
  useQuery({
    queryKey: ['issue', id],
    queryFn: () => API.get(`/api/issues/${id}`).then(r => r.data),
    enabled: !!id,
  })

export const useCreateIssue = () => {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: payload => API.post('/api/issues', payload).then(r => r.data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['issues'] }),
  })
}

export const useUpdateIssueStatus = () => {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({ id, status }) =>
      API.patch(`/api/issues/${id}/status`, { status }).then(r => r.data),
    onSuccess: (_, { id }) => {
      qc.invalidateQueries({ queryKey: ['issues'] })
      qc.invalidateQueries({ queryKey: ['issue', id] })
    },
  })
}

// ── Hazard Predictions ────────────────────────────────────────────
export const useHazardPrediction = district =>
  useQuery({
    queryKey: ['hazard', district],
    queryFn: () =>
      API.get(`/api/district/${district}`).then(r => r.data),
    enabled: !!district,
    staleTime: 10 * 60_000,   // 10 min cache (matches backend cache)
    refetchInterval: 10 * 60_000,
  })

export const useDistrictOverview = () =>
  useQuery({
    queryKey: ['overview'],
    queryFn: () => API.get('/api/overview').then(r => r.data),
    staleTime: 5 * 60_000,
    refetchInterval: 5 * 60_000,
  })

export const useAnomalies = district =>
  useQuery({
    queryKey: ['anomalies', district],
    queryFn: () => API.get(`/api/anomalies/${district}`).then(r => r.data),
    enabled: !!district,
    staleTime: 10 * 60_000,
  })

export const useForecastAlerts = district =>
  useQuery({
    queryKey: ['forecast', district],
    queryFn: () => API.get(`/api/forecast-alerts/${district}`).then(r => r.data),
    enabled: !!district,
    staleTime: 10 * 60_000,
  })

export const usePipelineStatus = district =>
  useQuery({
    queryKey: ['pipeline', district],
    queryFn: () =>
      district
        ? API.get(`/api/pipeline-status/${district}`).then(r => r.data)
        : API.get('/api/pipeline-status').then(r => r.data),
    staleTime: 30_000,
    refetchInterval: 30_000,
  })

// ── Agriculture Models ────────────────────────────────────────────
export const useAgriYield = (district, crop) =>
  useQuery({
    queryKey: ['agri_yield', district, crop],
    queryFn: () =>
      API.get(`/api/agri/yield/${district}`, { params: { crop } }).then(r => r.data),
    enabled: !!district && !!crop,
    staleTime: 60 * 60_000,   // 1hr — yield model is slower-changing
  })

export const useAgriStress = district =>
  useQuery({
    queryKey: ['agri_stress', district],
    queryFn: () => API.get(`/api/agri/stress/${district}`).then(r => r.data),
    enabled: !!district,
    staleTime: 30 * 60_000,
  })

export const useAgriIrrigation = (district, crop, daysSowing) =>
  useQuery({
    queryKey: ['agri_irrigation', district, crop, daysSowing],
    queryFn: () =>
      API.get(`/api/agri/irrigation/${district}`, {
        params: { crop, days_sowing: daysSowing },
      }).then(r => r.data),
    enabled: !!district && !!crop,
    staleTime: 60 * 60_000,
  })

export const useAgriSuitability = (district, season) =>
  useQuery({
    queryKey: ['agri_suitability', district, season],
    queryFn: () =>
      API.get(`/api/agri/suitability/${district}`, { params: { season } }).then(r => r.data),
    enabled: !!district,
    staleTime: 24 * 60 * 60_000,  // 24hr
  })

export const useAgriRisk = district =>
  useQuery({
    queryKey: ['agri_risk', district],
    queryFn: () => API.get(`/api/agri/risk/${district}`).then(r => r.data),
    enabled: !!district,
    staleTime: 30 * 60_000,
  })

// ── Community / Posts ─────────────────────────────────────────────
export const usePosts = (filters = {}) =>
  useQuery({
    queryKey: ['posts', filters],
    queryFn: () => API.get('/api/posts', { params: filters }).then(r => r.data),
    staleTime: 30_000,
  })

export const useCreatePost = () => {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: payload => API.post('/api/posts', payload).then(r => r.data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['posts'] }),
  })
}

export const useVotePost = () => {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({ id, direction }) =>
      API.post(`/api/posts/${id}/vote`, { direction }).then(r => r.data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['posts'] }),
  })
}

export const useComments = postId =>
  useQuery({
    queryKey: ['comments', postId],
    queryFn: () => API.get(`/api/posts/${postId}/comments`).then(r => r.data),
    enabled: !!postId,
    staleTime: 30_000,
  })

export const useCreateComment = () => {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({ postId, content, parentId }) =>
      API.post(`/api/posts/${postId}/comments`, { content, parentId }).then(r => r.data),
    onSuccess: (_, { postId }) =>
      qc.invalidateQueries({ queryKey: ['comments', postId] }),
  })
}

// ── Media Upload (S3 presigned) ───────────────────────────────────
export const usePresignedUpload = () =>
  useMutation({
    mutationFn: async ({ file, type }) => {
      // 1. Get presigned URL from backend
      const { data } = await API.post('/api/media/presigned-url', {
        filename: file.name,
        contentType: file.type,
        mediaType: type,  // 'image' | 'video' | 'evidence'
      })
      // 2. Upload directly to S3
      await axios.put(data.presignedUrl, file, {
        headers: { 'Content-Type': file.type },
      })
      // 3. Return the final S3 URL
      return data.s3Url
    },
  })

// ── Dashboard (Govt) ─────────────────────────────────────────────
export const useDashboardOverview = (district, dept) =>
  useQuery({
    queryKey: ['dashboard', district, dept],
    queryFn: () =>
      API.get('/api/dashboard/overview', { params: { district, dept } }).then(r => r.data),
    enabled: !!district,
    staleTime: 2 * 60_000,
    refetchInterval: 2 * 60_000,
  })

export const usePriorityQueue = (dept) =>
  useQuery({
    queryKey: ['priority_queue', dept],
    queryFn: () =>
      API.get('/api/dashboard/priority-queue', { params: { dept } }).then(r => r.data),
    staleTime: 60_000,
    refetchInterval: 60_000,
  })

export const useAuditTrail = (dept, page = 1) =>
  useQuery({
    queryKey: ['audit', dept, page],
    queryFn: () =>
      API.get('/api/dashboard/audit-trail', { params: { dept, page } }).then(r => r.data),
    staleTime: 30_000,
  })

// ── Geo ──────────────────────────────────────────────────────────
export const useGeolocation = () => {
  const [loc, setLoc] = React.useState(null)
  const [error, setError] = React.useState(null)

  React.useEffect(() => {
    if (!navigator.geolocation) {
      setError('Geolocation not supported')
      return
    }
    navigator.geolocation.getCurrentPosition(
      pos => setLoc({ lat: pos.coords.latitude, lon: pos.coords.longitude }),
      err => setError(err.message),
      { enableHighAccuracy: true, timeout: 10000 }
    )
  }, [])

  return { loc, error }
}

// ── Notifications ─────────────────────────────────────────────────
export const useNotifications = () =>
  useQuery({
    queryKey: ['notifications'],
    queryFn: () => API.get('/api/notifications').then(r => r.data),
    staleTime: 30_000,
    refetchInterval: 30_000,
  })

export const useMarkNotificationRead = () => {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: id => API.patch(`/api/notifications/${id}/read`).then(r => r.data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['notifications'] }),
  })
}
