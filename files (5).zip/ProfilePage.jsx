import React, { useState } from 'react'
import { useStore } from '../store/useStore'
import { Card, LevelBadge, Btn, StatCard } from '../components/ui'

const MOCK_MY_ISSUES = [
  { id:'NTV-2847', title:'Streetlight broken — MG Road', status:'Under Review', level:'HIGH', time:'2h ago', score:7.2, dept:'UPCL', category:'⚡' },
  { id:'NTV-2831', title:'Water supply disrupted — Sector 4', status:'Resolved', level:'MEDIUM', time:'Yesterday', score:5.4, dept:'Jal Nigam', category:'🚰' },
  { id:'NTV-2801', title:'Pothole near market crossing', status:'Assigned', level:'MEDIUM', time:'3 days ago', score:4.8, dept:'PWD', category:'🛣️' },
  { id:'NTV-2756', title:'Garbage pile — residential colony', status:'Reported', level:'WATCH', time:'5 days ago', score:3.2, dept:'LMC', category:'🗑️' },
]

const STATUS_STYLES = {
  'Resolved':     { bg:'rgba(16,185,129,0.1)',  color:'#10B981' },
  'Under Review': { bg:'rgba(245,158,11,0.1)',  color:'#F59E0B' },
  'Assigned':     { bg:'rgba(79,70,229,0.1)',   color:'#4F46E5' },
  'Reported':     { bg:'rgba(100,116,139,0.1)', color:'#64748B' },
}

export default function ProfilePage() {
  const { user, showToast } = useStore()
  const [activeTab, setActiveTab] = useState('issues')

  if (!user) return (
    <div style={{ padding:'4rem 2rem', textAlign:'center' }}>
      <div style={{ fontSize:'3rem', marginBottom:'1rem' }}>👤</div>
      <p style={{ color:'#64748B' }}>Sign in to view your profile</p>
    </div>
  )

  const TABS = [
    { id:'issues',   label:'My Issues',   count: MOCK_MY_ISSUES.length },
    { id:'posts',    label:'My Posts',    count: 24 },
    { id:'activity', label:'Activity' },
    { id:'settings', label:'Settings' },
  ]

  return (
    <div style={{ minHeight:'100vh', background:'#F0F4F8', padding:'2rem' }}>
      <div style={{ maxWidth:900, margin:'0 auto' }}>
        {/* Profile header */}
        <Card className="mb-6 overflow-hidden">
          <div style={{ height:80, background:'linear-gradient(135deg,#0B1E3D,#1A3A6E)' }} />
          <div style={{ padding:'0 1.75rem 1.75rem' }}>
            <div style={{ display:'flex', alignItems:'flex-end', gap:'1rem', marginTop:-30, marginBottom:'1rem' }}>
              <div style={{ width:72, height:72, borderRadius:'50%', background:'linear-gradient(135deg,#C6A75E,#F59E0B)', border:'4px solid white', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'1.5rem', fontWeight:700, color:'#0B1E3D', flexShrink:0 }}>
                {user.name.split(' ').map(n=>n[0]).join('')}
              </div>
              <div style={{ flex:1, paddingBottom:4 }}>
                <h1 style={{ fontFamily:'Playfair Display', fontSize:'1.25rem', fontWeight:700, color:'#0B1E3D' }}>{user.name}</h1>
                <div style={{ display:'flex', gap:8, alignItems:'center', marginTop:2, flexWrap:'wrap' }}>
                  <span style={{ fontSize:'0.75rem', color:'#64748B' }}>👤 Citizen · Active Contributor</span>
                  <span style={{ fontSize:'0.6875rem', background:'rgba(198,167,94,0.1)', color:'#C6A75E', border:'1px solid rgba(198,167,94,0.2)', padding:'2px 8px', borderRadius:100, fontWeight:600 }}>📍 Lucknow, UP</span>
                  <span style={{ fontSize:'0.6875rem', background:'rgba(16,185,129,0.1)', color:'#10B981', border:'1px solid rgba(16,185,129,0.2)', padding:'2px 8px', borderRadius:100, fontWeight:700 }}>🏆 Civic Champion</span>
                </div>
              </div>
              <Btn variant="outline" size="sm" onClick={() => showToast('✏️ Edit profile — coming soon')}>Edit Profile</Btn>
            </div>

            {/* Stats row */}
            <div style={{ display:'flex', gap:'2rem', borderTop:'1px solid #F0F4F8', paddingTop:'1rem' }}>
              {[['8','Issues Filed'],['3','Resolved'],['312','Votes Given'],['24','Posts'],['89','Followers'],['142','Following']].map(([v,l]) => (
                <div key={l} style={{ textAlign:'center' }}>
                  <div style={{ fontFamily:'IBM Plex Mono', fontSize:'1.125rem', fontWeight:700, color:'#0B1E3D' }}>{v}</div>
                  <div style={{ fontSize:'0.6rem', color:'#94A3B8', textTransform:'uppercase', letterSpacing:'0.05em' }}>{l}</div>
                </div>
              ))}
            </div>
          </div>
        </Card>

        {/* Tabs */}
        <div style={{ display:'flex', gap:4, background:'white', borderRadius:10, padding:4, border:'1px solid #E2E8F0', marginBottom:'1.5rem', width:'fit-content' }}>
          {TABS.map(t => (
            <button key={t.id} onClick={() => setActiveTab(t.id)} style={{
              padding:'6px 16px', borderRadius:7, fontSize:'0.8125rem', fontWeight:600,
              border:'none', cursor:'pointer', transition:'all 0.2s',
              background: activeTab===t.id ? 'linear-gradient(135deg,#0B1E3D,#1A3A6E)' : 'transparent',
              color: activeTab===t.id ? 'white' : '#64748B',
            }}>
              {t.label} {t.count !== undefined && <span style={{ marginLeft:4, fontSize:'0.6rem', background: activeTab===t.id ? 'rgba(255,255,255,0.2)' : 'rgba(11,30,61,0.06)', padding:'1px 5px', borderRadius:100 }}>{t.count}</span>}
            </button>
          ))}
        </div>

        {/* My Issues */}
        {activeTab === 'issues' && (
          <div>
            {MOCK_MY_ISSUES.map(issue => {
              const ss = STATUS_STYLES[issue.status] || STATUS_STYLES['Reported']
              const progress = { 'Reported':15, 'Assigned':45, 'Under Review':65, 'Resolved':100 }[issue.status] || 0

              return (
                <Card key={issue.id} className="mb-4 p-5">
                  <div style={{ display:'flex', alignItems:'flex-start', gap:12 }}>
                    <div style={{ width:40, height:40, borderRadius:10, background:'rgba(11,30,61,0.06)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'1.125rem', flexShrink:0 }}>{issue.category}</div>
                    <div style={{ flex:1 }}>
                      <div style={{ display:'flex', gap:8, alignItems:'center', marginBottom:4, flexWrap:'wrap' }}>
                        <span style={{ fontSize:'0.875rem', fontWeight:700, color:'#0F172A' }}>{issue.title}</span>
                        <span style={{ ...ss, padding:'2px 8px', borderRadius:100, fontSize:'0.6875rem', fontWeight:700 }}>{issue.status}</span>
                      </div>
                      <div style={{ display:'flex', gap:12, marginBottom:'0.75rem' }}>
                        <span style={{ fontFamily:'IBM Plex Mono', fontSize:'0.6875rem', color:'#94A3B8' }}>{issue.id}</span>
                        <span style={{ fontSize:'0.6875rem', color:'#94A3B8' }}>🏛️ {issue.dept}</span>
                        <span style={{ fontSize:'0.6875rem', color:'#94A3B8' }}>⏰ {issue.time}</span>
                        <span style={{ fontSize:'0.6875rem', color:'#C6A75E', fontWeight:600 }}>AI Score: {issue.score}</span>
                      </div>
                      {/* Progress bar */}
                      <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                        <div style={{ flex:1, height:5, background:'#F0F4F8', borderRadius:100, overflow:'hidden' }}>
                          <div style={{ width:`${progress}%`, height:'100%', background: progress===100 ? '#10B981' : 'linear-gradient(90deg,#C6A75E,#F59E0B)', borderRadius:100, transition:'width 1s' }} />
                        </div>
                        <span style={{ fontSize:'0.625rem', color:'#94A3B8', width:28 }}>{progress}%</span>
                      </div>
                      <div style={{ display:'flex', gap:4, marginTop:6 }}>
                        {['Reported','Assigned','Under Review','Resolved'].map((s,i) => (
                          <span key={s} style={{ fontSize:'0.5625rem', color: ['Reported','Assigned','Under Review','Resolved'].indexOf(issue.status) >= i ? '#0B1E3D' : '#CBD5E1', fontWeight: issue.status===s ? 700 : 400 }}>{s}{i<3 && ' →'}</span>
                        ))}
                      </div>
                    </div>
                  </div>
                </Card>
              )
            })}
          </div>
        )}

        {/* Posts tab */}
        {activeTab === 'posts' && (
          <div style={{ padding:'3rem', textAlign:'center', background:'white', borderRadius:14, border:'1px solid #E2E8F0' }}>
            <div style={{ fontSize:'2rem', marginBottom:'0.75rem' }}>📝</div>
            <p style={{ color:'#64748B' }}>24 posts — go to Community to view</p>
            <Btn variant="primary" size="sm" style={{ marginTop:'1rem' }} onClick={() => setPage('community')}>Open Community →</Btn>
          </div>
        )}

        {/* Activity */}
        {activeTab === 'activity' && (
          <Card className="p-5">
            {[
              ['📋','Filed Issue #2847','Streetlight broken — MG Road · AI Priority 7.2','2h ago'],
              ['▲','Upvoted post','Gomti Nagar flood report by Priya K.','3h ago'],
              ['💬','Commented','On official drainage alert from Collector','5h ago'],
              ['✅','Issue Resolved','Water supply #2831 marked resolved','Yesterday'],
              ['📝','Posted update','Shared photos of pothole near market','2 days ago'],
            ].map(([icon, title, desc, time], i) => (
              <div key={i} style={{ display:'flex', gap:12, padding:'0.75rem 0', borderBottom: i<4 ? '1px solid #F0F4F8' : 'none' }}>
                <div style={{ width:34, height:34, borderRadius:8, background:'#F0F4F8', border:'1px solid #E2E8F0', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'0.875rem', flexShrink:0 }}>{icon}</div>
                <div style={{ flex:1 }}>
                  <div style={{ fontSize:'0.875rem', fontWeight:600, color:'#0F172A' }}>{title}</div>
                  <div style={{ fontSize:'0.75rem', color:'#94A3B8', marginTop:1 }}>{desc}</div>
                </div>
                <div style={{ fontFamily:'IBM Plex Mono', fontSize:'0.625rem', color:'#94A3B8', whiteSpace:'nowrap' }}>{time}</div>
              </div>
            ))}
          </Card>
        )}

        {/* Settings */}
        {activeTab === 'settings' && (
          <div style={{ display:'flex', flexDirection:'column', gap:'1rem' }}>
            <Card className="p-5">
              <div style={{ fontFamily:'Playfair Display', fontSize:'0.9375rem', fontWeight:700, color:'#0B1E3D', marginBottom:'1rem' }}>Language & Region</div>
              <div style={{ display:'flex', gap:8, flexWrap:'wrap' }}>
                {[['🇬🇧 English', true],['🇮🇳 हिंदी', false],['🇮🇳 বাংলা', false],['🇮🇳 தமிழ்', false]].map(([l, active]) => (
                  <Btn key={l} variant={active ? 'primary' : 'outline'} size="sm" onClick={() => showToast(`🌐 Switching to ${l}…`)}>{l}</Btn>
                ))}
              </div>
            </Card>
            <Card className="p-5">
              <div style={{ fontFamily:'Playfair Display', fontSize:'0.9375rem', fontWeight:700, color:'#0B1E3D', marginBottom:'1rem' }}>Notifications</div>
              {['Issue status changes','New comments','Followers','Government announcements','AI alerts in my district'].map((n, i) => (
                <div key={n} style={{ display:'flex', justifyContent:'space-between', alignItems:'center', padding:'0.625rem 0', borderBottom: i<4 ? '1px solid #F0F4F8' : 'none' }}>
                  <span style={{ fontSize:'0.875rem', color:'#0F172A' }}>{n}</span>
                  <div style={{ width:40, height:22, borderRadius:11, background:'#0B1E3D', position:'relative', cursor:'pointer' }} onClick={() => showToast('⚙️ Setting updated')}>
                    <div style={{ position:'absolute', top:3, left:3, width:16, height:16, borderRadius:'50%', background:'#C6A75E', transition:'transform 0.2s' }} />
                  </div>
                </div>
              ))}
            </Card>
          </div>
        )}
      </div>
    </div>
  )
}
