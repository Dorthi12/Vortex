import React, { useState } from 'react';
import { useStore } from '../../store/useStore';
import { DEPARTMENTS, MOCK_REPORTS, AI_MODELS } from '../../data/masterData';
import { Card, LevelBadge, Btn, StatCard } from '../ui';

export default function DepartmentsPage() {
  const { setPage, setActiveDept, showToast, isGovt } = useStore();
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('all');

  const filtered = DEPARTMENTS.filter(d => {
    if (search && !d.name.toLowerCase().includes(search.toLowerCase()) && !d.shortName.toLowerCase().includes(search.toLowerCase())) return false;
    if (filter === 'alerts' && d.activeAlerts === 0) return false;
    return true;
  });

  return (
    <div style={{ padding:'2rem' }}>
      {/* Header */}
      <div style={{ marginBottom:'2rem' }}>
        <div style={{ display:'flex', alignItems:'flex-end', justifyContent:'space-between', flexWrap:'wrap', gap:'1rem' }}>
          <div>
            <div style={{ fontSize:'0.6875rem', fontWeight:700, letterSpacing:'0.1em', textTransform:'uppercase', color:'#C6A75E', marginBottom:'0.375rem' }}>Governance Intelligence</div>
            <h1 style={{ fontFamily:'Playfair Display', fontSize:'1.75rem', fontWeight:700, color:'#0B1E3D', marginBottom:'0.375rem' }}>
              All Government <span style={{ color:'#C6A75E' }}>Departments</span>
            </h1>
            <p style={{ fontSize:'0.875rem', color:'#64748B' }}>Personalized AI reports for 10 ministries · {Object.values(MOCK_REPORTS).flat().length} active AI alerts</p>
          </div>
          <div style={{ display:'flex', gap:8 }}>
            <div style={{ display:'flex', alignItems:'center', gap:8, background:'white', border:'1px solid #E2E8F0', borderRadius:8, padding:'0.5rem 0.875rem' }}>
              <span style={{ fontSize:'0.875rem' }}>🔍</span>
              <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search departments..." style={{ border:'none', outline:'none', fontSize:'0.8125rem', color:'#0F172A', background:'transparent', width:180, fontFamily:'Inter' }} />
            </div>
            <Btn variant="gold" size="sm" onClick={() => showToast('📥 Generating consolidated report...')}>📥 All Reports</Btn>
          </div>
        </div>

        {/* Filter tabs */}
        <div style={{ display:'flex', gap:6, marginTop:'1.25rem' }}>
          {[['all','All Departments'],['alerts','Has Active Alerts']].map(([v,l]) => (
            <button key={v} onClick={() => setFilter(v)} style={{
              padding:'5px 14px', borderRadius:7, fontSize:'0.8125rem', fontWeight:600,
              border: filter===v ? 'none' : '1.5px solid #E2E8F0',
              background: filter===v ? 'linear-gradient(135deg,#0B1E3D,#1A3A6E)' : 'transparent',
              color: filter===v ? 'white' : '#64748B', cursor:'pointer',
            }}>{l}</button>
          ))}
        </div>
      </div>

      {/* Summary stats */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:'1rem', marginBottom:'2rem' }}>
        <StatCard icon="🏛️" value={DEPARTMENTS.length} label="Departments" sub="All connected" iconBg="rgba(11,30,61,0.06)" />
        <StatCard icon="🤖" value={Object.keys(AI_MODELS).length} label="AI Models" sub="Across all depts" iconBg="rgba(198,167,94,0.1)" />
        <StatCard icon="🚨" value={DEPARTMENTS.reduce((a,d)=>a+d.activeAlerts,0)} label="Active Alerts" trend="▲ 7 today" iconBg="rgba(239,68,68,0.08)" />
        <StatCard icon="✅" value={DEPARTMENTS.reduce((a,d)=>a+d.resolvedIssues,0).toLocaleString()} label="Issues Resolved" trend="↑ 8.2%" trendUp iconBg="rgba(16,185,129,0.08)" />
      </div>

      {/* Department cards grid */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(340px,1fr))', gap:'1.25rem' }}>
        {filtered.map(dept => {
          const reports = MOCK_REPORTS[dept.id] || [];
          const criticals = reports.filter(r => r.level === 'CRITICAL').length;
          const models = AI_MODELS;
          const deptModels = dept.models.map(m => models[m]).filter(Boolean);

          return (
            <Card key={dept.id} className="overflow-hidden group cursor-pointer"
              style={{ border:`1px solid ${dept.border}` }}
              onClick={() => { setActiveDept(dept.id); setPage('dept_' + dept.id); }}>

              {/* Top bar */}
              <div style={{ height:4, background:`linear-gradient(90deg,${dept.color},${dept.color}88)` }} />

              <div style={{ padding:'1.25rem' }}>
                {/* Header */}
                <div style={{ display:'flex', alignItems:'flex-start', gap:12, marginBottom:'1rem' }}>
                  <div style={{ width:48, height:48, borderRadius:12, background: dept.bg, border:`1px solid ${dept.border}`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:'1.5rem', flexShrink:0 }}>{dept.icon}</div>
                  <div style={{ flex:1, minWidth:0 }}>
                    <div style={{ fontSize:'0.9375rem', fontWeight:700, color:'#0F172A', fontFamily:'Playfair Display', lineHeight:1.2, marginBottom:3 }}>{dept.shortName}</div>
                    <div style={{ fontSize:'0.6875rem', color:'#64748B', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{dept.name}</div>
                  </div>
                  {dept.activeAlerts > 0 && (
                    <div style={{ background:'rgba(239,68,68,0.1)', color:'#DC2626', border:'1px solid rgba(239,68,68,0.2)', borderRadius:100, padding:'3px 10px', fontSize:'0.6875rem', fontWeight:700, flexShrink:0 }}>
                      🚨 {dept.activeAlerts}
                    </div>
                  )}
                </div>

                {/* Description */}
                <p style={{ fontSize:'0.8125rem', color:'#64748B', lineHeight:1.55, marginBottom:'1rem' }}>{dept.description}</p>

                {/* Models chips */}
                <div style={{ display:'flex', gap:5, flexWrap:'wrap', marginBottom:'1rem' }}>
                  {deptModels.slice(0,4).map(m => (
                    <span key={m.id} style={{ fontSize:'0.6rem', padding:'2px 8px', borderRadius:100, background: dept.bg, color: dept.color, border:`1px solid ${dept.border}`, fontWeight:600 }}>
                      {m.icon} {m.name.split(' ').slice(0,2).join(' ')}
                    </span>
                  ))}
                  {deptModels.length > 4 && (
                    <span style={{ fontSize:'0.6rem', padding:'2px 8px', borderRadius:100, background:'rgba(100,116,139,0.08)', color:'#64748B', fontWeight:600 }}>+{deptModels.length-4} more</span>
                  )}
                </div>

                {/* Stats row */}
                <div style={{ display:'flex', gap:'0.75rem', paddingTop:'0.875rem', borderTop:'1px solid #F0F4F8' }}>
                  {[
                    [dept.activeAlerts, 'Alerts', '#DC2626'],
                    [criticals, 'Critical', '#EF4444'],
                    [dept.resolvedIssues, 'Resolved', '#10B981'],
                    [deptModels.length, 'Models', dept.color],
                  ].map(([val, label, color]) => (
                    <div key={label} style={{ flex:1, textAlign:'center' }}>
                      <div style={{ fontFamily:'IBM Plex Mono', fontSize:'1rem', fontWeight:700, color }}>{val}</div>
                      <div style={{ fontSize:'0.5625rem', color:'#94A3B8', textTransform:'uppercase', letterSpacing:'0.05em' }}>{label}</div>
                    </div>
                  ))}
                </div>

                {/* Recent alert */}
                {reports[0] && (
                  <div style={{ marginTop:'0.875rem', padding:'0.625rem', background: criticals > 0 ? 'rgba(239,68,68,0.04)' : 'rgba(245,158,11,0.04)', border:`1px solid ${criticals > 0 ? 'rgba(239,68,68,0.15)' : 'rgba(245,158,11,0.15)'}`, borderRadius:8, cursor:'pointer' }}>
                    <div style={{ fontSize:'0.6875rem', fontWeight:600, color:'#0F172A', marginBottom:2, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{reports[0].title}</div>
                    <div style={{ fontSize:'0.625rem', color:'#94A3B8' }}>{reports[0].time} · {reports[0].district}</div>
                  </div>
                )}
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
