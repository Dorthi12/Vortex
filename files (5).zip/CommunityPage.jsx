import React, { useState } from 'react';
import { useStore } from '../../store/useStore';
import { COMMUNITY_POSTS, ALL_REPORTS, DEPARTMENTS, AI_MODELS } from '../../data/masterData';
import { Card, LevelBadge, Btn, ScoreRing, Tag } from '../ui';
import { levelColor } from '../../lib/theme';

export default function CommunityPage() {
  const { isGovt, userDept, user, showToast } = useStore();
  const [activeTab, setActiveTab] = useState(isGovt ? 'intelligence' : 'feed');
  const [composing, setComposing] = useState(false);
  const [draftText, setDraftText] = useState('');
  const [votes, setVotes] = useState({});
  const [filterDept, setFilterDept] = useState('all');
  const [filterLevel, setFilterLevel] = useState('all');

  const TABS = [
    { id:'feed', label:'🌐 Citizen Feed', count: COMMUNITY_POSTS.length },
    { id:'trending', label:'📈 Trending' },
    ...(isGovt ? [
      { id:'intelligence', label:'🏛️ Govt Intelligence', govtOnly:true },
      { id:'all_reports', label:'📊 All Dept Reports', govtOnly:true },
    ] : []),
  ];

  const filteredReports = ALL_REPORTS.filter(r => {
    if (filterDept !== 'all' && r.dept !== filterDept) return false;
    if (filterLevel !== 'all' && r.level !== filterLevel) return false;
    return true;
  }).sort((a, b) => b.score - a.score);

  return (
    <div style={{ minHeight:'100vh', background:'#F0F4F8' }}>
      {/* Header */}
      <div style={{ background:'#0B1E3D', padding:'1.5rem 2rem', borderBottom:'1px solid rgba(198,167,94,0.15)' }}>
        <div style={{ maxWidth:1100, margin:'0 auto' }}>
          <h1 style={{ fontFamily:'Playfair Display', fontSize:'1.5rem', fontWeight:700, color:'white', marginBottom:'0.375rem' }}>
            NETRAVAAH <span style={{ color:'#C6A75E' }}>Community</span>
          </h1>
          <p style={{ fontSize:'0.875rem', color:'rgba(255,255,255,0.5)', marginBottom:'1.25rem' }}>
            {isGovt ? 'Civic intelligence + classified government AI reports' : 'India\'s civic intelligence network'}
          </p>

          {/* Tabs */}
          <div style={{ display:'flex', gap:4 }}>
            {TABS.map(t => (
              <button key={t.id} onClick={() => setActiveTab(t.id)} style={{
                padding:'7px 18px', borderRadius:8, fontSize:'0.8125rem', fontWeight:600,
                border:'none', cursor:'pointer', transition:'all 0.2s',
                background: activeTab===t.id ? 'rgba(198,167,94,0.2)' : 'rgba(255,255,255,0.05)',
                color: activeTab===t.id ? '#C6A75E' : 'rgba(255,255,255,0.5)',
                display:'flex', alignItems:'center', gap:6,
              }}>
                {t.label}
                {t.govtOnly && <span style={{ fontSize:'0.5rem', background:'rgba(198,167,94,0.3)', color:'#C6A75E', padding:'1px 5px', borderRadius:100, fontWeight:800 }}>GOVT</span>}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div style={{ maxWidth:1100, margin:'0 auto', padding:'1.5rem 2rem' }}>

        {/* ── CITIZEN FEED ── */}
        {activeTab === 'feed' && (
          <div style={{ display:'grid', gridTemplateColumns:'1fr 280px', gap:'1.5rem' }}>
            <div>
              {/* Compose */}
              {user && (
                <div style={{ background:'white', border:'1px solid #E2E8F0', borderRadius:14, padding:'1.25rem', marginBottom:'1.25rem' }}>
                  <div style={{ display:'flex', gap:10 }}>
                    <div style={{ width:40, height:40, borderRadius:'50%', background:'linear-gradient(135deg,#C6A75E,#F59E0B)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'0.875rem', fontWeight:700, color:'#0B1E3D', flexShrink:0 }}>
                      {user.name.split(' ').map(n=>n[0]).join('')}
                    </div>
                    <textarea value={draftText} onChange={e=>setDraftText(e.target.value)}
                      placeholder="Share a civic update, report an issue, start a discussion..."
                      style={{ flex:1, border:'1.5px solid #E2E8F0', borderRadius:10, padding:'0.75rem', fontSize:'0.9375rem', fontFamily:'Inter', resize:'none', outline:'none', minHeight:60, background:'#F0F4F8', transition:'all 0.2s' }}
                      onFocus={e=>{e.target.style.borderColor='#0B1E3D';e.target.style.background='white'}}
                      onBlur={e=>{e.target.style.borderColor='#E2E8F0';e.target.style.background='#F0F4F8'}} />
                  </div>
                  <div style={{ display:'flex', gap:6, marginTop:10, paddingLeft:50, alignItems:'center' }}>
                    {['📷 Photo','🎥 Video','📍 Location'].map(b => (
                      <button key={b} onClick={() => showToast(`${b.split(' ')[0]} upload enabled`)} style={{ display:'flex', alignItems:'center', gap:4, padding:'4px 10px', borderRadius:6, fontSize:'0.75rem', fontWeight:600, color:'#64748B', cursor:'pointer', border:'none', background:'#F0F4F8', transition:'all 0.2s' }}>{b}</button>
                    ))}
                    <Btn variant="primary" size="sm" style={{ marginLeft:'auto' }} onClick={() => { if(draftText.trim()){ showToast('🚀 Post published! AI analyzing...'); setDraftText(''); } else showToast('✏️ Write something first', 'warning'); }}>Post Update</Btn>
                  </div>
                </div>
              )}

              {/* Posts */}
              {COMMUNITY_POSTS.map(post => (
                <PostCard key={post.id} post={post} votes={votes} onVote={(id, dir) => {
                  setVotes(v => ({ ...v, [`${id}_${dir}`]: !v[`${id}_${dir}`] }));
                  if (dir === 'up') showToast('▲ Upvoted — boosts AI priority');
                }} />
              ))}
            </div>

            {/* Right sidebar */}
            <div>
              <div style={{ background:'white', border:'1px solid #E2E8F0', borderRadius:14, padding:'1.25rem', marginBottom:'1rem' }}>
                <div style={{ fontSize:'0.6875rem', fontWeight:700, letterSpacing:'0.1em', textTransform:'uppercase', color:'#94A3B8', marginBottom:'0.875rem' }}>📈 Trending</div>
                {[['#GomtiNagarFlood','324 posts','🔥 Hot'],['#HazratganjPower','178 posts','🔥'],['#AlambaghRoads','92 posts','📈'],['#WaterCrisis2026','67 posts','📈']].map(([tag,count,heat]) => (
                  <div key={tag} onClick={() => showToast(`Showing ${tag} posts`)} style={{ display:'flex', alignItems:'center', gap:8, padding:'6px 0', borderBottom:'1px solid #F0F4F8', cursor:'pointer' }}>
                    <div style={{ flex:1 }}>
                      <div style={{ fontSize:'0.8125rem', fontWeight:600, color:'#0F172A' }}>{tag}</div>
                      <div style={{ fontSize:'0.6875rem', color:'#94A3B8' }}>{count}</div>
                    </div>
                    <span style={{ fontSize:'0.75rem' }}>{heat}</span>
                  </div>
                ))}
              </div>

              {isGovt && (
                <div style={{ background:'rgba(11,30,61,0.03)', border:'1px solid rgba(198,167,94,0.2)', borderRadius:14, padding:'1.25rem' }}>
                  <div style={{ fontSize:'0.6875rem', fontWeight:700, letterSpacing:'0.1em', textTransform:'uppercase', color:'#C6A75E', marginBottom:'0.875rem' }}>🏛️ Govt View</div>
                  <p style={{ fontSize:'0.75rem', color:'#64748B', lineHeight:1.6, marginBottom:'0.875rem' }}>Switch to Intelligence tab for classified AI model reports across all departments.</p>
                  <Btn variant="primary" size="sm" style={{ width:'100%', justifyContent:'center' }} onClick={() => setActiveTab('intelligence')}>View AI Reports →</Btn>
                </div>
              )}
            </div>
          </div>
        )}

        {/* ── TRENDING ── */}
        {activeTab === 'trending' && (
          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(300px,1fr))', gap:'1.25rem' }}>
            {[
              { tag:'#GomtiNagarFlood', posts:324, desc:'Drainage overflow affecting 340 residents. Flood model at 87% probability.', level:'CRITICAL', icon:'🌊' },
              { tag:'#HazratganjPower', posts:178, desc:'72hr power outage resolved. UPCL response appreciated by residents.', level:'MEDIUM', icon:'⚡' },
              { tag:'#AlambaghRoads', posts:92, desc:'Road damage causing accidents. PWD assigned. Priority score 7.2.', level:'HIGH', icon:'🛣️' },
              { tag:'#WaterCrisis2026', posts:67, desc:'Groundwater depletion in Bundelkhand. Drought model SPI-3 at -1.4.', level:'HIGH', icon:'💧' },
              { tag:'#WheatRustAlert', posts:48, desc:'Disease detection model: 94% confidence Puccinia graminis in Punjab.', level:'CRITICAL', icon:'🌾' },
              { tag:'#DelhiAQI', posts:156, desc:'PM2.5 at 312 µg/m³. GRAP Stage IV interventions required.', level:'CRITICAL', icon:'🌫️' },
            ].map(t => (
              <Card key={t.tag} className="p-5 cursor-pointer" onClick={() => showToast(`Viewing ${t.tag}`)}>
                <div style={{ display:'flex', items:'center', gap:10, marginBottom:'0.75rem' }}>
                  <span style={{ fontSize:'1.5rem' }}>{t.icon}</span>
                  <div>
                    <div style={{ fontWeight:700, color:'#0B1E3D', fontSize:'0.9375rem' }}>{t.tag}</div>
                    <div style={{ fontSize:'0.6875rem', color:'#94A3B8' }}>{t.posts} posts</div>
                  </div>
                  <div style={{ marginLeft:'auto' }}><LevelBadge level={t.level} /></div>
                </div>
                <p style={{ fontSize:'0.8125rem', color:'#64748B', lineHeight:1.55 }}>{t.desc}</p>
              </Card>
            ))}
          </div>
        )}

        {/* ── GOVT INTELLIGENCE (restricted) ── */}
        {activeTab === 'intelligence' && (
          isGovt ? (
            <div>
              <div style={{ background:'linear-gradient(135deg,#0B1E3D,#1A3A6E)', borderRadius:16, padding:'1.25rem 1.5rem', marginBottom:'1.5rem', display:'flex', alignItems:'center', gap:12 }}>
                <span style={{ fontSize:'1.25rem' }}>🔐</span>
                <div>
                  <div style={{ fontSize:'0.875rem', fontWeight:700, color:'white' }}>Classified Government Intelligence Feed</div>
                  <div style={{ fontSize:'0.75rem', color:'rgba(255,255,255,0.5)', marginTop:2 }}>AI model outputs across all {DEPARTMENTS.length} departments · Restricted to verified officials</div>
                </div>
                <div style={{ marginLeft:'auto', display:'flex', alignItems:'center', gap:6 }}>
                  <span style={{ width:8, height:8, borderRadius:'50%', background:'#10B981', display:'block', boxShadow:'0 0 6px #10B981' }} />
                  <span style={{ fontSize:'0.6875rem', color:'#10B981', fontWeight:600 }}>LIVE</span>
                </div>
              </div>

              {/* Summary row */}
              <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:'1rem', marginBottom:'1.5rem' }}>
                {[
                  ['🚨', ALL_REPORTS.filter(r=>r.level==='CRITICAL').length, 'Critical Alerts', '#EF4444'],
                  ['⚠️', ALL_REPORTS.filter(r=>r.level==='HIGH').length, 'High Priority', '#F59E0B'],
                  ['📊', ALL_REPORTS.length, 'Total Reports', '#C6A75E'],
                  ['✅', ALL_REPORTS.filter(r=>r.assigned).length, 'Assigned', '#10B981'],
                ].map(([icon, val, label, color]) => (
                  <div key={label} style={{ background:'white', border:'1px solid #E2E8F0', borderRadius:12, padding:'1rem', display:'flex', alignItems:'center', gap:10 }}>
                    <div style={{ width:38, height:38, borderRadius:10, background:`${color}12`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:'1.125rem' }}>{icon}</div>
                    <div>
                      <div style={{ fontFamily:'IBM Plex Mono', fontSize:'1.25rem', fontWeight:700, color }}>{val}</div>
                      <div style={{ fontSize:'0.6875rem', color:'#94A3B8' }}>{label}</div>
                    </div>
                  </div>
                ))}
              </div>

              {/* By dept sections */}
              {DEPARTMENTS.map(dept => {
                const reports = ALL_REPORTS.filter(r => r.dept === dept.id);
                if (reports.length === 0) return null;
                return (
                  <div key={dept.id} style={{ marginBottom:'1.5rem' }}>
                    <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:'0.75rem' }}>
                      <span style={{ fontSize:'1rem' }}>{dept.icon}</span>
                      <span style={{ fontFamily:'Playfair Display', fontSize:'0.9375rem', fontWeight:700, color:'#0B1E3D' }}>{dept.shortName}</span>
                      <span style={{ fontSize:'0.6rem', padding:'2px 7px', borderRadius:100, background: dept.bg, color: dept.color, fontWeight:700, border:`1px solid ${dept.border}` }}>{reports.length} alerts</span>
                      <div style={{ flex:1, height:1, background:'#E2E8F0', marginLeft:4 }} />
                    </div>
                    <div style={{ display:'flex', flexDirection:'column', gap:'0.625rem' }}>
                      {reports.map(r => <IntelligenceReportRow key={r.id} report={r} dept={dept} />)}
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <AccessDenied tab="Government Intelligence" />
          )
        )}

        {/* ── ALL DEPT REPORTS ── */}
        {activeTab === 'all_reports' && (
          isGovt ? (
            <div>
              <div style={{ display:'flex', gap:8, flexWrap:'wrap', marginBottom:'1.25rem', alignItems:'center' }}>
                <span style={{ fontSize:'0.8125rem', fontWeight:600, color:'#64748B', marginRight:4 }}>Dept:</span>
                <button onClick={()=>setFilterDept('all')} style={{ padding:'4px 12px', borderRadius:7, fontSize:'0.75rem', fontWeight:600, border: filterDept==='all'?'none':'1.5px solid #E2E8F0', background: filterDept==='all'?'linear-gradient(135deg,#0B1E3D,#1A3A6E)':'transparent', color: filterDept==='all'?'white':'#64748B', cursor:'pointer' }}>All</button>
                {DEPARTMENTS.map(d => (
                  <button key={d.id} onClick={()=>setFilterDept(d.id)} style={{ padding:'4px 12px', borderRadius:7, fontSize:'0.75rem', fontWeight:600, border: filterDept===d.id?'none':`1.5px solid ${d.border}`, background: filterDept===d.id? d.color:'transparent', color: filterDept===d.id?'white': d.color, cursor:'pointer' }}>
                    {d.icon} {d.shortName}
                  </button>
                ))}
              </div>
              <div style={{ display:'flex', gap:6, marginBottom:'1.25rem' }}>
                <span style={{ fontSize:'0.8125rem', fontWeight:600, color:'#64748B', marginRight:4 }}>Level:</span>
                {['all','CRITICAL','HIGH','MEDIUM'].map(l => (
                  <button key={l} onClick={()=>setFilterLevel(l)} style={{ padding:'4px 12px', borderRadius:7, fontSize:'0.75rem', fontWeight:600, border: filterLevel===l?'none':'1.5px solid #E2E8F0', background: filterLevel===l?(l==='all'?'linear-gradient(135deg,#0B1E3D,#1A3A6E)':l==='CRITICAL'?'#EF4444':l==='HIGH'?'#F59E0B':'#10B981'):'transparent', color: filterLevel===l?'white':'#64748B', cursor:'pointer' }}>
                    {l==='all'?'All':l}
                  </button>
                ))}
              </div>
              <div style={{ fontSize:'0.8125rem', color:'#94A3B8', marginBottom:'1rem' }}>{filteredReports.length} reports found</div>
              <div style={{ display:'flex', flexDirection:'column', gap:'0.75rem' }}>
                {filteredReports.map(r => {
                  const dept = DEPARTMENTS.find(d=>d.id===r.dept);
                  const model = AI_MODELS[r.model];
                  return (
                    <div key={r.id} style={{ background:'white', border:`1px solid ${levelColor(r.level).badge}`, borderRadius:12, padding:'1rem 1.25rem', display:'flex', alignItems:'center', gap:12, transition:'all 0.2s' }}
                      onMouseEnter={e=>e.currentTarget.style.boxShadow='0 4px 16px rgba(11,30,61,0.08)'}
                      onMouseLeave={e=>e.currentTarget.style.boxShadow=''}>
                      <ScoreRing score={r.score} size={42} />
                      <div style={{ flex:1, minWidth:0 }}>
                        <div style={{ display:'flex', gap:8, alignItems:'center', marginBottom:3, flexWrap:'wrap' }}>
                          <span style={{ fontSize:'0.8125rem', fontWeight:700, color:'#0F172A' }}>{r.title}</span>
                          <LevelBadge level={r.level} />
                        </div>
                        <div style={{ fontSize:'0.75rem', color:'#64748B' }}>{r.summary}</div>
                        <div style={{ display:'flex', gap:8, marginTop:4, flexWrap:'wrap' }}>
                          {dept && <span style={{ fontSize:'0.5875rem', background: dept.bg, color: dept.color, padding:'2px 7px', borderRadius:100, fontWeight:700, border:`1px solid ${dept.border}` }}>{dept.icon} {dept.shortName}</span>}
                          {model && <span style={{ fontSize:'0.5875rem', background:'rgba(11,30,61,0.05)', color:'#64748B', padding:'2px 7px', borderRadius:100, fontWeight:600 }}>{model.icon} {model.name}</span>}
                          <span style={{ fontSize:'0.6875rem', color:'#94A3B8' }}>📍 {r.district} · {r.time}</span>
                        </div>
                      </div>
                      <div style={{ display:'flex', gap:6, flexShrink:0 }}>
                        <Btn variant="outline" size="sm" onClick={() => showToast(`✅ Assigned to ${dept?.shortName}`)}>Assign</Btn>
                        <Btn variant="gold" size="sm" onClick={() => showToast('🚨 Escalated!')}>Escalate</Btn>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ) : (
            <AccessDenied tab="All Department Reports" />
          )
        )}
      </div>
    </div>
  );
}

// ── Post Card ─────────────────────────────────────────────────────
function PostCard({ post, votes, onVote }) {
  const { showToast, isGovt } = useStore();
  const upKey = `${post.id}_up`;
  const voted = votes[upKey];
  const SENT_COLORS = { frustrated:'#EF4444', positive:'#10B981', official:'#C6A75E', urgent:'#F59E0B' };

  return (
    <div style={{ background:'white', border: post.verified ? '1px solid rgba(198,167,94,0.3)' : '1px solid #E2E8F0', borderRadius:14, padding:'1.25rem', marginBottom:'0.875rem', transition:'all 0.2s' }}
      onMouseEnter={e=>e.currentTarget.style.boxShadow='0 4px 16px rgba(11,30,61,0.08)'}
      onMouseLeave={e=>e.currentTarget.style.boxShadow=''}>
      <div style={{ display:'flex', gap:10, marginBottom:'0.875rem' }}>
        <div style={{ width:42, height:42, borderRadius:'50%', background: post.color, display:'flex', alignItems:'center', justifyContent:'center', fontSize: post.verified ? '1.125rem' : '0.875rem', fontWeight:700, color:'white', flexShrink:0 }}>
          {post.initials}
        </div>
        <div style={{ flex:1 }}>
          <div style={{ display:'flex', gap:6, alignItems:'center', flexWrap:'wrap' }}>
            <span style={{ fontSize:'0.9375rem', fontWeight:700, color:'#0F172A' }}>{post.author}</span>
            {post.verified && <span style={{ fontSize:'0.5625rem', background:'#C6A75E', color:'#0B1E3D', padding:'2px 6px', borderRadius:100, fontWeight:800 }}>✓ VERIFIED</span>}
          </div>
          <div style={{ display:'flex', gap:6, marginTop:2, flexWrap:'wrap' }}>
            <span style={{ fontSize:'0.6875rem', color:'#94A3B8' }}>{post.role}</span>
            <span style={{ fontSize:'0.6875rem', background:'rgba(11,30,61,0.06)', color:'#0B1E3D', padding:'1px 7px', borderRadius:100, fontWeight:600 }}>📍 {post.district}</span>
            <span style={{ fontSize:'0.6875rem', color:'#94A3B8' }}>{post.time}</span>
          </div>
        </div>
        <button onClick={() => showToast('⋯ Options: Report, Follow, Share')} style={{ background:'none', border:'none', cursor:'pointer', fontSize:'1.25rem', color:'#94A3B8', padding:'4px' }}>⋯</button>
      </div>

      {post.tag && (
        <span style={{ display:'inline-flex', fontSize:'0.6875rem', padding:'3px 10px', borderRadius:100, background:'rgba(11,30,61,0.05)', color:'#0B1E3D', fontWeight:600, marginBottom:'0.625rem' }}>#{post.tag}</span>
      )}

      <p style={{ fontSize:'0.9375rem', lineHeight:1.65, color:'#0F172A', marginBottom:'0.875rem' }}>{post.content}</p>

      {post.hasAI && post.aiInsight && (
        <div style={{ padding:'0.625rem 0.875rem', background:'rgba(11,30,61,0.03)', border:'1px solid rgba(198,167,94,0.2)', borderRadius:8, marginBottom:'0.875rem', display:'flex', gap:8 }}>
          <span style={{ fontSize:'0.875rem', flexShrink:0 }}>🧠</span>
          <span style={{ fontSize:'0.8125rem', color:'#64748B', lineHeight:1.5 }}>
            <strong style={{ color:'#0B1E3D' }}>AI Analysis: </strong>{post.aiInsight}
          </span>
        </div>
      )}

      {post.sentiment && post.sentiment !== 'official' && (
        <div style={{ display:'flex', alignItems:'center', gap:6, marginBottom:'0.875rem' }}>
          <span style={{ fontSize:'0.6rem', padding:'3px 8px', borderRadius:100, background:`${SENT_COLORS[post.sentiment] || '#94A3B8'}12`, color: SENT_COLORS[post.sentiment] || '#94A3B8', fontWeight:700, border:`1px solid ${SENT_COLORS[post.sentiment] || '#94A3B8'}25` }}>
            {post.sentiment === 'positive' ? '😊 Positive' : post.sentiment === 'frustrated' ? '😤 Frustrated' : '⚠️ Urgent'}
          </span>
        </div>
      )}

      <div style={{ display:'flex', gap:4, paddingTop:'0.75rem', borderTop:'1px solid #F0F4F8', flexWrap:'wrap' }}>
        <button onClick={() => onVote(post.id, 'up')} style={{ display:'flex', alignItems:'center', gap:5, padding:'5px 10px', borderRadius:7, fontSize:'0.8125rem', color: voted ? '#C6A75E' : '#64748B', background: voted ? 'rgba(198,167,94,0.08)' : 'transparent', border:'none', cursor:'pointer', fontWeight: voted ? 700 : 500 }}>
          ▲ {post.votes + (voted ? 1 : 0)}
        </button>
        <button onClick={() => showToast('💬 Comments loading...')} style={{ display:'flex', alignItems:'center', gap:5, padding:'5px 10px', borderRadius:7, fontSize:'0.8125rem', color:'#64748B', background:'transparent', border:'none', cursor:'pointer' }}>
          💬 {post.comments}
        </button>
        <button onClick={() => showToast('🔗 Link copied')} style={{ display:'flex', alignItems:'center', gap:5, padding:'5px 10px', borderRadius:7, fontSize:'0.8125rem', color:'#64748B', background:'transparent', border:'none', cursor:'pointer' }}>
          🔗 Share
        </button>
        {isGovt && (
          <button onClick={() => showToast('📋 Issue logged from signal')} style={{ display:'flex', alignItems:'center', gap:5, padding:'5px 10px', borderRadius:7, fontSize:'0.8125rem', color:'#DC2626', background:'rgba(239,68,68,0.06)', border:'none', cursor:'pointer', fontWeight:600, marginLeft:'auto' }}>
            🚨 Log Issue
          </button>
        )}
      </div>
    </div>
  );
}

// ── Intelligence Report Row ────────────────────────────────────────
function IntelligenceReportRow({ report, dept }) {
  const { showToast } = useStore();
  const model = AI_MODELS[report.model];
  return (
    <div style={{ background:'white', border:`1px solid ${levelColor(report.level).badge}`, borderRadius:10, padding:'0.875rem 1rem', display:'flex', alignItems:'center', gap:10, transition:'all 0.2s' }}
      onMouseEnter={e=>e.currentTarget.style.boxShadow='0 2px 12px rgba(11,30,61,0.07)'}
      onMouseLeave={e=>e.currentTarget.style.boxShadow=''}>
      <ScoreRing score={report.score} size={38} />
      <div style={{ flex:1, minWidth:0 }}>
        <div style={{ fontSize:'0.8125rem', fontWeight:700, color:'#0F172A', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{report.title}</div>
        <div style={{ fontSize:'0.6875rem', color:'#94A3B8', marginTop:2 }}>📍 {report.district}, {report.state} · {report.time} {model ? `· ${model.icon} ${model.name}` : ''}</div>
      </div>
      <LevelBadge level={report.level} />
      {!report.assigned && (
        <Btn variant="outline" size="sm" onClick={() => showToast(`✅ Assigned to ${dept.shortName}`)}>Assign</Btn>
      )}
    </div>
  );
}

// ── Access Denied ─────────────────────────────────────────────────
function AccessDenied({ tab }) {
  const { setPage } = useStore();
  return (
    <div style={{ textAlign:'center', padding:'5rem 2rem' }}>
      <div style={{ fontSize:'3rem', marginBottom:'1rem' }}>🔐</div>
      <h2 style={{ fontFamily:'Playfair Display', fontSize:'1.5rem', color:'#0B1E3D', marginBottom:'0.75rem' }}>Restricted Access</h2>
      <p style={{ color:'#64748B', maxWidth:400, margin:'0 auto 1.5rem' }}>
        The <strong>{tab}</strong> section is restricted to verified government officials only.
      </p>
      <Btn variant="primary" onClick={() => setPage('landing')}>← Back to Home</Btn>
    </div>
  );
}
