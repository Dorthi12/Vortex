/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        playfair: ['"Playfair Display"', 'serif'],
        inter:    ['Inter', 'sans-serif'],
        mono:     ['"IBM Plex Mono"', 'monospace'],
      },
      colors: {
        navy:    '#0B1E3D',
        'navy-light': '#132952',
        'navy-mid':   '#1A3A6E',
        gold:    '#C6A75E',
        saffron: '#F59E0B',
      },
      keyframes: {
        slideUp: {
          from: { transform: 'translateY(60px)', opacity: '0' },
          to:   { transform: 'translateY(0)',    opacity: '1' },
        },
        scaleIn: {
          from: { transform: 'scale(0.95) translateY(16px)', opacity: '0' },
          to:   { transform: 'scale(1) translateY(0)',        opacity: '1' },
        },
        blink: {
          '0%,100%': { opacity: '1' },
          '50%':     { opacity: '0.3' },
        },
      },
      animation: {
        'slide-up': 'slideUp 0.4s cubic-bezier(0.34,1.56,0.64,1)',
        'scale-in': 'scaleIn 0.3s ease',
        'blink':    'blink 2s ease-in-out infinite',
      },
    },
  },
  plugins: [],
}
