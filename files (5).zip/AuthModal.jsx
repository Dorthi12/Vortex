import React, { useState } from 'react';
import { useStore } from '../../store/useStore';
import { DEPARTMENTS } from '../../data/masterData';
import { Modal, Btn } from '../ui';

export default function AuthModal({ mode, onClose }) {
  const { login, setPage, showToast } = useStore();
  const [role, setRole] = useState(mode === 'official' ? 'govt' : 'citizen');
  const [selectedDept, setSelectedDept] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [step, setStep] = useState('form'); // 'form' | 'dept'
  const isSignup = mode === 'signup';

  const handleSubmit = () => {
    if (!email || !password) { showToast('Please fill in all fields', 'warning'); return; }
    if (role === 'govt' && !selectedDept) { showToast('Please select your department', 'warning'); return; }
    login(role, selectedDept || null);
    onClose();
    showToast(`🎉 Welcome to NETRAVAAH!`);
    if (role === 'govt') setPage('dashboard');
  };

  return (
    <Modal open onClose={onClose}>
      <div style={{ padding:'2rem' }}>
        {/* Logo */}
        <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:'1.5rem' }}>
          <div style={{ width:32, height:32, borderRadius:8, background:'linear-gradient(135deg,#C6A75E,#F59E0B)', display:'flex', alignItems:'center', justifyContent:'center', fontFamily:'Playfair Display', fontWeight:700, color:'#0B1E3D', fontSize:'0.875rem' }}>N</div>
          <span style={{ fontFamily:'Playfair Display', fontSize:'0.9375rem', fontWeight:700, color:'#0B1E3D' }}>NETRAVAAH</span>
        </div>

        <h2 style={{ fontFamily:'Playfair Display', fontSize:'1.375rem', fontWeight:700, color:'#0B1E3D', marginBottom:'0.25rem' }}>
          {isSignup ? 'Create Account' : 'Welcome Back'}
        </h2>
        <p style={{ fontSize:'0.875rem', color:'#64748B', marginBottom:'1.5rem' }}>
          {isSignup ? 'Join the governance intelligence network' : 'Sign in to your governance account'}
        </p>

        {/* Role toggle */}
        <div style={{ display:'flex', background:'#F0F4F8', borderRadius:10, padding:4, gap:4, marginBottom:'1.5rem' }}>
          {[['citizen','👤 Citizen'],['govt','🏛️ Govt Official']].map(([r, label]) => (
            <button key={r} onClick={() => setRole(r)} style={{
              flex:1, padding:'0.5rem', borderRadius:7, fontSize:'0.8125rem', fontWeight:600,
              border:'none', cursor:'pointer', transition:'all 0.2s',
              background: role===r ? 'white' : 'transparent',
              color: role===r ? '#0B1E3D' : '#94A3B8',
              boxShadow: role===r ? '0 1px 4px rgba(11,30,61,0.08)' : 'none',
            }}>{label}</button>
          ))}
        </div>

        {/* Dept picker for govt */}
        {role === 'govt' && (
          <div style={{ background:'rgba(245,158,11,0.05)', border:'1px solid rgba(245,158,11,0.2)', borderRadius:10, padding:'0.875rem', marginBottom:'1.25rem' }}>
            <div style={{ fontSize:'0.6875rem', fontWeight:700, color:'#92400E', marginBottom:'0.75rem', display:'flex', gap:6, alignItems:'center' }}>
              <span>🔐</span> Select Your Ministry / Department
            </div>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:6 }}>
              {DEPARTMENTS.map(d => (
                <button key={d.id} onClick={() => setSelectedDept(d.id)} style={{
                  padding:'6px 10px', borderRadius:7, fontSize:'0.7rem', fontWeight:600,
                  border: selectedDept===d.id ? `2px solid ${d.color}` : '1.5px solid #E2E8F0',
                  background: selectedDept===d.id ? d.bg : 'white',
                  color: selectedDept===d.id ? d.color : '#64748B', cursor:'pointer',
                  display:'flex', alignItems:'center', gap:5, textAlign:'left',
                }}>
                  <span>{d.icon}</span> {d.shortName}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Form fields */}
        {[['Email Address','email','email','you@domain.gov.in'],['Password','password','password','Enter your password']].map(([label, type, name, placeholder]) => (
          <div key={name} style={{ marginBottom:'1rem' }}>
            <label style={{ display:'block', fontSize:'0.8125rem', fontWeight:600, color:'#0F172A', marginBottom:'0.375rem' }}>{label}</label>
            <input type={type} placeholder={placeholder} value={name==='email'?email:password} onChange={e => name==='email'?setEmail(e.target.value):setPassword(e.target.value)}
              style={{ width:'100%', padding:'0.75rem 1rem', borderRadius:8, border:'1.5px solid #E2E8F0', background:'#F0F4F8', fontSize:'0.9375rem', color:'#0F172A', fontFamily:'Inter', outline:'none', transition:'all 0.2s', boxSizing:'border-box' }}
              onFocus={e=>{e.target.style.borderColor='#0B1E3D';e.target.style.background='white'}}
              onBlur={e=>{e.target.style.borderColor='#E2E8F0';e.target.style.background='#F0F4F8'}} />
          </div>
        ))}

        {!isSignup && <div style={{ textAlign:'right', marginBottom:'1rem' }}><a href="#" style={{ fontSize:'0.8125rem', color:'#0B1E3D', fontWeight:500 }}>Forgot password?</a></div>}

        <button onClick={handleSubmit} style={{ width:'100%', padding:'0.875rem', background:'linear-gradient(135deg,#0B1E3D,#1A3A6E)', color:'white', border:'none', borderRadius:8, fontSize:'0.9375rem', fontWeight:600, cursor:'pointer', fontFamily:'Inter', transition:'all 0.2s' }}
          onMouseEnter={e=>e.currentTarget.style.transform='translateY(-1px)'}
          onMouseLeave={e=>e.currentTarget.style.transform=''}>
          {isSignup ? 'Create Account' : role==='govt' ? 'Access Dashboard' : 'Sign In'}
        </button>

        <div style={{ textAlign:'center', fontSize:'0.8125rem', color:'#94A3B8', marginTop:'1.25rem' }}>
          {isSignup ? 'Already have an account? ' : "Don't have an account? "}
          <button onClick={onClose} style={{ color:'#0B1E3D', fontWeight:700, background:'none', border:'none', cursor:'pointer' }}>
            {isSignup ? 'Sign in' : 'Create one →'}
          </button>
        </div>
      </div>
    </Modal>
  );
}
