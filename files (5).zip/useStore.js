import { create } from 'zustand';

export const useStore = create((set, get) => ({
  // Auth
  user: null,
  isGovt: false,
  userDept: null, // dept id if govt user

  login: (role, dept = null) => set({
    user: role === 'govt'
      ? { name: dept === 'agriculture' ? 'Dr. Anita Sharma' : 'Rajesh Kumar', role: 'govt', dept }
      : { name: 'Arjun Kumar', role: 'citizen' },
    isGovt: role === 'govt',
    userDept: dept,
  }),
  logout: () => set({ user: null, isGovt: false, userDept: null }),

  // Navigation
  activePage: 'landing',
  activeDept: null,
  activeModel: null,
  setPage: (page) => set({ activePage: page }),
  setActiveDept: (dept) => set({ activeDept: dept }),
  setActiveModel: (model) => set({ activeModel: model }),

  // UI
  sidebarOpen: true,
  toggleSidebar: () => set(s => ({ sidebarOpen: !s.sidebarOpen })),
  toast: null,
  showToast: (msg, type = 'success') => {
    set({ toast: { msg, type } });
    setTimeout(() => set({ toast: null }), 3500);
  },

  // Community
  posts: [],
  addPost: (post) => set(s => ({ posts: [post, ...s.posts] })),
}));
