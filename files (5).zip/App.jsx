import React, { useState } from 'react';
import { useStore } from './store/useStore';
import Navbar from './components/layout/Navbar';
import AuthModal from './components/auth/AuthModal';
import { Toast } from './components/ui';
import LandingPage from './pages/LandingPage';
import DashboardPage from './pages/DashboardPage';
import CommunityPage from './pages/CommunityPage';
import DepartmentsPage from './pages/DepartmentsPage';
import DepartmentDetailPage from './pages/DepartmentDetailPage';
import ModelDetailPage from './pages/ModelDetailPage';
import AllModelsPage from './pages/AllModelsPage';
import IssueReportPage from './pages/IssueReportPage';
import ProfilePage from './pages/ProfilePage';

export default function App() {
  const { activePage, toast } = useStore();
  const [authModal, setAuthModal] = useState(null);

  const renderPage = () => {
    if (activePage === 'landing')     return <LandingPage onLogin={setAuthModal} />;
    if (activePage === 'dashboard')   return <DashboardPage />;
    if (activePage === 'community')   return <CommunityPage />;
    if (activePage === 'departments') return <DepartmentsPage />;
    if (activePage === 'report')      return <IssueReportPage />;
    if (activePage === 'profile')     return <ProfilePage />;
    if (activePage === 'models')      return <AllModelsPage />;
    if (activePage?.startsWith('dept_')) {
      return <DepartmentDetailPage deptId={activePage.replace('dept_', '')} />;
    }
    if (activePage?.startsWith('model_')) {
      return <ModelDetailPage modelId={activePage.replace('model_', '')} />;
    }
    return <LandingPage onLogin={setAuthModal} />;
  };

  const showNavbar = activePage !== 'dashboard';

  return (
    <div style={{ minHeight:'100vh' }}>
      {showNavbar && <Navbar onLogin={setAuthModal} />}
      <div style={{ paddingTop: showNavbar ? 60 : 0 }}>
        {renderPage()}
      </div>
      {authModal && <AuthModal mode={authModal} onClose={() => setAuthModal(null)} />}
      <Toast toast={toast} />
    </div>
  );
}

// ── All Models Page ───────────────────────────────────────────────
import { AI_MODELS, DEPARTMENTS } from './data/masterData';
import { Card, Btn, ConfBar } from './components/ui';

function AllModelsPage() {
  const { setPage, setActiveModel, showToast } = useStore();
  const [filterDept, setFilterDept] = useState('all');

  const models = Object.values(AI_MODELS).filter(m =>
    filterDept === 'all' || m.dept === filterDept || (m.also && m.also.includes(filterDept))
  );

  return (
    <div style={{ padding:'2rem', maxWidth:1200, margin:'0 auto' }}>
      <div style={{ marginBottom:'2rem' }}>
        <div style={{ fontSize:'0.6875rem', fontWeight:700, letterSpacing:'0.1em', textTransform:'uppercase', color:'#C6A75E', marginBottom:'0.375rem' }}>AI Intelligence</div>
        <h1 style={{ fontFamily:'Playfair Display', fontSize:'1.75rem', fontWeight:700, color:'#0B1E3D', marginBottom:'0.375rem' }}>
          All AI <span style={{ color:'#C6A75E' }}>Models</span>
        </h1>
        <p style={{ fontSize:'0.875rem', color:'#64748B' }}>{Object.keys(AI_MODELS).length} models across {DEPARTMENTS.length} government departments</p>
      </div>

      {/* Dept filter */}
      <div style={{ display:'flex', gap:6, flexWrap:'wrap', marginBottom:'1.5rem' }}>
        <button onClick={() => setFilterDept('all')} style={{ padding:'5px 14px', borderRadius:7, fontSize:'0.75rem', fontWeight:600, border: filterDept==='all'?'none':'1.5px solid #E2E8F0', background: filterDept==='all'?'linear-gradient(135deg,#0B1E3D,#1A3A6E)':'transparent', color: filterDept==='all'?'white':'#64748B', cursor:'pointer' }}>All Models</button>
        {DEPARTMENTS.map(d => (
          <button key={d.id} onClick={() => setFilterDept(d.id)} style={{ padding:'5px 12px', borderRadius:7, fontSize:'0.75rem', fontWeight:600, border: filterDept===d.id?'none':`1.5px solid ${d.border}`, background: filterDept===d.id? d.color:'transparent', color: filterDept===d.id?'white': d.color, cursor:'pointer' }}>
            {d.icon} {d.shortName}
          </button>
        ))}
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(300px,1fr))', gap:'1.25rem' }}>
        {models.map(model => {
          const dept = DEPARTMENTS.find(d => d.id === model.dept);
          return (
            <div key={model.id} style={{ background:'white', border:'1px solid #E2E8F0', borderRadius:14, overflow:'hidden', cursor:'pointer', transition:'all 0.2s' }}
              onClick={() => { setActiveModel(model.id); setPage('model_' + model.id); }}
              onMouseEnter={e=>{e.currentTarget.style.boxShadow='0 8px 24px rgba(11,30,61,0.1)';e.currentTarget.style.borderColor='rgba(198,167,94,0.3)';e.currentTarget.style.transform='translateY(-2px)';}}
              onMouseLeave={e=>{e.currentTarget.style.boxShadow='';e.currentTarget.style.borderColor='#E2E8F0';e.currentTarget.style.transform='';}}>
              <div style={{ height:3, background: model.color || '#C6A75E' }} />
              <div style={{ padding:'1.25rem' }}>
                <div style={{ display:'flex', gap:10, marginBottom:'0.875rem' }}>
                  <div style={{ width:42, height:42, borderRadius:10, background:`${model.color || '#C6A75E'}18`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:'1.25rem', flexShrink:0 }}>{model.icon}</div>
                  <div>
                    <div style={{ fontSize:'0.9375rem', fontWeight:700, color:'#0F172A', fontFamily:'Playfair Display', lineHeight:1.2 }}>{model.name}</div>
                    <div style={{ fontSize:'0.6875rem', color:'#64748B', marginTop:2 }}>{model.algorithm}</div>
                  </div>
                </div>
                <p style={{ fontSize:'0.8125rem', color:'#64748B', lineHeight:1.55, marginBottom:'0.875rem' }}>{model.description}</p>
                <div style={{ display:'flex', gap:6, marginBottom:'0.875rem', flexWrap:'wrap' }}>
                  <span style={{ fontSize:'0.6rem', padding:'2px 8px', borderRadius:100, background:'rgba(16,185,129,0.08)', color:'#10B981', fontWeight:700 }}>✓ {model.accuracy}%</span>
                  <span style={{ fontSize:'0.6rem', padding:'2px 8px', borderRadius:100, background:'rgba(11,30,61,0.05)', color:'#64748B', fontWeight:600 }}>{model.trainingRecords}</span>
                  <span style={{ fontSize:'0.6rem', padding:'2px 8px', borderRadius:100, background:`${model.color || '#C6A75E'}12`, color: model.color || '#C6A75E', fontWeight:700 }}>{model.version}</span>
                  {dept && <span style={{ fontSize:'0.6rem', padding:'2px 8px', borderRadius:100, background: dept.bg, color: dept.color, fontWeight:700, border:`1px solid ${dept.border}` }}>{dept.icon} {dept.shortName}</span>}
                </div>
                <ConfBar label="Confidence" value={model.accuracy} color={model.color || '#C6A75E'} />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
